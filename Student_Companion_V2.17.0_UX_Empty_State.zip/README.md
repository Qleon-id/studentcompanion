# Student Companion V2.17.0

Pembaruan:
- Jadwal Ujian dibuat lebih terlihat di Detail Mata Kuliah.
- Dari Detail Mata Kuliah, pengguna bisa langsung menambah UTS/UAS/kuis/presentasi untuk mata kuliah tersebut.
- Jadwal ujian menampilkan tanggal, jam, ruangan, dan countdown.
- Checklist Tugas: tambah langkah, centang selesai, edit, hapus, dan progress otomatis.
- Checklist tersimpan lokal dan kompatibel dengan tugas lama.

Baseline: Student Companion V2.10.0 yang sudah berhasil dibuild dan diuji.


Pembaruan V2.17:
- UX empty state diperjelas untuk membedakan data belum ada dan kondisi semua tugas sudah selesai.
- Empty state mendapat visual, motion ringan, CTA, dan ikon aksi yang lebih konsisten.
- Empty state absensi sekarang memiliki tombol Catat Kehadiran yang benar-benar aktif.
- Empty state akademik mengarahkan pengguna ke penambahan mata kuliah.
- Baseline: Student Companion V2.16.0 (Animation & Motion).
