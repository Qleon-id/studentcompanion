# Student Companion V2.11.0

Pembaruan:
- Jadwal Ujian dibuat lebih terlihat di Detail Mata Kuliah.
- Dari Detail Mata Kuliah, pengguna bisa langsung menambah UTS/UAS/kuis/presentasi untuk mata kuliah tersebut.
- Jadwal ujian menampilkan tanggal, jam, ruangan, dan countdown.
- Checklist Tugas: tambah langkah, centang selesai, edit, hapus, dan progress otomatis.
- Checklist tersimpan lokal dan kompatibel dengan tugas lama.

Baseline: Student Companion V2.10.0 yang sudah berhasil dibuild dan diuji.
