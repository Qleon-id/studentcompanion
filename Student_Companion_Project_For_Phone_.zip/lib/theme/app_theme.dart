import 'package:flutter/material.dart';

class AppTheme {
  static const blue = Color(0xFF2563EB);
  static const navy = Color(0xFF173B8F);
  static const lightBlue = Color(0xFF38BDF8);
  static const purple = Color(0xFF5D17EB);
  static const pink = Color(0xFFEC4899);
  static const red = Color(0xFFEF4444);
  static const maroon = Color(0xFF8B1E3F);
  static const orange = Color(0xFFF97316);
  static const yellow = Color(0xFFEAB308);
  static const teal = Color(0xFF0F9F8E);
  static const cyan = Color(0xFF06B6D4);
  static const darkGreen = Color(0xFF166534);
  static const green = Color(0xFF22C55E);
  static const lightGreen = Color(0xFF84CC16);
  static const sage = Color(0xFF84A98C);
  static const brown = Color(0xFF8B5E3C);
  static const indigo = Color(0xFF4F46E5);
  static const gray = Color(0xFF64748B);
  static const muted = Color(0xFF667085);
  static const background = Color(0xFFF6F8FC);

  static const themeNames = <String, String>{
    'blue': 'Biru', 'navy': 'Biru tua', 'lightBlue': 'Biru muda',
    'purple': 'Ungu', 'pink': 'Pink', 'red': 'Merah', 'maroon': 'Maroon',
    'orange': 'Oranye', 'yellow': 'Kuning', 'teal': 'Teal', 'cyan': 'Cyan',
    'darkGreen': 'Hijau tua', 'green': 'Hijau', 'lightGreen': 'Hijau muda',
    'sage': 'Hijau sage', 'brown': 'Cokelat', 'indigo': 'Indigo', 'gray': 'Abu-abu',
  };

  static Color primaryFor(String theme) {
    switch (theme) {
      case 'navy': return navy;
      case 'lightBlue': return lightBlue;
      case 'purple': return purple;
      case 'pink': return pink;
      case 'red': return red;
      case 'maroon': return maroon;
      case 'orange': return orange;
      case 'yellow': return yellow;
      case 'teal': return teal;
      case 'cyan': return cyan;
      case 'darkGreen': return darkGreen;
      case 'green': return green;
      case 'lightGreen': return lightGreen;
      case 'sage': return sage;
      case 'brown': return brown;
      case 'indigo': return indigo;
      case 'gray': return gray;
      default: return blue;
    }
  }

  static ThemeData light(String theme) => _build(theme, Brightness.light);
  static ThemeData dark(String theme) => _build(theme, Brightness.dark);

  static ThemeData _build(String theme, Brightness brightness) {
    final primary = primaryFor(theme);
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(
      seedColor: primary,
      brightness: brightness,
    ).copyWith(primary: primary);
    final surface = dark ? const Color(0xFF171E28) : Colors.white;
    final page = dark ? const Color(0xFF0F141C) : background;
    final border = dark ? const Color(0xFF283241) : const Color(0xFFE1E6EF);
    final subtle = dark ? const Color(0xFF1D2632) : const Color(0xFFF1F3F8);

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: page,
      fontFamily: 'Poppins',
      visualDensity: VisualDensity.standard,
      textTheme: TextTheme(
        headlineLarge: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, height: 1.12, color: scheme.onSurface),
        headlineMedium: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, height: 1.16, color: scheme.onSurface),
        headlineSmall: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, height: 1.2, color: scheme.onSurface),
        titleLarge: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: scheme.onSurface),
        titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: scheme.onSurface),
        bodyLarge: TextStyle(fontSize: 15, height: 1.45, color: scheme.onSurface),
        bodyMedium: TextStyle(fontSize: 13, height: 1.4, color: scheme.onSurfaceVariant),
        bodySmall: const TextStyle(fontSize: 11, height: 1.35, color: muted),
        labelLarge: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: page,
        foregroundColor: scheme.onSurface,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        surfaceTintColor: Colors.transparent,
        toolbarHeight: 62,
        titleTextStyle: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: scheme.onSurface),
        iconTheme: IconThemeData(color: scheme.onSurface, size: 23),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: border),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        hintStyle: TextStyle(color: scheme.onSurfaceVariant.withAlpha(170), fontSize: 13),
        labelStyle: TextStyle(color: scheme.onSurfaceVariant, fontSize: 13),
        floatingLabelStyle: TextStyle(color: primary, fontWeight: FontWeight.w600, fontSize: 13),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: border)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: primary, width: 1.5)),
        errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: scheme.error)),
        focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: scheme.error, width: 1.5)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(0, 50),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(0, 48),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          side: BorderSide(color: border),
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          minimumSize: const Size(44, 44),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
        ),
      ),
      listTileTheme: ListTileThemeData(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        minVerticalPadding: 8,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        iconColor: scheme.onSurfaceVariant,
        titleTextStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: scheme.onSurface),
        subtitleTextStyle: const TextStyle(fontSize: 11, height: 1.35, color: muted),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        titleTextStyle: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: scheme.onSurface),
        contentTextStyle: TextStyle(fontSize: 13, height: 1.45, color: scheme.onSurfaceVariant),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: subtle,
        selectedColor: primary.withAlpha(22),
        side: BorderSide(color: border),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        labelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        indicatorColor: primary.withAlpha(dark ? 58 : 30),
        height: 76,
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        labelTextStyle: WidgetStatePropertyAll(TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: scheme.onSurface)),
        iconTheme: WidgetStatePropertyAll(IconThemeData(size: 23, color: scheme.onSurfaceVariant)),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        contentTextStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(color: primary, linearTrackColor: primary.withAlpha(24)),
      dividerTheme: DividerThemeData(color: border, thickness: 1),
    );
  }
}
