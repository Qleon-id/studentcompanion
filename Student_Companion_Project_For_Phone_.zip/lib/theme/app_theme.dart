import 'package:flutter/material.dart';

class AppTheme {
  static const blue = Color(0xFF2563EB);
  static const navy = Color(0xFF173B8F);
  static const lightBlue = Color(0xFF38BDF8);
  static const purple = Color(0xFF7C3AED);
  static const pink = Color(0xFFEC4899);
  static const red = Color(0xFFEF4444);
  static const maroon = Color(0xFF8B1E3F);
  static const orange = Color(0xFFF97316);
  static const yellow = Color(0xFFEAB308);
  static const teal = Color(0xFF0F9F8E);
  static const cyan = Color(0xFF06B6D4);
  static const darkGreen = Color(0xFF166534);
  static const green = Color(0xFF22C55E);
  static const lightGreen = Color(0xFF84CC16);
  static const sage = Color(0xFF84A98C);
  static const brown = Color(0xFF8B5E3C);
  static const indigo = Color(0xFF4F46E5);
  static const gray = Color(0xFF64748B);
  static const muted = Color(0xFF667085);
  static const background = Color(0xFFF6F8FC);

  static const themeNames = <String, String>{
    'blue': 'Biru', 'navy': 'Biru tua', 'lightBlue': 'Biru muda',
    'purple': 'Ungu', 'pink': 'Pink', 'red': 'Merah', 'maroon': 'Maroon',
    'orange': 'Oranye', 'yellow': 'Kuning', 'teal': 'Teal', 'cyan': 'Cyan',
    'darkGreen': 'Hijau tua', 'green': 'Hijau', 'lightGreen': 'Hijau muda',
    'sage': 'Hijau sage', 'brown': 'Cokelat', 'indigo': 'Indigo', 'gray': 'Abu-abu',
  };

  static Color primaryFor(String theme) {
    switch (theme) {
      case 'navy': return navy;
      case 'lightBlue': return lightBlue;
      case 'purple': return purple;
      case 'pink': return pink;
      case 'red': return red;
      case 'maroon': return maroon;
      case 'orange': return orange;
      case 'yellow': return yellow;
      case 'teal': return teal;
      case 'cyan': return cyan;
      case 'darkGreen': return darkGreen;
      case 'green': return green;
      case 'lightGreen': return lightGreen;
      case 'sage': return sage;
      case 'brown': return brown;
      case 'indigo': return indigo;
      case 'gray': return gray;
      default: return blue;
    }
  }

  static ThemeData light(String theme) => _build(theme, Brightness.light);
  static ThemeData dark(String theme) => _build(theme, Brightness.dark);

  static ThemeData _build(String theme, Brightness brightness) {
    final primary = primaryFor(theme);
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(seedColor: primary, brightness: brightness).copyWith(primary: primary);
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: dark ? const Color(0xFF0F141C) : background,
      fontFamily: 'Poppins',
      appBarTheme: AppBarTheme(backgroundColor: dark ? const Color(0xFF0F141C) : background, foregroundColor: scheme.onSurface, elevation: 0, centerTitle: false, surfaceTintColor: Colors.transparent, toolbarHeight: 64, titleTextStyle: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: scheme.onSurface)),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: dark ? const Color(0xFF171E28) : Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: dark ? const Color(0xFF2A3442) : const Color(0xFFE6EAF0))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: primary, width: 1.5)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      ),
      cardTheme: CardThemeData(color: dark ? const Color(0xFF171E28) : Colors.white, elevation: 0, margin: EdgeInsets.zero, surfaceTintColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: dark ? const Color(0xFF283241) : const Color(0xFFE3E8F0)))),
      navigationBarTheme: NavigationBarThemeData(backgroundColor: dark ? const Color(0xFF151B24) : Colors.white, indicatorColor: primary.withAlpha(dark ? 55 : 28), height: 74, labelTextStyle: WidgetStatePropertyAll(TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: scheme.onSurface)), iconTheme: WidgetStatePropertyAll(IconThemeData(size: 23))),
      dividerTheme: DividerThemeData(color: dark ? const Color(0xFF2A3442) : const Color(0xFFE8ECF2)),
    );
  }
}
