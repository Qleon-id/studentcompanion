import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:url_launcher/url_launcher.dart';
import 'models/app_models.dart';
import 'services/app_store.dart';
import 'services/notification_service.dart';
import 'theme/app_theme.dart';
import 'widgets/common.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('id_ID');
  await NotificationService.initialize();
  runApp(const StudentCompanionApp());
}

class StudentCompanionApp extends StatefulWidget {
  const StudentCompanionApp({super.key});
  @override
  State<StudentCompanionApp> createState() => _StudentCompanionAppState();
}

class _StudentCompanionAppState extends State<StudentCompanionApp> {
  final store = AppStore();
  @override
  void initState() { super.initState(); store.load(); }
  @override
  void dispose() { store.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: store, builder: (_, __) => MaterialApp(debugShowCheckedModeBanner: false, title: 'Student Companion', theme: AppTheme.light(store.theme), darkTheme: AppTheme.dark(store.theme), themeMode: store.themeMode == 'dark' ? ThemeMode.dark : store.themeMode == 'light' ? ThemeMode.light : ThemeMode.system, home: store.onboarded ? HomeShell(store: store) : OnboardingScreen(store: store)));
}

class BrandLogo extends StatelessWidget {
  final double size;
  final double radius;
  const BrandLogo({super.key, this.size = 42, this.radius = 12});

  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: Image.asset('assets/brand_logo.png', width: size, height: size, fit: BoxFit.cover),
      );
}

class GraduationLogo extends StatelessWidget {
  final double size;
  const GraduationLogo({super.key, this.size = 44});

  @override
  Widget build(BuildContext context) => Icon(
        Icons.school_rounded,
        size: size,
        color: Theme.of(context).colorScheme.primary,
      );
}

class StudentStairsIllustration extends StatefulWidget {
  final double size;
  const StudentStairsIllustration({super.key, this.size = 118});

  @override
  State<StudentStairsIllustration> createState() => _StudentStairsIllustrationState();
}

class _StudentStairsIllustrationState extends State<StudentStairsIllustration> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800));
    if (!MediaQueryData.fromView(WidgetsBinding.instance.platformDispatcher.views.first).disableAnimations) {
      _controller.repeat(reverse: true);
    } else {
      _controller.value = .5;
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).disableAnimations) {
      return Image.asset('assets/student_stairs_original.png', width: widget.size, height: widget.size, fit: BoxFit.contain);
    }
    return AnimatedBuilder(
      animation: _controller,
      child: Image.asset('assets/student_stairs_original.png', width: widget.size, height: widget.size, fit: BoxFit.contain),
      builder: (context, child) => Transform.translate(offset: Offset(0, -2.5 * Curves.easeInOut.transform(_controller.value)), child: child),
    );
  }
}
class OnboardingScreen extends StatefulWidget {
  final AppStore store;
  const OnboardingScreen({super.key, required this.store});
  @override State<OnboardingScreen> createState() => _OnboardingScreenState();
}
class _OnboardingScreenState extends State<OnboardingScreen> {
  final name = TextEditingController();
  final university = TextEditingController();
  final major = TextEditingController();
  final nim = TextEditingController();
  int semester = 1;
  int step = 0;
  @override void dispose() { name.dispose(); university.dispose(); major.dispose(); nim.dispose(); super.dispose(); }
  void next() {
    if (step == 0) { setState(() => step = 1); return; }
    if (name.text.trim().isEmpty) { _snack('Nama mahasiswa wajib diisi.'); return; }
    widget.store.completeOnboarding(StudentProfile(name: name.text.trim(), university: university.text.trim(), major: major.text.trim(), nim: nim.text.trim(), semester: semester));
  }
  @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(24, 24, 24, 20), child: Column(children: [Row(children: [const BrandLogo(size: 42, radius: 13), const SizedBox(width: 12), const Text('Student Companion', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))]), Expanded(child: AnimatedSwitcher(duration: const Duration(milliseconds: 250), child: step == 0 ? _welcome(context) : _profile(context))), _dots(), const SizedBox(height: 16), PrimaryButton(label: step == 0 ? 'Mulai Sekarang' : 'Simpan & Masuk', onPressed: next)]))));
  Widget _welcome(BuildContext context) => Center(key: const ValueKey(0), child: Column(mainAxisSize: MainAxisSize.min, children: [Container(width: 120, height: 120, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(18), shape: BoxShape.circle), child: Icon(Icons.auto_awesome_rounded, size: 58, color: Theme.of(context).colorScheme.primary)), const SizedBox(height: 28), const Text('Kuliah jadi lebih teratur.', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, height: 1.15)), const SizedBox(height: 12), const Text('Dari tugas sampai IPK, semua dalam satu aplikasi.', textAlign: TextAlign.center, style: TextStyle(fontSize: 15, color: AppTheme.muted, height: 1.5)), const SizedBox(height: 28), Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: const [_Pill(icon: Icons.task_alt_rounded, text: 'Tugas'), _Pill(icon: Icons.calendar_month_rounded, text: 'Jadwal'), _Pill(icon: Icons.auto_graph_rounded, text: 'IPK')])]));
  Widget _profile(BuildContext context) => ListView(key: const ValueKey(1), padding: const EdgeInsets.only(top: 24), children: [const Text('Kenalan dulu, yuk.', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)), const SizedBox(height: 8), const Text('Data ini tersimpan di perangkatmu dan bisa diubah kapan saja.', style: TextStyle(color: AppTheme.muted)), const SizedBox(height: 24), TextField(controller: name, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Nama lengkap', prefixIcon: Icon(Icons.person_outline_rounded))), const SizedBox(height: 12), TextField(controller: university, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Universitas (opsional)', prefixIcon: Icon(Icons.account_balance_outlined))), const SizedBox(height: 12), TextField(controller: major, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Program studi (opsional)', prefixIcon: Icon(Icons.menu_book_outlined))), const SizedBox(height: 12), TextField(controller: nim, decoration: const InputDecoration(labelText: 'NIM (opsional)', prefixIcon: Icon(Icons.badge_outlined))), const SizedBox(height: 16), DropdownButtonFormField<int>(initialValue: semester, decoration: const InputDecoration(labelText: 'Semester saat ini', prefixIcon: Icon(Icons.layers_outlined)), items: List.generate(12, (i) => DropdownMenuItem(value: i + 1, child: Text('Semester ${i + 1}'))), onChanged: (v) => setState(() => semester = v ?? 1))]);
  Widget _dots() => Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(2, (i) => AnimatedContainer(duration: const Duration(milliseconds: 200), margin: const EdgeInsets.symmetric(horizontal: 4), width: i == step ? 22 : 7, height: 7, decoration: BoxDecoration(color: i == step ? Theme.of(context).colorScheme.primary : const Color(0xFFD7DCE5), borderRadius: BorderRadius.circular(10)))));
  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
}
class _Pill extends StatelessWidget { final IconData icon; final String text; const _Pill({required this.icon, required this.text}); @override Widget build(BuildContext c) => Container(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9), decoration: BoxDecoration(color: Theme.of(c).colorScheme.surface, borderRadius: BorderRadius.circular(30), border: Border.all(color: Theme.of(c).dividerColor)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 17, color: Theme.of(c).colorScheme.primary), const SizedBox(width: 6), Text(text, style: const TextStyle(fontWeight: FontWeight.w600))])); }

Widget _buildClassCard(BuildContext context, AppStore store, ScheduleItem item) {
  final course = store.courses.where((c) => c.id == item.courseId).firstOrNull;
  return Card(
    margin: const EdgeInsets.only(bottom: 9),
    child: ListTile(
      contentPadding: const EdgeInsets.all(13),
      leading: Container(
        width: 58,
        padding: const EdgeInsets.symmetric(vertical: 7),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(13)),
        child: Column(children: [
          Text(item.start, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800, fontSize: 12)),
          const Text('—', style: TextStyle(color: AppTheme.muted, fontSize: 10)),
          Text(item.end, style: const TextStyle(color: AppTheme.muted, fontSize: 10)),
        ]),
      ),
      title: Text(course?.name ?? 'Mata kuliah', style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text([course?.code, if (item.room.isNotEmpty) item.room].whereType<String>().where((x) => x.isNotEmpty).join(' • ')),
    ),
  );
}

Widget _buildTaskCard(BuildContext context, AppStore store, TaskItem task) {
  final course = store.courses.where((c) => c.id == task.courseId).firstOrNull;
  final late = task.dueDate.isBefore(DateTime.now()) && !task.isDone;
  return Card(
    margin: const EdgeInsets.only(bottom: 9),
    child: ListTile(
      onTap: () => showTaskDetail(context, store, task),
      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 5),
      leading: Checkbox(value: task.isDone, onChanged: (_) => store.toggleTask(task.id)),
      title: Text(task.title, style: TextStyle(fontWeight: FontWeight.w700, decoration: task.isDone ? TextDecoration.lineThrough : null)),
      subtitle: Text('${course?.name ?? 'Mata kuliah'} • ${DateFormat('HH:mm').format(task.dueDate)}', style: TextStyle(color: late ? Colors.red : AppTheme.muted)),
      trailing: _PriorityPill(task.priority),
    ),
  );
}

class HomeShell extends StatefulWidget {
  final AppStore store;
  const HomeShell({super.key, required this.store});
  @override State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int index = 0;
  @override Widget build(BuildContext context) {
    final pages = [DashboardPage(store: widget.store, onTab: (i) => setState(() => index = i)), CoursesPage(store: widget.store), SchedulePage(store: widget.store), ProgressPage(store: widget.store), ProfilePage(store: widget.store)];
    return Scaffold(body: IndexedStack(index: index, children: pages), bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (i) => setState(() => index = i), destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'), NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book_rounded), label: 'Kuliah'), NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month_rounded), label: 'Jadwal'), NavigationDestination(icon: Icon(Icons.auto_graph_outlined), selectedIcon: Icon(Icons.auto_graph_rounded), label: 'Progress'), NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'Profil')]));
  }
}

class DashboardPage extends StatelessWidget {
  final AppStore store;
  final ValueChanged<int> onTab;
  const DashboardPage({super.key, required this.store, required this.onTab});

  @override
  Widget build(BuildContext context) {
    final pending = store.tasks.where((t) => !t.completed).toList()..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    final upcoming = _upcomingSchedule(store);
    final now = DateTime.now();
    final greeting = now.hour < 12 ? 'Selamat pagi' : now.hour < 18 ? 'Selamat siang' : 'Selamat malam';
    final totalCredits = store.courses.fold<int>(0, (sum, c) => sum + c.credits);
    return SafeArea(child: CustomScrollView(slivers: [
      SliverPadding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 28), sliver: SliverList(delegate: SliverChildListDelegate([
        Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(greeting, style: const TextStyle(color: AppTheme.muted, fontSize: 13)), const SizedBox(height: 2), Text(store.profile.name.isEmpty ? 'Mahasiswa' : store.profile.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800))])), CircleAvatar(radius: 20, backgroundColor: Theme.of(context).colorScheme.primary.withAlpha(18), backgroundImage: store.profilePhotoPath.isNotEmpty && File(store.profilePhotoPath).existsSync() ? FileImage(File(store.profilePhotoPath)) : null, child: store.profilePhotoPath.isNotEmpty && File(store.profilePhotoPath).existsSync() ? null : Icon(Icons.person_rounded, color: Theme.of(context).colorScheme.primary)), IconButton(onPressed: () => Navigator.push(context, MotionPageRoute(builder: (_) => NotesPage(store: store))), icon: const Icon(Icons.sticky_note_2_outlined)), IconButton(tooltip: 'Agenda Pintar', onPressed: () => Navigator.push(context, MotionPageRoute(builder: (_) => AgendaPage(store: store))), icon: const Icon(Icons.calendar_month_outlined)), IconButton(onPressed: () => _showNotifications(context), icon: const Icon(Icons.notifications_none_rounded))]),
        const SizedBox(height: 16),
        MotionReveal(delay: const Duration(milliseconds: 0), child: _HeroCard(store: store)),
        const SizedBox(height: 16),
        MotionReveal(delay: const Duration(milliseconds: 70), child: Row(children: [StatCard(icon: Icons.task_alt_rounded, value: '${store.pendingTasks}', label: 'Tugas aktif', color: Theme.of(context).colorScheme.primary), const SizedBox(width: 10), StatCard(icon: Icons.menu_book_rounded, value: '${store.courses.length}', label: 'Mata kuliah', color: AppTheme.teal), const SizedBox(width: 10), StatCard(icon: Icons.star_rounded, value: store.gpa.toStringAsFixed(2), label: 'IP semester', color: AppTheme.orange)])),
        const SizedBox(height: 14),
        MotionReveal(delay: const Duration(milliseconds: 140), child: Row(children: [Expanded(child: _MiniDashboardStat(icon: Icons.timelapse_rounded, label: 'Dalam proses', value: '${store.inProgressTasks}')), const SizedBox(width: 10), Expanded(child: _MiniDashboardStat(icon: Icons.warning_amber_rounded, label: 'Terlambat', value: '${store.overdueTasks}')), const SizedBox(width: 10), Expanded(child: _MiniDashboardStat(icon: Icons.flag_rounded, label: 'Prioritas tinggi', value: '${store.highPriorityTasks}'))])),
        const SizedBox(height: 18),
        MotionReveal(delay: const Duration(milliseconds: 210), child: Card(child: ListTile(contentPadding: const EdgeInsets.all(14), leading: SizedBox(width: 52, height: 52, child: const GraduationLogo(size: 52)), title: const Text('Semester kamu', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${store.profile.semester} • $totalCredits SKS terdaftar', style: const TextStyle(color: AppTheme.muted, fontSize: 12)), trailing: TextButton(onPressed: () => onTab(1), child: const Text('Lihat'))))),
        const SizedBox(height: 10),
        Card(child: ListTile(onTap: () => Navigator.push(context, MotionPageRoute(builder: (_) => ResourcesPage(store: store))), contentPadding: const EdgeInsets.all(14), leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(13)), child: Icon(Icons.folder_copy_outlined, color: Theme.of(context).colorScheme.primary)), title: const Text('Pusat Dokumen & Link', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${store.resources.length} materi/link tersimpan • Drive, Classroom, Canva, dan lainnya', style: const TextStyle(color: AppTheme.muted, fontSize: 12)), trailing: const Icon(Icons.chevron_right_rounded))),
        const SizedBox(height: 22),
        const SectionTitle(title: 'Jadwal berikutnya'),
        const SizedBox(height: 10),
        upcoming == null ? const _EmptyScheduleDashboard() : _UpcomingScheduleCard(item: upcoming.item, course: upcoming.course, date: upcoming.date),
        const SizedBox(height: 22),
        const SectionTitle(title: 'Ujian terdekat'),
        const SizedBox(height: 10),
        _UpcomingExamCard(exam: _upcomingExam(store), store: store),
        const SizedBox(height: 22),
        SectionTitle(title: 'Tugas terdekat', action: 'Lihat semua', onAction: () => Navigator.push(context, MotionPageRoute(builder: (_) => TasksPage(store: store)))),
        const SizedBox(height: 10),
        if (pending.isEmpty) const EmptyState(icon: Icons.task_alt_rounded, title: 'Semua beres!', subtitle: 'Belum ada tugas yang perlu dikerjakan.') else ...pending.take(3).map((task) => _TaskTile(task: task, course: store.courses.where((c) => c.id == task.courseId).firstOrNull, onToggle: () => store.toggleTask(task.id), onTap: () => showTaskDetail(context, store, task))),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Akses cepat'),
        const SizedBox(height: 10),
        Row(children: [_QuickAction(icon: Icons.add_task_rounded, label: 'Tambah tugas', onTap: () => showTaskForm(context, store)), const SizedBox(width: 10), _QuickAction(icon: Icons.add_box_rounded, label: 'Tambah kuliah', onTap: () => showCourseForm(context, store)), const SizedBox(width: 10), _QuickAction(icon: Icons.design_services_rounded, label: 'Jasa', onTap: () => showServices(context))]),
      ])))
    ]));
  }

  void _showNotifications(BuildContext context) {
    showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 30), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Notifikasi', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      ListTile(leading: const Icon(Icons.notifications_active_outlined), title: const Text('Pengingat tugas'), subtitle: Text(store.notificationsEnabled ? 'Aktif — deadline akan diingatkan otomatis.' : 'Nonaktif — aktifkan dari Profil.'), trailing: Switch(value: store.notificationsEnabled, onChanged: (value) async { await store.setNotificationsEnabled(value); if (context.mounted) Navigator.pop(context); })),
      ListTile(leading: const Icon(Icons.school_outlined), title: const Text('Pengingat kuliah'), subtitle: Text(store.scheduleNotificationsEnabled ? 'Aktif — 30 menit sebelum kelas.' : 'Nonaktif — aktifkan dari Profil.'), trailing: Switch(value: store.scheduleNotificationsEnabled, onChanged: (value) async { await store.setScheduleNotificationsEnabled(value); if (context.mounted) Navigator.pop(context); })),
    ])));
  }
}

class _HeroCard extends StatelessWidget {
  final AppStore store;
  const _HeroCard({required this.store});

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final secondary = Color.lerp(primary, Colors.white, .18)!;
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 18, 16, 18),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [primary, secondary]),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Semester ${store.profile.semester}', style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 7),
          const Text('Tetap fokus,\nselangkah demi selangkah.', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800, height: 1.14)),
          const SizedBox(height: 12),
          Text('${store.completedTasks} tugas selesai', style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
        ])),
        const SizedBox(width: 12),
        const StudentStairsIllustration(size: 118),
      ]),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _QuickAction({required this.icon, required this.label, required this.onTap});
  @override Widget build(BuildContext c) => Expanded(child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(16), child: Container(padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8), decoration: BoxDecoration(color: Theme.of(c).colorScheme.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Theme.of(c).dividerColor)), child: Column(children: [Icon(icon, color: Theme.of(c).colorScheme.primary), const SizedBox(height: 8), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600))]))));
}

class _MiniDashboardStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _MiniDashboardStat({required this.icon, required this.label, required this.value});
  @override Widget build(BuildContext c) => Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Theme.of(c).colorScheme.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: Theme.of(c).dividerColor)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, size: 18, color: Theme.of(c).colorScheme.primary), const SizedBox(height: 8), Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)), const SizedBox(height: 2), Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: AppTheme.muted))]));
}

class _UpcomingScheduleData { final ScheduleItem item; final Course? course; final DateTime date; const _UpcomingScheduleData(this.item, this.course, this.date); }
_UpcomingScheduleData? _upcomingSchedule(AppStore store) {
  if (store.schedule.isEmpty) return null;
  final now = DateTime.now(); _UpcomingScheduleData? best;
  for (final item in store.schedule) {
    final parts = item.start.split(':'); final hour = int.tryParse(parts.first) ?? 0; final minute = parts.length > 1 ? int.tryParse(parts[1]) ?? 0 : 0;
    var date = DateTime(now.year, now.month, now.day); final daysAhead = (item.weekday - date.weekday + 7) % 7; date = date.add(Duration(days: daysAhead)); date = DateTime(date.year, date.month, date.day, hour, minute);
    if (!date.isAfter(now)) date = date.add(const Duration(days: 7));
    if (best == null || date.isBefore(best.date)) best = _UpcomingScheduleData(item, store.courses.where((c) => c.id == item.courseId).firstOrNull, date);
  }
  return best;
}

class _UpcomingScheduleCard extends StatelessWidget {
  final ScheduleItem item; final Course? course; final DateTime date;
  const _UpcomingScheduleCard({required this.item, required this.course, required this.date});
  @override Widget build(BuildContext context) => Card(child: ListTile(contentPadding: const EdgeInsets.all(14), leading: Container(width: 58, padding: const EdgeInsets.symmetric(vertical: 8), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(14)), child: Column(children: [Text(DateFormat('EEE', 'id_ID').format(date), style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800, fontSize: 12)), const SizedBox(height: 2), Text(DateFormat('HH:mm').format(date), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12))])), title: Text(course?.name ?? 'Mata kuliah', style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${item.start}–${item.end}${item.room.isEmpty ? '' : '  •  ${item.room}'}')));
}
class _EmptyScheduleDashboard extends StatelessWidget {
  const _EmptyScheduleDashboard();
  @override Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(Icons.event_available_outlined, color: Theme.of(context).colorScheme.primary), title: const Text('Belum ada jadwal', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('Tambahkan jadwal kuliah dari tab Jadwal.')));
}

class AgendaPage extends StatefulWidget {
  final AppStore store;
  const AgendaPage({super.key, required this.store});
  @override State<AgendaPage> createState() => _AgendaPageState();
}

class _AgendaPageState extends State<AgendaPage> {
  DateTime selectedDate = DateTime.now();
  DateTime _day(DateTime d) => DateTime(d.year, d.month, d.day);
  List<TaskItem> _tasks() => widget.store.tasks.where((t) => _day(t.dueDate) == _day(selectedDate)).toList()..sort((a,b) => a.dueDate.compareTo(b.dueDate));
  List<ScheduleItem> _classes() => widget.store.schedule.where((s) => s.weekday == selectedDate.weekday).toList()..sort((a,b) => a.start.compareTo(b.start));
  List<ExamItem> _exams() => widget.store.exams.where((e) => _day(e.date) == _day(selectedDate)).toList()..sort((a,b) => a.start.compareTo(b.start));
  bool _hasEvents(DateTime d) => widget.store.tasks.any((t) => _day(t.dueDate) == _day(d)) || widget.store.schedule.any((s) => s.weekday == d.weekday) || widget.store.exams.any((e) => _day(e.date) == _day(d));

  @override Widget build(BuildContext context) {
    final tasks = _tasks();
    final classes = _classes();
    final exams = _exams();
    final today = _day(selectedDate) == _day(DateTime.now());
    return Scaffold(
      appBar: AppBar(title: const Text('Agenda Pintar'), actions: [IconButton(tooltip: 'Hari ini', onPressed: () => setState(() => selectedDate = DateTime.now()), icon: const Icon(Icons.today_outlined))]),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
        Card(child: CalendarDatePicker(initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime(2100), onDateChanged: (d) => setState(() => selectedDate = d))),
        const SizedBox(height: 14),
        Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(12), borderRadius: BorderRadius.circular(16), border: Border.all(color: Theme.of(context).dividerColor)), child: Row(children: [Icon(Icons.event_available_rounded, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 10), Expanded(child: Text('${today ? 'Hari ini • ' : ''}${DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(selectedDate)}', style: const TextStyle(fontWeight: FontWeight.w700)))])),
        const SizedBox(height: 20),
        const SectionTitle(title: 'Kuliah'), const SizedBox(height: 10),
        if (classes.isEmpty)
          const _AgendaEmpty(icon: Icons.school_outlined, text: 'Tidak ada jadwal kuliah pada tanggal ini.')
        else
          ...classes.map((item) => _buildClassCard(context, widget.store, item)),
        const SizedBox(height: 16),
        Row(children: [const Expanded(child: SectionTitle(title: 'Ujian')), Text('${exams.length} ujian', style: const TextStyle(color: AppTheme.muted, fontSize: 12))]),
        const SizedBox(height: 10),
        if (exams.isEmpty)
          const _AgendaEmpty(icon: Icons.assignment_outlined, text: 'Tidak ada ujian pada tanggal ini.')
        else
          ...exams.map((exam) => _buildExamCard(context, widget.store, exam)),
        const SizedBox(height: 16),
        Row(children: [const Expanded(child: SectionTitle(title: 'Deadline tugas')), Text('${tasks.length} tugas', style: const TextStyle(color: AppTheme.muted, fontSize: 12))]),
        const SizedBox(height: 10),
        if (tasks.isEmpty)
          const _AgendaEmpty(icon: Icons.task_alt_rounded, text: 'Tidak ada deadline tugas pada tanggal ini.')
        else
          ...tasks.map((task) => _buildTaskCard(context, widget.store, task)),
        if (!_hasEvents(selectedDate)) ...[const SizedBox(height: 4), Card(child: ListTile(leading: Icon(Icons.auto_awesome_outlined, color: Theme.of(context).colorScheme.primary), title: const Text('Hari ini masih kosong ✨', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('Manfaatkan waktu untuk belajar atau menyelesaikan tugas.')))],
      ]),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => showTaskForm(context, widget.store, initialDate: selectedDate), icon: const Icon(Icons.add_task_rounded), label: const Text('Tambah tugas')),
    );
  }
}

class _AgendaEmpty extends StatelessWidget {
  final IconData icon; final String text;
  const _AgendaEmpty({required this.icon, required this.text});
  @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Theme.of(context).dividerColor)), child: Row(children: [Icon(icon, color: AppTheme.muted, size: 20), const SizedBox(width: 10), Expanded(child: Text(text, style: const TextStyle(color: AppTheme.muted, fontSize: 13)))]));
}

DateTime _dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

ExamItem? _upcomingExam(AppStore store) {
  final now = DateTime.now();
  final list = store.exams.where((e) => _dateOnly(e.date).isAfter(_dateOnly(now)) || _dateOnly(e.date).isAtSameMomentAs(_dateOnly(now))).toList()
    ..sort((a, b) => DateTime(a.date.year, a.date.month, a.date.day, _timeMinutes(a.start) ~/ 60, _timeMinutes(a.start) % 60).compareTo(DateTime(b.date.year, b.date.month, b.date.day, _timeMinutes(b.start) ~/ 60, _timeMinutes(b.start) % 60)));
  return list.isEmpty ? null : list.first;
}

int _timeMinutes(String value) {
  final parts = value.split(':');
  if (parts.length != 2) return 0;
  return (int.tryParse(parts[0]) ?? 0) * 60 + (int.tryParse(parts[1]) ?? 0);
}

Widget _buildExamCard(BuildContext context, AppStore store, ExamItem exam) {
  final course = store.courses.where((c) => c.id == exam.courseId).firstOrNull;
  return Card(child: ListTile(
    leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primary.withAlpha(15), child: Icon(Icons.assignment_outlined, color: Theme.of(context).colorScheme.primary)),
    title: Text('${exam.type} • ${course?.name ?? 'Mata kuliah'}', style: const TextStyle(fontWeight: FontWeight.w700)),
    subtitle: Text('${exam.start}–${exam.end}${exam.room.isEmpty ? '' : ' • Ruang ${exam.room}'}${exam.note.isEmpty ? '' : '\n${exam.note}'}'),
    isThreeLine: exam.note.isNotEmpty,
  ));
}

class _UpcomingExamCard extends StatelessWidget {
  final ExamItem? exam;
  final AppStore store;
  const _UpcomingExamCard({required this.exam, required this.store});
  @override Widget build(BuildContext context) {
    if (exam == null) return Card(child: ListTile(leading: Icon(Icons.event_note_outlined, color: Theme.of(context).colorScheme.primary), title: const Text('Belum ada jadwal ujian', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('Tambahkan UTS atau UAS dari menu Jadwal.')));
    final course = store.courses.where((c) => c.id == exam!.courseId).firstOrNull;
    final today = _dateOnly(DateTime.now());
    final date = _dateOnly(exam!.date);
    final days = date.difference(today).inDays;
    final countdown = days == 0 ? 'Hari ini' : days == 1 ? 'Besok' : '$days hari lagi';
    return Card(child: ListTile(
      contentPadding: const EdgeInsets.all(14),
      leading: Container(width: 48, height: 48, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(14)), child: Icon(Icons.school_outlined, color: Theme.of(context).colorScheme.primary)),
      title: Text('${exam!.type} • ${course?.name ?? 'Mata kuliah'}', style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text('${DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(exam!.date)} • ${exam!.start}–${exam!.end}'),
      trailing: Text(countdown, textAlign: TextAlign.end, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800, fontSize: 12)),
    ));
  }
}

class ExamPage extends StatelessWidget {
  final AppStore store;
  const ExamPage({super.key, required this.store});
  @override Widget build(BuildContext context) {
    final exams = [...store.exams]..sort((a,b) => a.date.compareTo(b.date));
    return PageShell(title: 'Jadwal Ujian', actions: [IconButton(onPressed: () => showExamForm(context, store), icon: const Icon(Icons.add_rounded))], child: exams.isEmpty
      ? EmptyState(icon: Icons.assignment_outlined, title: 'Belum ada jadwal ujian', subtitle: 'Tambahkan UTS, UAS, kuis, atau presentasi agar tidak lupa.', buttonText: 'Tambah Ujian', onPressed: () => showExamForm(context, store))
      : ListView.separated(padding: const EdgeInsets.fromLTRB(20, 8, 20, 28), itemCount: exams.length, separatorBuilder: (_,__) => const SizedBox(height: 10), itemBuilder: (_, i) { final e = exams[i]; final c = store.courses.where((x) => x.id == e.courseId).firstOrNull; return Card(child: ListTile(contentPadding: const EdgeInsets.all(14), leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primary.withAlpha(15), child: Icon(Icons.assignment_outlined, color: Theme.of(context).colorScheme.primary)), title: Text('${e.type} • ${c?.name ?? 'Mata kuliah'}', style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${DateFormat('dd MMM yyyy', 'id_ID').format(e.date)} • ${e.start}–${e.end}${e.room.isEmpty ? '' : ' • ${e.room}'}'), trailing: PopupMenuButton<String>(onSelected: (v) { if (v == 'edit') showExamForm(context, store, exam: e); if (v == 'delete') store.deleteExam(e.id); }, itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'delete', child: Text('Hapus'))]))); })
    );
  }
}

class NotesPage extends StatelessWidget {
  final AppStore store;
  const NotesPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final notes = [...store.notes]..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return PageShell(
      title: 'Catatan Kuliah',
      actions: [
        IconButton(onPressed: () => showNoteForm(context, store), icon: const Icon(Icons.add_rounded)),
      ],
      child: notes.isEmpty
          ? EmptyState(
              icon: Icons.sticky_note_2_outlined,
              title: 'Belum ada catatan',
              subtitle: 'Simpan ringkasan materi, ide tugas, atau catatan penting kuliah di sini.',
              buttonText: 'Buat Catatan',
              onPressed: () => showNoteForm(context, store),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
              itemCount: notes.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final note = notes[i];
                final course = store.courses.where((c) => c.id == note.courseId).firstOrNull;
                final preview = note.content.replaceAll(RegExp(r'\s+'), ' ').trim();
                return Card(
                  child: ListTile(
                    onTap: () => showNoteDetail(context, store, note),
                    contentPadding: const EdgeInsets.all(14),
                    leading: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary.withAlpha(18),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(Icons.sticky_note_2_rounded, color: Theme.of(context).colorScheme.primary),
                    ),
                    title: Text(note.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        [if (course != null) course.name, if (preview.isNotEmpty) preview].join(' • '),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) {
                        if (v == 'edit') showNoteForm(context, store, note: note);
                        if (v == 'delete') _confirmDeleteNote(context, store, note);
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('Edit')),
                        PopupMenuItem(value: 'delete', child: Text('Hapus')),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _confirmDeleteNote(BuildContext context, AppStore store, NoteItem note) => showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Hapus catatan?'),
          content: Text('Catatan "${note.title}" akan dihapus dari perangkat.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
            FilledButton(
              onPressed: () {
                store.deleteNote(note.id);
                Navigator.pop(context);
              },
              child: const Text('Hapus'),
            ),
          ],
        ),
      );
}

void showNoteDetail(BuildContext context, AppStore store, NoteItem note) {
  final course = store.courses.where((c) => c.id == note.courseId).firstOrNull;
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(note.title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
            IconButton(onPressed: () { Navigator.pop(ctx); showNoteForm(context, store, note: note); }, icon: const Icon(Icons.edit_outlined)),
          ]),
          if (course != null) ...[
            const SizedBox(height: 4),
            Text(course.name, style: TextStyle(color: Theme.of(ctx).colorScheme.primary, fontWeight: FontWeight.w600)),
          ],
          const SizedBox(height: 16),
          Text(note.content.isEmpty ? 'Catatan ini masih kosong.' : note.content, style: const TextStyle(fontSize: 15, height: 1.55)),
          const SizedBox(height: 18),
          Text('Diperbarui ${DateFormat('dd MMM yyyy • HH:mm', 'id_ID').format(note.updatedAt)}', style: const TextStyle(color: AppTheme.muted, fontSize: 11)),
        ]),
      ),
    ),
  );
}

Future<void> showNoteForm(BuildContext context, AppStore store, {NoteItem? note}) async {
  final title = TextEditingController(text: note?.title ?? '');
  final content = TextEditingController(text: note?.content ?? '');
  String courseId = note?.courseId ?? '';
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(
      builder: (_, set) => _FormSheet(
        title: note == null ? 'Catatan Baru' : 'Edit Catatan',
        children: [
          TextField(controller: title, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Judul catatan', prefixIcon: Icon(Icons.title_rounded))),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            initialValue: courseId,
            decoration: const InputDecoration(labelText: 'Mata kuliah (opsional)', prefixIcon: Icon(Icons.menu_book_outlined)),
            items: [const DropdownMenuItem(value: '', child: Text('Umum')),...store.courses.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name)))],
            onChanged: (v) => set(() => courseId = v ?? ''),
          ),
          const SizedBox(height: 10),
          TextField(controller: content, minLines: 8, maxLines: 14, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Isi catatan', alignLabelWithHint: true, prefixIcon: Icon(Icons.notes_rounded)),),
          const SizedBox(height: 18),
          PrimaryButton(
            label: 'Simpan Catatan',
            onPressed: () {
              if (title.text.trim().isEmpty) return;
              final now = DateTime.now();
              if (note == null) {
                store.addNote(NoteItem(id: now.microsecondsSinceEpoch.toString(), title: title.text.trim(), content: content.text.trim(), courseId: courseId, updatedAt: now));
              } else {
                store.updateNote(note.copyWith(title: title.text.trim(), content: content.text.trim(), courseId: courseId, updatedAt: now));
              }
              Navigator.pop(ctx);
            },
          ),
        ],
      ),
    ),
  );
  title.dispose();
  content.dispose();
}

class ResourcesPage extends StatelessWidget {
  final AppStore store;
  const ResourcesPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final items = [...store.resources]..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return Scaffold(
      appBar: AppBar(title: const Text('Pusat Dokumen & Link'), actions: [IconButton(onPressed: () => showResourceForm(context, store), icon: const Icon(Icons.add_rounded))]),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 28),
        children: [
          Card(child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [
            Container(width: 50, height: 50, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(15)), child: Icon(Icons.folder_copy_rounded, color: Theme.of(context).colorScheme.primary, size: 27)),
            const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Semua materi di satu tempat', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), const SizedBox(height: 4), const Text('Simpan link Google Drive, Classroom, Canva, atau sumber kuliah lainnya.', style: TextStyle(color: AppTheme.muted, height: 1.35))])),
          ]))),
          const SizedBox(height: 18),
          Row(children: [const Expanded(child: SectionTitle(title: 'Materi & Link')), Text('${items.length} tersimpan', style: const TextStyle(color: AppTheme.muted, fontSize: 12))]),
          const SizedBox(height: 10),
          if (items.isEmpty)
            EmptyState(icon: Icons.link_rounded, title: 'Belum ada dokumen atau link', subtitle: 'Simpan link materi supaya tidak perlu mencarinya lagi.', buttonText: 'Tambah Link', onPressed: () => showResourceForm(context, store))
          else
            ...items.map((item) => _ResourceTile(store: store, item: item)),
        ],
      ),
      floatingActionButton: items.isEmpty ? null : FloatingActionButton.extended(onPressed: () => showResourceForm(context, store), icon: const Icon(Icons.add_link_rounded), label: const Text('Tambah Link')),
    );
  }
}

class _ResourceTile extends StatelessWidget {
  final AppStore store;
  final ResourceItem item;
  const _ResourceTile({required this.store, required this.item});

  Future<void> _open(BuildContext context) async {
    final uri = Uri.tryParse(item.url);
    if (uri == null || (uri.scheme != 'http' && uri.scheme != 'https')) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Link tidak valid. Gunakan http:// atau https://.')));
      return;
    }
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Link tidak dapat dibuka di perangkat ini.')));
  }

  @override
  Widget build(BuildContext context) {
    final course = store.courses.where((c) => c.id == item.courseId).firstOrNull;
    return Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(
      onTap: () => _open(context),
      contentPadding: const EdgeInsets.all(13),
      leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(13)), child: Icon(Icons.link_rounded, color: Theme.of(context).colorScheme.primary)),
      title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text([item.type, if (course != null) course.name, if (item.note.isNotEmpty) item.note].join(' • '), maxLines: 2, overflow: TextOverflow.ellipsis),
      trailing: PopupMenuButton<String>(onSelected: (value) { if (value == 'open') _open(context); if (value == 'edit') showResourceForm(context, store, item: item); if (value == 'delete') _confirmDeleteResource(context, store, item); }, itemBuilder: (_) => const [PopupMenuItem(value: 'open', child: Text('Buka link')), PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'delete', child: Text('Hapus'))]),
    ));
  }
}

void _confirmDeleteResource(BuildContext context, AppStore store, ResourceItem item) {
  showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Hapus link?'), content: Text('"${item.title}" akan dihapus dari Pusat Dokumen & Link.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')), FilledButton(onPressed: () { store.deleteResource(item.id); Navigator.pop(context); }, child: const Text('Hapus'))]));
}

Future<void> showResourceForm(BuildContext context, AppStore store, {ResourceItem? item}) async {
  final title = TextEditingController(text: item?.title ?? '');
  final url = TextEditingController(text: item?.url ?? '');
  final note = TextEditingController(text: item?.note ?? '');
  String courseId = item?.courseId ?? '';
  String type = item?.type ?? 'Link';
  final types = ['Materi', 'Google Drive', 'Google Classroom', 'Canva', 'Link'];
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(builder: (_, set) => _FormSheet(title: item == null ? 'Tambah Link' : 'Edit Link', children: [
      TextField(controller: title, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Nama dokumen/link', prefixIcon: Icon(Icons.title_rounded))),
      const SizedBox(height: 10),
      TextField(controller: url, keyboardType: TextInputType.url, textInputAction: TextInputAction.next, autocorrect: false, decoration: const InputDecoration(labelText: 'URL', hintText: 'https://...', prefixIcon: Icon(Icons.link_rounded))),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(initialValue: type, decoration: const InputDecoration(labelText: 'Jenis', prefixIcon: Icon(Icons.category_outlined)), items: types.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => set(() => type = v ?? type)),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(initialValue: courseId, decoration: const InputDecoration(labelText: 'Mata kuliah (opsional)', prefixIcon: Icon(Icons.menu_book_outlined)), items: [const DropdownMenuItem(value: '', child: Text('Umum')), ...store.courses.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name)))], onChanged: (v) => set(() => courseId = v ?? '')),
      const SizedBox(height: 10),
      TextField(controller: note, minLines: 2, maxLines: 4, decoration: const InputDecoration(labelText: 'Keterangan (opsional)', alignLabelWithHint: true, prefixIcon: Icon(Icons.notes_outlined))),
      const SizedBox(height: 18),
      PrimaryButton(label: item == null ? 'Simpan Link' : 'Simpan Perubahan', onPressed: () {
        final value = url.text.trim();
        final uri = Uri.tryParse(value);
        if (title.text.trim().isEmpty || uri == null || (uri.scheme != 'http' && uri.scheme != 'https')) return;
        final now = DateTime.now();
        final next = ResourceItem(id: item?.id ?? now.microsecondsSinceEpoch.toString(), title: title.text.trim(), url: value, courseId: courseId, type: type, note: note.text.trim(), updatedAt: now);
        if (item == null) { store.addResource(next); } else { store.updateResource(next); }
        Navigator.pop(ctx);
      }),
    ])),
  );
  title.dispose(); url.dispose(); note.dispose();
}

class CoursesPage extends StatelessWidget {
  final AppStore store;
  const CoursesPage({super.key, required this.store});
  @override Widget build(BuildContext context) => PageShell(title: 'Mata Kuliah', actions: [IconButton(onPressed: () => showCourseForm(context, store), icon: const Icon(Icons.add_rounded))], child: store.courses.isEmpty ? EmptyState(icon: Icons.menu_book_outlined, title: 'Belum ada mata kuliah', subtitle: 'Tambahkan mata kuliah agar jadwal, tugas, dan IPK saling terhubung.', buttonText: 'Tambah Mata Kuliah', onPressed: () => showCourseForm(context, store)) : ListView.separated(padding: const EdgeInsets.fromLTRB(20, 8, 20, 24), itemCount: store.courses.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (_, i) { final c = store.courses[i]; final taskCount = store.tasks.where((t) => t.courseId == c.id && !t.completed).length; final grade = store.grades.where((g) => g.courseId == c.id).firstOrNull; return Card(child: ListTile(onTap: () => Navigator.push(context, MotionPageRoute(builder: (_) => CourseDetailPage(store: store, course: c))), contentPadding: const EdgeInsets.all(12), leading: Container(width: 46, height: 46, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(18), borderRadius: BorderRadius.circular(14)), child: Icon(Icons.menu_book_rounded, color: Theme.of(context).colorScheme.primary)), title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${c.code}  •  ${c.credits} SKS${c.lecturer.isEmpty ? '' : '  •  ${c.lecturer}'}\n$taskCount tugas aktif${grade == null ? '' : '  •  Nilai ${grade.letter}'}'), isThreeLine: true, trailing: PopupMenuButton<String>(onSelected: (v) { if (v == 'detail') Navigator.push(context, MotionPageRoute(builder: (_) => CourseDetailPage(store: store, course: c))); if (v == 'edit') showCourseForm(context, store, course: c); if (v == 'delete') _confirmDelete(context, c); }, itemBuilder: (_) => const [PopupMenuItem(value: 'detail', child: Text('Lihat detail')), PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'delete', child: Text('Hapus'))]))); }));
  void _confirmDelete(BuildContext context, Course c) => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Hapus mata kuliah?'), content: Text('Data tugas, nilai, dan jadwal yang terkait dengan ${c.name} juga akan dihapus.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')), FilledButton(onPressed: () { store.deleteCourse(c.id); Navigator.pop(context); }, child: const Text('Hapus'))]));
}

class CourseDetailPage extends StatelessWidget {
  final AppStore store;
  final Course course;
  const CourseDetailPage({super.key, required this.store, required this.course});

  @override
  Widget build(BuildContext context) {
    final tasks = store.tasks.where((t) => t.courseId == course.id).toList()
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    final schedules = store.schedule.where((s) => s.courseId == course.id).toList()
      ..sort((a, b) => a.weekday == b.weekday ? a.start.compareTo(b.start) : a.weekday.compareTo(b.weekday));
    final exams = store.exams.where((e) => e.courseId == course.id).toList()
      ..sort((a, b) => DateTime(a.date.year, a.date.month, a.date.day).compareTo(DateTime(b.date.year, b.date.month, b.date.day)));
    final grade = store.grades.where((g) => g.courseId == course.id).firstOrNull;

    return Scaffold(
      appBar: AppBar(title: const Text('Detail Mata Kuliah')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(22)),
            child: Row(children: [
              Container(width: 56, height: 56, decoration: BoxDecoration(color: Colors.white.withAlpha(28), borderRadius: BorderRadius.circular(17)), child: const Icon(Icons.menu_book_rounded, color: Colors.white, size: 28)),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(course.name, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('${course.code} • ${course.credits} SKS', style: const TextStyle(color: Colors.white70)),
              ])),
            ]),
          ),
          const SizedBox(height: 16),
          _InfoCard(icon: Icons.person_outline_rounded, title: 'Dosen', value: course.lecturer.isEmpty ? 'Belum diisi' : course.lecturer),
          const SizedBox(height: 18),
          const SectionTitle(title: 'Absensi'),
          const SizedBox(height: 10),
          _AttendanceSummaryCard(store: store, course: course),
          const SizedBox(height: 18),
          const SectionTitle(title: 'Jadwal Ujian'),
          const SizedBox(height: 10),
          _CourseExamSection(store: store, course: course, exams: exams),
          if (schedules.isNotEmpty) ...[
            const SizedBox(height: 18),
            const SectionTitle(title: 'Jadwal kuliah'),
            const SizedBox(height: 10),
            ...schedules.map((s) => Card(child: ListTile(
              leading: const Icon(Icons.schedule_rounded),
              title: Text(_weekdayName(s.weekday), style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${s.start}–${s.end}${s.room.isEmpty ? '' : '  •  ${s.room}'}'),
            ))),
          ],
          const SizedBox(height: 18),
          const SectionTitle(title: 'Nilai'),
          const SizedBox(height: 10),
          Card(child: ListTile(
            contentPadding: const EdgeInsets.all(14),
            leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primary.withAlpha(15), child: Text(grade?.letter ?? '-', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800))),
            title: Text(grade == null ? 'Belum ada nilai' : 'Nilai akhir ${grade.score.toStringAsFixed(1)}', style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(grade == null ? 'Isi komponen nilai untuk menghitung grade.' : 'Tugas 30% • UTS 30% • UAS 30% • Kehadiran 10%'),
            trailing: TextButton(onPressed: () => showGradeForm(context, store, course), child: Text(grade == null ? 'Isi nilai' : 'Edit')),
          )),
          const SizedBox(height: 18),
          Row(children: [
            const Expanded(child: SectionTitle(title: 'Tugas')),
            Text('${tasks.where((t) => !t.completed).length} aktif', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
          ]),
          const SizedBox(height: 10),
          if (tasks.isEmpty)
            const EmptyState(icon: Icons.task_alt_rounded, title: 'Belum ada tugas', subtitle: 'Tambahkan tugas untuk mata kuliah ini dari Home.')
          else
            ...tasks.map((task) => _TaskTile(task: task, course: course, onToggle: () => store.toggleTask(task.id), onTap: () => showTaskDetail(context, store, task))),
        ],
      ),
    );
  }
}

class _CourseExamSection extends StatelessWidget {
  final AppStore store;
  final Course course;
  final List<ExamItem> exams;
  const _CourseExamSection({required this.store, required this.course, required this.exams});

  String _countdown(ExamItem exam) {
    final today = DateTime.now();
    final target = DateTime(exam.date.year, exam.date.month, exam.date.day);
    final current = DateTime(today.year, today.month, today.day);
    final days = target.difference(current).inDays;
    if (days == 0) return 'Hari ini';
    if (days == 1) return 'Besok';
    if (days < 0) return 'Sudah lewat';
    return '$days hari lagi';
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 44, height: 44, decoration: BoxDecoration(color: primary.withAlpha(15), borderRadius: BorderRadius.circular(13)), child: Icon(Icons.assignment_rounded, color: primary)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(exams.isEmpty ? 'Belum ada jadwal ujian' : '${exams.length} jadwal ujian', style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 3),
              Text(exams.isEmpty ? 'Simpan UTS, UAS, kuis, atau presentasi di sini.' : 'UTS/UAS dan ujian lainnya untuk mata kuliah ini.', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
            ])),
          ]),
          if (exams.isNotEmpty) ...[
            const SizedBox(height: 14),
            ...exams.map((e) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: primary.withAlpha(8), borderRadius: BorderRadius.circular(14), border: Border.all(color: primary.withAlpha(18))),
              child: Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7), decoration: BoxDecoration(color: primary, borderRadius: BorderRadius.circular(10)), child: Text(e.type, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800))),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(e.date), style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text('${e.start}–${e.end}${e.room.isEmpty ? '' : ' • ${e.room}'}', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
                ])),
                Text(_countdown(e), textAlign: TextAlign.end, style: TextStyle(color: primary, fontSize: 11, fontWeight: FontWeight.w800)),
              ]),
            )),
          ],
          const SizedBox(height: 6),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            onPressed: () => showExamForm(context, store, initialCourse: course),
            icon: const Icon(Icons.add_rounded),
            label: Text(exams.isEmpty ? 'Tambah Jadwal Ujian' : 'Tambah Ujian Lain'),
          )),
          if (exams.isNotEmpty) ...[
            const SizedBox(height: 4),
            SizedBox(width: double.infinity, child: TextButton.icon(
              onPressed: () => Navigator.push(context, MotionPageRoute(builder: (_) => ExamPage(store: store))),
              icon: const Icon(Icons.calendar_month_outlined, size: 18),
              label: const Text('Lihat semua jadwal ujian'),
            )),
          ],
        ]),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget { final IconData icon; final String title; final String value; const _InfoCard({required this.icon, required this.title, required this.value}); @override Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon, color: Theme.of(context).colorScheme.primary), title: Text(title, style: const TextStyle(fontSize: 12, color: AppTheme.muted)), subtitle: Text(value, style: const TextStyle(fontWeight: FontWeight.w700)))); }
String _weekdayName(int day) => const ['', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'][day.clamp(1, 7).toInt()];


class _AttendanceSummaryCard extends StatelessWidget {
  final AppStore store;
  final Course course;
  const _AttendanceSummaryCard({required this.store, required this.course});

  @override
  Widget build(BuildContext context) {
    final items = store.attendanceForCourse(course.id);
    final present = items.where((e) => e.status == 'Hadir').length;
    final permission = items.where((e) => e.status == 'Izin').length;
    final sick = items.where((e) => e.status == 'Sakit').length;
    final absent = items.where((e) => e.status == 'Alpha').length;
    final percentage = store.attendancePercentage(course.id);
    final progress = (percentage / 100).clamp(0.0, 1.0).toDouble();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${percentage.toStringAsFixed(0)}%', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.primary)),
                      const SizedBox(height: 2),
                      Text(items.isEmpty ? 'Belum ada pertemuan' : '${items.length} pertemuan tercatat', style: const TextStyle(color: AppTheme.muted)),
                    ],
                  ),
                ),
                FilledButton.icon(
                  onPressed: () => Navigator.push(context, MotionPageRoute(builder: (_) => AttendancePage(store: store, course: course))),
                  icon: const Icon(Icons.edit_calendar_rounded, size: 18),
                  label: Text(items.isEmpty ? 'Catat' : 'Kelola'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: progress, minHeight: 8)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _AttendanceMiniStat(icon: Icons.check_circle_outline_rounded, label: 'Hadir', value: '$present'),
                _AttendanceMiniStat(icon: Icons.event_note_rounded, label: 'Izin', value: '$permission'),
                _AttendanceMiniStat(icon: Icons.healing_rounded, label: 'Sakit', value: '$sick'),
                _AttendanceMiniStat(icon: Icons.cancel_outlined, label: 'Alpha', value: '$absent'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AttendanceMiniStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _AttendanceMiniStat({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(10), borderRadius: BorderRadius.circular(12)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 15, color: Theme.of(context).colorScheme.primary),
      const SizedBox(width: 5),
      Text('$value $label', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
    ]),
  );
}

class AttendancePage extends StatefulWidget {
  final AppStore store;
  final Course course;
  const AttendancePage({super.key, required this.store, required this.course});

  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  @override
  Widget build(BuildContext context) {
    final items = widget.store.attendanceForCourse(widget.course.id);
    final percentage = widget.store.attendancePercentage(widget.course.id);
    final present = items.where((e) => e.status == 'Hadir').length;
    final permission = items.where((e) => e.status == 'Izin').length;
    final sick = items.where((e) => e.status == 'Sakit').length;
    final absent = items.where((e) => e.status == 'Alpha').length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Absensi Kuliah'),
        actions: [
          IconButton(onPressed: () => showAttendanceForm(context, widget.store, widget.course), icon: const Icon(Icons.add_rounded)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 28),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.course.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('${widget.course.code} • ${widget.course.credits} SKS', style: const TextStyle(color: AppTheme.muted)),
                const SizedBox(height: 18),
                Row(children: [
                  Text('${percentage.toStringAsFixed(0)}%', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.primary)),
                  const SizedBox(width: 10),
                  const Text('kehadiran', style: TextStyle(color: AppTheme.muted)),
                ]),
                const SizedBox(height: 10),
                LinearProgressIndicator(value: (percentage / 100).clamp(0.0, 1.0).toDouble(), minHeight: 8),
                const SizedBox(height: 14),
                Text('$present Hadir • $permission Izin • $sick Sakit • $absent Alpha', style: const TextStyle(fontSize: 12, color: AppTheme.muted)),
              ]),
            ),
          ),
          const SizedBox(height: 18),
          Row(children: [const Expanded(child: SectionTitle(title: 'Riwayat Pertemuan')), Text('${items.length} data', style: const TextStyle(color: AppTheme.muted, fontSize: 12))]),
          const SizedBox(height: 10),
          if (items.isEmpty)
            const EmptyState(icon: Icons.fact_check_outlined, title: 'Belum ada absensi', subtitle: 'Catat kehadiran setiap kali mengikuti perkuliahan.', buttonText: 'Catat Kehadiran', onPressed: null)
          else
            ...items.map((item) => _AttendanceHistoryTile(store: widget.store, course: widget.course, item: item, onChanged: () => setState(() {}))),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async { await showAttendanceForm(context, widget.store, widget.course); if (mounted) setState(() {}); },
        icon: const Icon(Icons.add_rounded),
        label: const Text('Catat Kehadiran'),
      ),
    );
  }
}

class _AttendanceHistoryTile extends StatelessWidget {
  final AppStore store;
  final Course course;
  final AttendanceItem item;
  final VoidCallback onChanged;
  const _AttendanceHistoryTile({required this.store, required this.course, required this.item, required this.onChanged});

  Color _statusColor(BuildContext context) {
    switch (item.status) {
      case 'Hadir': return Colors.green;
      case 'Izin': return Colors.orange;
      case 'Sakit': return Colors.blue;
      default: return Colors.red;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _statusColor(context);
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
        leading: CircleAvatar(backgroundColor: color.withAlpha(18), child: Icon(item.status == 'Hadir' ? Icons.check_rounded : item.status == 'Alpha' ? Icons.close_rounded : Icons.event_note_rounded, color: color)),
        title: Text(DateFormat('EEEE, d MMMM yyyy', 'id_ID').format(item.date), style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(item.note.isEmpty ? item.status : '${item.status} • ${item.note}'),
        trailing: PopupMenuButton<String>(
          onSelected: (value) async {
            if (value == 'edit') {
              await showAttendanceForm(context, store, course, item: item);
              if (!context.mounted) return;
              onChanged();
              return;
            }
            if (value == 'delete') {
              final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Hapus absensi?'), content: Text('Catatan ${DateFormat('d MMM yyyy', 'id_ID').format(item.date)} akan dihapus.'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus'))]));
              if (ok == true) { await store.deleteAttendance(item.id); onChanged(); }
            }
          },
          itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'delete', child: Text('Hapus'))],
        ),
      ),
    );
  }
}

Future<void> showAttendanceForm(BuildContext context, AppStore store, Course course, {AttendanceItem? item}) async {
  final note = TextEditingController(text: item?.note ?? '');
  DateTime selectedDate = item?.date ?? DateTime.now();
  String status = item?.status ?? 'Hadir';
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(builder: (ctx, setSheetState) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(ctx).bottom),
      child: SingleChildScrollView(child: Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 28), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(item == null ? 'Catat Kehadiran' : 'Edit Kehadiran', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text(course.name, style: const TextStyle(color: AppTheme.muted)),
        const SizedBox(height: 18),
        InkWell(
          onTap: () async { final picked = await showDatePicker(context: ctx, initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime(2100)); if (picked != null) setSheetState(() => selectedDate = picked); },
          borderRadius: BorderRadius.circular(14),
          child: InputDecorator(decoration: const InputDecoration(labelText: 'Tanggal', prefixIcon: Icon(Icons.calendar_today_rounded)), child: Text(DateFormat('EEEE, d MMMM yyyy', 'id_ID').format(selectedDate))),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(initialValue: status, decoration: const InputDecoration(labelText: 'Status', prefixIcon: Icon(Icons.fact_check_outlined)), items: const [DropdownMenuItem(value: 'Hadir', child: Text('Hadir')), DropdownMenuItem(value: 'Izin', child: Text('Izin')), DropdownMenuItem(value: 'Sakit', child: Text('Sakit')), DropdownMenuItem(value: 'Alpha', child: Text('Alpha'))], onChanged: (v) => setSheetState(() => status = v ?? 'Hadir')),
        const SizedBox(height: 12),
        TextField(controller: note, maxLines: 3, decoration: const InputDecoration(labelText: 'Catatan (opsional)', hintText: 'Contoh: Materi pertemuan 5')),
        const SizedBox(height: 18),
        PrimaryButton(label: item == null ? 'Simpan Kehadiran' : 'Simpan Perubahan', onPressed: () async {
          final saved = AttendanceItem(id: item?.id ?? DateTime.now().microsecondsSinceEpoch.toString(), courseId: course.id, date: selectedDate, status: status, note: note.text.trim());
          if (item == null) {
            await store.addAttendance(saved);
          } else {
            await store.updateAttendance(saved);
          }
          if (ctx.mounted) Navigator.pop(ctx);
        }),
      ]))),
    )),
  );
  note.dispose();
}

class SchedulePage extends StatefulWidget { final AppStore store; const SchedulePage({super.key, required this.store}); @override State<SchedulePage> createState() => _SchedulePageState(); }
class _SchedulePageState extends State<SchedulePage> {
  int day = DateTime.now().weekday;

  @override
  Widget build(BuildContext context) {
    final items = widget.store.schedule.where((s) => s.weekday == day).toList()
      ..sort((a, b) => a.start.compareTo(b.start));
    return PageShell(
      title: 'Jadwal Mingguan',
      actions: [
        IconButton(tooltip: 'Jadwal ujian', onPressed: () => Navigator.push(context, MotionPageRoute(builder: (_) => ExamPage(store: widget.store))), icon: const Icon(Icons.assignment_outlined)),
        IconButton(onPressed: () => showScheduleForm(context, widget.store), icon: const Icon(Icons.add_rounded)),
      ],
      child: Column(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Row(
              children: List.generate(7, (i) {
                final d = i + 1;
                const names = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
                final count = widget.store.schedule.where((s) => s.weekday == d).length;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(names[i]),
                        if (count > 0) ...[
                          const SizedBox(width: 5),
                          Text('$count', style: const TextStyle(fontSize: 10)),
                        ],
                      ],
                    ),
                    selected: day == d,
                    onSelected: (_) => setState(() => day = d),
                  ),
                );
              }),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
            child: Row(
              children: [
                Expanded(child: Text(_weekdayName(day), style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
                Text('${items.length} kelas', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
              ],
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? EmptyState(
                    icon: Icons.event_available_outlined,
                    title: 'Tidak ada kelas',
                    subtitle: 'Hari ini kamu belum punya jadwal kuliah.',
                    buttonText: 'Tambah Jadwal',
                    onPressed: () => showScheduleForm(context, widget.store),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) => _scheduleCard(context, items[i]),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _scheduleCard(BuildContext context, ScheduleItem item) {
    final course = widget.store.courses.where((x) => x.id == item.courseId).firstOrNull;
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(15),
        leading: Container(
          width: 64,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withAlpha(15),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            children: [
              Text(item.start, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800, fontSize: 12)),
              const SizedBox(height: 2),
              const Icon(Icons.arrow_downward_rounded, size: 12),
              Text(item.end, style: const TextStyle(color: AppTheme.muted, fontSize: 10)),
            ],
          ),
        ),
        title: Text(course?.name ?? 'Mata kuliah', style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text([
            course?.code,
            if (item.room.isNotEmpty) 'Ruang ${item.room}',
          ].whereType<String>().where((x) => x.isNotEmpty).join(' • ')),
        ),
        trailing: IconButton(
          onPressed: () => widget.store.deleteSchedule(item.id),
          icon: const Icon(Icons.delete_outline_rounded),
        ),
      ),
    );
  }
}

class ProgressPage extends StatelessWidget {
  final AppStore store;
  const ProgressPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final totalTasks = store.tasks.length;
    final doneTasks = store.completedTasks;
    final taskProgress = totalTasks == 0 ? 0.0 : doneTasks / totalTasks;
    final graded = store.gradedCourses;
    final targetGap = store.targetGpa - store.gpa;
    final attendanceCourses = store.courses.where((c) => store.attendanceForCourse(c.id).isNotEmpty).toList();
    final averageAttendance = attendanceCourses.isEmpty
        ? 0.0
        : attendanceCourses.map((c) => store.attendancePercentage(c.id)).reduce((a, b) => a + b) / attendanceCourses.length;
    final upcomingExams = store.exams.where((e) => !_dateOnly(e.date).isBefore(_dateOnly(DateTime.now()))).length;
    final examsNext7Days = store.exams.where((e) {
      final days = _dateOnly(e.date).difference(_dateOnly(DateTime.now())).inDays;
      return days >= 0 && days <= 7;
    }).length;
    final checklistTotal = store.tasks.fold<int>(0, (sum, task) => sum + task.checklist.length);
    final checklistDone = store.tasks.fold<int>(0, (sum, task) => sum + task.checklist.where((item) => item.completed).length);
    final checklistProgress = checklistTotal == 0 ? 0.0 : checklistDone / checklistTotal;

    return PageShell(
      title: 'Ringkasan Semester',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
        children: [
          _SemesterOverviewCard(
            store: store,
            taskProgress: taskProgress,
            averageAttendance: averageAttendance,
            graded: graded,
            checklistProgress: checklistProgress,
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: _AcademicStatCard(title: 'IP Semester', value: store.gpa.toStringAsFixed(2), icon: Icons.school_rounded)),
            const SizedBox(width: 10),
            Expanded(child: _AcademicStatCard(title: 'Kehadiran', value: attendanceCourses.isEmpty ? '-' : '${averageAttendance.round()}%', icon: Icons.fact_check_outlined)),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _AcademicStatCard(title: 'Tugas selesai', value: '$doneTasks/$totalTasks', icon: Icons.task_alt_rounded)),
            const SizedBox(width: 10),
            Expanded(child: _AcademicStatCard(title: 'SKS', value: '${store.totalCredits}', icon: Icons.menu_book_outlined)),
          ]),
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.insights_rounded, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(width: 10),
                  const Expanded(child: Text('Status semester', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
                ]),
                const SizedBox(height: 14),
                _StatusRow(icon: Icons.assignment_outlined, label: 'Ujian terjadwal', value: '$upcomingExams ujian',
                    detail: examsNext7Days > 0 ? '$examsNext7Days dalam 7 hari' : 'Belum ada dalam 7 hari'),
                const SizedBox(height: 12),
                _StatusRow(icon: Icons.checklist_rounded, label: 'Checklist tugas', value: checklistTotal == 0 ? 'Belum ada' : '$checklistDone/$checklistTotal selesai',
                    detail: checklistTotal == 0 ? 'Tambahkan checklist ke tugasmu' : '${(checklistProgress * 100).round()}% progres'),
                const SizedBox(height: 12),
                _StatusRow(icon: Icons.grade_outlined, label: 'Nilai', value: '$graded/${store.courses.length} mata kuliah',
                    detail: graded == store.courses.length && store.courses.isNotEmpty ? 'Semua sudah dinilai' : 'Masih ada yang belum diisi'),
              ]),
            ),
          ),
          const SizedBox(height: 18),
          const SectionTitle(title: 'Yang perlu diperhatikan'),
          const SizedBox(height: 10),
          _AttentionCard(store: store, attendanceCourses: attendanceCourses),
          const SizedBox(height: 22),
          Card(
            child: ListTile(
              contentPadding: const EdgeInsets.all(15),
              leading: Icon(Icons.flag_outlined, color: Theme.of(context).colorScheme.primary),
              title: const Text('Target IP', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(targetGap <= 0
                  ? 'Target ${store.targetGpa.toStringAsFixed(2)} tercapai 🎉'
                  : 'Target ${store.targetGpa.toStringAsFixed(2)} • kurang ${targetGap.toStringAsFixed(2)} poin'),
              trailing: IconButton(onPressed: () => showTargetGpaForm(context, store), icon: const Icon(Icons.edit_outlined)),
            ),
          ),
          const SizedBox(height: 22),
          const SectionTitle(title: 'Progress tugas'),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                Row(children: [
                  Expanded(child: Text('$doneTasks dari $totalTasks tugas selesai', style: const TextStyle(fontWeight: FontWeight.w700))),
                  Text('${(taskProgress * 100).round()}%', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800)),
                ]),
                const SizedBox(height: 10),
                LinearProgressIndicator(value: taskProgress, minHeight: 8, borderRadius: BorderRadius.circular(10)),
                const SizedBox(height: 14),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Belum mulai ${store.notStartedTasks}', style: const TextStyle(fontSize: 11, color: AppTheme.muted)),
                  Text('Proses ${store.inProgressTasks}', style: const TextStyle(fontSize: 11, color: AppTheme.muted)),
                  Text('Selesai ${store.completedTasks}', style: const TextStyle(fontSize: 11, color: AppTheme.muted)),
                ]),
              ]),
            ),
          ),
          const SizedBox(height: 24),
          const SectionTitle(title: 'Nilai per mata kuliah'),
          const SizedBox(height: 10),
          if (store.courses.isEmpty)
            const EmptyState(icon: Icons.grade_outlined, title: 'Belum ada data', subtitle: 'Tambahkan mata kuliah terlebih dahulu.')
          else
            ...store.courses.map((course) {
              final grade = store.grades.where((g) => g.courseId == course.id).firstOrNull;
              final attendance = store.attendanceForCourse(course.id);
              final attendanceText = attendance.isEmpty ? 'Absensi belum dicatat' : 'Kehadiran ${store.attendancePercentage(course.id).round()}%';
              return _CourseGradeCard(store: store, course: course, grade: grade, attendanceText: attendanceText);
            }),
        ],
      ),
    );
  }
}

class _CourseGradeCard extends StatelessWidget {
  final AppStore store;
  final Course course;
  final GradeItem? grade;
  final String attendanceText;
  const _CourseGradeCard({required this.store, required this.course, required this.grade, required this.attendanceText});

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 10, 14),
        child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: primary.withAlpha(15),
            child: Text(grade?.letter ?? '-', style: TextStyle(color: primary, fontWeight: FontWeight.w800, fontSize: 15)),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(course.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            const SizedBox(height: 4),
            Text(grade == null ? '${course.credits} SKS  •  Nilai belum diisi' : '${course.credits} SKS  •  Nilai ${grade!.score.toStringAsFixed(1)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppTheme.muted, fontSize: 11)),
            const SizedBox(height: 3),
            Text(attendanceText, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: primary, fontSize: 11, fontWeight: FontWeight.w600)),
          ])),
          const SizedBox(width: 8),
          FilledButton.tonal(onPressed: () => showGradeForm(context, store, course), child: Text(grade?.letter ?? 'Isi')),
        ]),
      ),
    );
  }
}

class _SemesterOverviewCard extends StatelessWidget {
  final AppStore store;
  final double taskProgress;
  final double averageAttendance;
  final int graded;
  final double checklistProgress;
  const _SemesterOverviewCard({required this.store, required this.taskProgress, required this.averageAttendance, required this.graded, required this.checklistProgress});

  @override
  Widget build(BuildContext context) {
    final overall = (taskProgress * .4) + ((averageAttendance / 100) * .3) + ((store.courses.isEmpty ? 0 : graded / store.courses.length) * .3);
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(22)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Semester kamu', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 4),
            Text('Semester ${store.profile.semester}', style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text('${store.courses.length} mata kuliah • ${store.totalCredits} SKS', style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ])),
          Container(width: 68, height: 68, decoration: BoxDecoration(color: Colors.white.withAlpha(28), shape: BoxShape.circle), child: Stack(alignment: Alignment.center, children: [
            CircularProgressIndicator(value: overall.clamp(0, 1).toDouble(), color: Colors.white, backgroundColor: Colors.white24, strokeWidth: 7),
            Text('${(overall * 100).round()}%', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)),
          ])),
        ]),
        const SizedBox(height: 18),
        const Text('Gambaran performa dari tugas, kehadiran, dan kelengkapan nilai.', style: TextStyle(color: Colors.white70, fontSize: 12)),
      ]),
    );
  }
}

class _StatusRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String detail;
  const _StatusRow({required this.icon, required this.label, required this.value, required this.detail});
  @override
  Widget build(BuildContext context) => Row(children: [
    Container(width: 40, height: 40, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: Theme.of(context).colorScheme.primary, size: 20)),
    const SizedBox(width: 10),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 2), Text(detail, style: const TextStyle(fontSize: 11, color: AppTheme.muted))])),
    Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
  ]);
}

class _AttentionCard extends StatelessWidget {
  final AppStore store;
  final List<Course> attendanceCourses;
  const _AttentionCard({required this.store, required this.attendanceCourses});
  @override
  Widget build(BuildContext context) {
    final warnings = <String>[];
    if (store.overdueTasks > 0) warnings.add('${store.overdueTasks} tugas melewati deadline.');
    final lowAttendance = attendanceCourses.where((c) => store.attendancePercentage(c.id) < 75).toList();
    if (lowAttendance.isNotEmpty) warnings.add('${lowAttendance.length} mata kuliah punya kehadiran di bawah 75%.');
    final ungraded = store.courses.where((c) => !store.grades.any((g) => g.courseId == c.id)).length;
    if (ungraded > 0) warnings.add('$ungraded mata kuliah belum memiliki nilai.');
    final nextExam = _upcomingExam(store);
    if (nextExam != null) {
      final days = _dateOnly(nextExam.date).difference(_dateOnly(DateTime.now())).inDays;
      if (days <= 7) warnings.add('${nextExam.type} terdekat tinggal ${days == 0 ? 'hari ini' : '$days hari lagi'}.');
    }
    if (warnings.isEmpty) {
      return Card(child: ListTile(leading: Icon(Icons.check_circle_outline_rounded, color: Theme.of(context).colorScheme.primary), title: const Text('Semuanya terlihat baik', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('Belum ada hal penting yang perlu kamu perhatikan.')));
    }
    return Card(child: Padding(padding: const EdgeInsets.fromLTRB(16, 14, 16, 14), child: Column(children: [
      ...warnings.map((text) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.warning_amber_rounded, size: 20, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 10), Expanded(child: Text(text))]))),
    ])));
  }
}

class _AcademicStatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const _AcademicStatCard({required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(15),
      child: Row(children: [
        Container(width: 40, height: 40, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: Theme.of(context).colorScheme.primary, size: 20)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 11, color: AppTheme.muted)), const SizedBox(height: 3), Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))])),
      ]),
    ),
  );
}

Future<void> showTargetGpaForm(BuildContext context, AppStore store) async {
  final controller = TextEditingController(text: store.targetGpa.toStringAsFixed(2));
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => _FormSheet(
      title: 'Target IP',
      children: [
        const Text('Tentukan target IP semester yang ingin kamu capai.', style: TextStyle(color: AppTheme.muted)),
        const SizedBox(height: 14),
        TextField(controller: controller, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Target IP (0–4)', prefixIcon: Icon(Icons.flag_outlined))),
        const SizedBox(height: 18),
        PrimaryButton(label: 'Simpan Target', onPressed: () async {
          final value = double.tryParse(controller.text.replaceAll(',', '.'));
          if (value == null) return;
          await store.setTargetGpa(value);
          if (ctx.mounted) Navigator.pop(ctx);
        }),
      ],
    ),
  );
  controller.dispose();
}

class ProfilePage extends StatelessWidget {
  final AppStore store; const ProfilePage({super.key, required this.store});
  @override Widget build(BuildContext context) {
    final p = store.profile;
    return PageShell(
      title: 'Profil',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(22)),
            child: Row(children: [
              GestureDetector(
                onTap: () => _showProfilePhotoActions(context, store),
                child: Stack(clipBehavior: Clip.none, children: [
                  Container(
                    width: 62, height: 62,
                    decoration: BoxDecoration(color: Colors.white.withAlpha(30), shape: BoxShape.circle),
                    clipBehavior: Clip.antiAlias,
                    child: store.profilePhotoPath.isNotEmpty && File(store.profilePhotoPath).existsSync()
                        ? Image.file(File(store.profilePhotoPath), fit: BoxFit.cover)
                        : const Icon(Icons.person_rounded, color: Colors.white, size: 32),
                  ),
                  Positioned(
                    right: -2, bottom: -2,
                    child: Container(width: 23, height: 23, decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: Theme.of(context).colorScheme.primary, width: 2)), child: Icon(Icons.camera_alt_rounded, size: 12, color: Theme.of(context).colorScheme.primary)),
                  ),
                ]),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p.name.isEmpty ? 'Mahasiswa' : p.name, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(p.major.isEmpty ? 'Program studi belum diisi' : p.major, style: const TextStyle(color: Colors.white70)),
                Text('Semester ${p.semester}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ])),
            ]),
          ),
          const SizedBox(height: 18),
          _SettingTile(icon: Icons.edit_outlined, title: 'Edit profil', subtitle: 'Nama, universitas, program studi, NIM', onTap: () => showProfileForm(context, store)),
          _SettingTile(icon: Icons.sticky_note_2_outlined, title: 'Catatan kuliah', subtitle: '${store.notes.length} catatan tersimpan', onTap: () => Navigator.push(context, MotionPageRoute(builder: (_) => NotesPage(store: store)))),
          _SettingTile(icon: Icons.folder_copy_outlined, title: 'Pusat dokumen & link', subtitle: '${store.resources.length} materi/link tersimpan', onTap: () => Navigator.push(context, MotionPageRoute(builder: (_) => ResourcesPage(store: store)))),
          _SettingTile(icon: Icons.dark_mode_outlined, title: 'Tampilan', subtitle: _themeSummary(store), onTap: () => showThemePicker(context, store)),
          _SettingTile(icon: Icons.notifications_active_outlined, title: 'Pusat pengingat', subtitle: 'Tes notifikasi, status, dan pengaturan HP', onTap: () => showNotificationCenter(context, store)),
          _NotificationSettingTile(store: store),
          _ScheduleNotificationSettingTile(store: store),
          _SettingTile(icon: Icons.design_services_outlined, title: 'Bantuan & jasa', subtitle: 'PPT, Excel, dan format dokumen', onTap: () => showServices(context)),
          _SettingTile(icon: Icons.info_outline_rounded, title: 'Tentang aplikasi', subtitle: 'Student Companion • v2.16.0', onTap: () => showAbout(context)),
          const SizedBox(height: 10),
          const Text('Data tersimpan lokal di perangkat. Backup cloud dan sinkronisasi dapat ditambahkan pada fase berikutnya.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: AppTheme.muted, height: 1.4)),
        ],
      ),
    );
  }
}
class _SettingTile extends StatelessWidget { final IconData icon; final String title; final String subtitle; final VoidCallback onTap; const _SettingTile({required this.icon, required this.title, required this.subtitle, required this.onTap}); @override Widget build(BuildContext c) => Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(onTap: onTap, contentPadding: const EdgeInsets.all(13), leading: Container(width: 42, height: 42, decoration: BoxDecoration(color: Theme.of(c).colorScheme.primary.withAlpha(16), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: Theme.of(c).colorScheme.primary)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right_rounded))); }

class _NotificationSettingTile extends StatelessWidget {
  final AppStore store;
  const _NotificationSettingTile({required this.store});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: SwitchListTile(
          value: store.notificationsEnabled,
          onChanged: (value) => store.setNotificationsEnabled(value),
          secondary: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withAlpha(16),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(Icons.notifications_active_outlined, color: Theme.of(context).colorScheme.primary),
          ),
          title: const Text('Pengingat tugas', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: const Text('H-1, 1 jam sebelum, dan saat deadline'),
        ),
      );
}

class _ScheduleNotificationSettingTile extends StatelessWidget {
  final AppStore store;
  const _ScheduleNotificationSettingTile({required this.store});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: SwitchListTile(
          value: store.scheduleNotificationsEnabled,
          onChanged: (value) => store.setScheduleNotificationsEnabled(value),
          secondary: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withAlpha(16),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(Icons.school_outlined, color: Theme.of(context).colorScheme.primary),
          ),
          title: const Text('Pengingat kuliah', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: const Text('30 menit sebelum jadwal kuliah'),
        ),
      );
}


String _themeSummary(AppStore store) {
  final mode = switch (store.themeMode) {
    'dark' => 'Gelap',
    'light' => 'Terang',
    _ => 'Ikuti sistem',
  };
  final accent = AppTheme.themeNames[store.theme] ?? 'Biru';
  return '$mode • Aksen $accent';
}



Future<void> _showProfilePhotoActions(BuildContext context, AppStore store) async {
  await showModalBottomSheet(
    context: context,
    showDragHandle: true,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Align(alignment: Alignment.centerLeft, child: Text('Foto profil', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
        const SizedBox(height: 8),
        const Align(alignment: Alignment.centerLeft, child: Text('Pilih foto dari galeri atau hapus foto saat ini.', style: TextStyle(color: AppTheme.muted))),
        const SizedBox(height: 16),
        ListTile(leading: const Icon(Icons.photo_library_outlined), title: const Text('Pilih dari galeri'), onTap: () async { Navigator.pop(ctx); await store.pickProfilePhoto(); }),
        if (store.profilePhotoPath.isNotEmpty) ListTile(leading: const Icon(Icons.delete_outline_rounded), title: const Text('Hapus foto'), onTap: () async { Navigator.pop(ctx); await store.removeProfilePhoto(); }),
      ]),
    ),
  );
}

class TasksPage extends StatelessWidget {
  final AppStore store;
  const TasksPage({super.key, required this.store});
  @override Widget build(BuildContext context) {
    final tasks = [...store.tasks]..sort((a, b) { if (a.isDone != b.isDone) return a.isDone ? 1 : -1; if (a.dueDate != b.dueDate) return a.dueDate.compareTo(b.dueDate); return a.priority.compareTo(b.priority); });
    return Scaffold(appBar: AppBar(title: const Text('Semua Tugas'), actions: [IconButton(onPressed: () => showTaskForm(context, store), icon: const Icon(Icons.add_rounded))]), body: tasks.isEmpty ? EmptyState(icon: Icons.task_alt_rounded, title: 'Belum ada tugas', subtitle: 'Tambahkan tugas untuk mulai mengatur deadline.', buttonText: 'Tambah Tugas', onPressed: () => showTaskForm(context, store)) : ListView.separated(padding: const EdgeInsets.fromLTRB(20, 10, 20, 28), itemCount: tasks.length, separatorBuilder: (_, __) => const SizedBox(height: 9), itemBuilder: (_, i) { final task = tasks[i]; return _TaskTile(task: task, course: store.courses.where((c) => c.id == task.courseId).firstOrNull, onToggle: () => store.toggleTask(task.id), onTap: () => showTaskDetail(context, store, task)); }));
  }
}
void showTaskDetail(BuildContext context, AppStore store, TaskItem task) {
  Navigator.push(context, MotionPageRoute(builder: (_) => TaskDetailPage(store: store, taskId: task.id)));
}

class TaskDetailPage extends StatefulWidget {
  final AppStore store;
  final String taskId;
  const TaskDetailPage({super.key, required this.store, required this.taskId});
  @override State<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends State<TaskDetailPage> {
  Future<void> _openLink(String link) async {
    final uri = Uri.tryParse(link.trim());
    if (uri == null || !uri.hasScheme || !(uri.scheme == 'http' || uri.scheme == 'https')) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Link tidak valid. Gunakan link yang diawali http:// atau https://.')));
      return;
    }
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Link tidak dapat dibuka di perangkat ini.')));
  }

  @override Widget build(BuildContext context) {
    final task = widget.store.tasks.where((t) => t.id == widget.taskId).firstOrNull;
    if (task == null) return const Scaffold(body: Center(child: Text('Tugas tidak ditemukan.')));
    final course = widget.store.courses.where((c) => c.id == task.courseId).firstOrNull;
    final lateTask = task.dueDate.isBefore(DateTime.now()) && !task.completed;
    return Scaffold(
      appBar: AppBar(title: const Text('Detail Tugas'), actions: [
        IconButton(onPressed: () async { await showTaskForm(context, widget.store, task: task); if (mounted) setState(() {}); }, icon: const Icon(Icons.edit_outlined)),
      ]),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 10, 20, 28), children: [
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text(task.title, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800))), const SizedBox(width: 8), _PriorityPill(task.priority)]), const SizedBox(height: 12), Text(course?.name ?? 'Mata kuliah', style: const TextStyle(color: Colors.white70))])),
        const SizedBox(height: 16),
        _TaskInfoRow(icon: Icons.event_outlined, title: 'Deadline', value: DateFormat('EEEE, dd MMMM yyyy • HH:mm', 'id_ID').format(task.dueDate), valueColor: lateTask ? Colors.red : null),
        const SizedBox(height: 10),
        _TaskInfoRow(icon: Icons.flag_outlined, title: 'Prioritas', value: task.priority),
        const SizedBox(height: 10),
        _TaskInfoRow(icon: task.isDone ? Icons.check_circle_outline_rounded : Icons.pending_actions_rounded, title: 'Status', value: task.isDone ? 'Selesai' : lateTask ? 'Terlambat' : task.status),
        if (task.link.trim().isNotEmpty) ...[
          const SizedBox(height: 10),
          Card(child: ListTile(leading: Icon(Icons.link_rounded, color: Theme.of(context).colorScheme.primary), title: const Text('Link tugas', style: TextStyle(fontSize: 12, color: AppTheme.muted)), subtitle: Text(task.link, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)), trailing: IconButton(onPressed: () => _openLink(task.link), icon: const Icon(Icons.open_in_new_rounded)))),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: () => _openLink(task.link), icon: const Icon(Icons.open_in_new_rounded), label: const Text('Buka Link Tugas')),
        ],
        if (task.note.trim().isNotEmpty) ...[
          const SizedBox(height: 10),
          Card(child: ListTile(leading: Icon(Icons.sticky_note_2_outlined, color: Theme.of(context).colorScheme.primary), title: const Text('Catatan Tugas', style: TextStyle(fontSize: 12, color: AppTheme.muted)), subtitle: Text(task.note, style: const TextStyle(fontWeight: FontWeight.w500)))),
        ],
        const SizedBox(height: 18),
        _TaskChecklistCard(store: widget.store, task: task, onChanged: () { if (mounted) setState(() {}); }),
        const SizedBox(height: 18),
        const Text('Ubah status tugas', style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'Belum mulai', icon: Icon(Icons.radio_button_unchecked_rounded), label: Text('Belum mulai')),
            ButtonSegment(value: 'Dalam proses', icon: Icon(Icons.timelapse_rounded), label: Text('Proses')),
            ButtonSegment(value: 'Selesai', icon: Icon(Icons.check_circle_outline_rounded), label: Text('Selesai')),
          ],
          selected: {task.status},
          onSelectionChanged: (v) async { await widget.store.setTaskStatus(task.id, v.first); if (mounted) setState(() {}); },
          multiSelectionEnabled: false,
          showSelectedIcon: false,
        ),
        const SizedBox(height: 20),
        FilledButton.icon(
          onPressed: () async {
            await widget.store.toggleTask(task.id);
            if (!mounted) return;
            setState(() {});
          },
          icon: Icon(task.isDone ? Icons.undo_rounded : Icons.check_rounded),
          label: Text(task.isDone ? 'Tandai belum mulai' : 'Tandai selesai'),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () async {
            await widget.store.deleteTask(task.id);
            if (!context.mounted) return;
            Navigator.pop(context);
          },
          icon: const Icon(Icons.delete_outline_rounded),
          label: const Text('Hapus tugas'),
        ),
      ]),
    );
  }
}
class _TaskChecklistCard extends StatelessWidget {
  final AppStore store;
  final TaskItem task;
  final VoidCallback onChanged;
  const _TaskChecklistCard({required this.store, required this.task, required this.onChanged});

  Future<void> _toggle(BuildContext context, ChecklistItem item) async {
    final next = task.checklist.map((e) => e.id == item.id ? e.copyWith(completed: !e.completed) : e).toList();
    await store.updateTask(task.copyWith(checklist: next));
    onChanged();
  }

  Future<void> _add(BuildContext context) async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tambah checklist'),
        content: TextField(controller: controller, autofocus: true, textInputAction: TextInputAction.done, decoration: const InputDecoration(labelText: 'Yang harus dilakukan', hintText: 'Contoh: Cari materi referensi'), onSubmitted: (_) => Navigator.pop(ctx, controller.text.trim())),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Tambah'))],
      ),
    );
    controller.dispose();
    if (value == null || value.trim().isEmpty) return;
    final item = ChecklistItem(id: DateTime.now().microsecondsSinceEpoch.toString(), title: value.trim());
    await store.updateTask(task.copyWith(checklist: [...task.checklist, item]));
    onChanged();
  }

  Future<void> _edit(BuildContext context, ChecklistItem item) async {
    final controller = TextEditingController(text: item.title);
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit checklist'),
        content: TextField(controller: controller, autofocus: true, textInputAction: TextInputAction.done, decoration: const InputDecoration(labelText: 'Checklist'), onSubmitted: (_) => Navigator.pop(ctx, controller.text.trim())),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Simpan'))],
      ),
    );
    controller.dispose();
    if (value == null || value.trim().isEmpty) return;
    final next = task.checklist.map((e) => e.id == item.id ? e.copyWith(title: value.trim()) : e).toList();
    await store.updateTask(task.copyWith(checklist: next));
    onChanged();
  }

  Future<void> _delete(BuildContext context, ChecklistItem item) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Hapus checklist?'), content: Text('"${item.title}" akan dihapus dari tugas ini.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus'))]));
    if (ok != true) return;
    await store.updateTask(task.copyWith(checklist: task.checklist.where((e) => e.id != item.id).toList()));
    onChanged();
  }

  @override
  Widget build(BuildContext context) {
    final total = task.checklist.length;
    final done = task.checklist.where((e) => e.completed).length;
    final progress = total == 0 ? 0.0 : done / total;
    final primary = Theme.of(context).colorScheme.primary;
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 10, 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(Icons.checklist_rounded, color: primary),
            const SizedBox(width: 9),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Checklist Tugas', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text(total == 0 ? 'Pecah tugas menjadi beberapa langkah kecil.' : '$done dari $total selesai', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
            ])),
            IconButton(onPressed: () => _add(context), tooltip: 'Tambah checklist', icon: const Icon(Icons.add_rounded)),
          ]),
          if (total > 0) ...[
            const SizedBox(height: 8),
            ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: progress, minHeight: 7)),
            const SizedBox(height: 8),
            ...task.checklist.map((item) => ListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              leading: Checkbox(value: item.completed, onChanged: (_) => _toggle(context, item)),
              title: Text(item.title, style: TextStyle(fontWeight: FontWeight.w600, decoration: item.completed ? TextDecoration.lineThrough : null, color: item.completed ? AppTheme.muted : null)),
              trailing: PopupMenuButton<String>(onSelected: (v) { if (v == 'edit') _edit(context, item); if (v == 'delete') _delete(context, item); }, itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'delete', child: Text('Hapus'))]),
              onTap: () => _toggle(context, item),
            )),
          ] else
            Padding(padding: const EdgeInsets.fromLTRB(4, 6, 4, 4), child: OutlinedButton.icon(onPressed: () => _add(context), icon: const Icon(Icons.add_rounded, size: 18), label: const Text('Tambah langkah'))),
        ]),
      ),
    );
  }
}

class _TaskInfoRow extends StatelessWidget { final IconData icon; final String title; final String value; final Color? valueColor; const _TaskInfoRow({required this.icon, required this.title, required this.value, this.valueColor}); @override Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon, color: Theme.of(context).colorScheme.primary), title: Text(title, style: const TextStyle(fontSize: 12, color: AppTheme.muted)), subtitle: Text(value, style: TextStyle(fontWeight: FontWeight.w700, color: valueColor)))); }
class _TaskTile extends StatelessWidget {
  final TaskItem task;
  final Course? course;
  final VoidCallback onToggle;
  final VoidCallback onTap;
  const _TaskTile({required this.task, required this.course, required this.onToggle, required this.onTap});

  @override
  Widget build(BuildContext c) {
    final lateTask = task.dueDate.isBefore(DateTime.now()) && !task.isDone;
    final timeLeft = task.dueDate.difference(DateTime.now());
    final deadline = task.isDone
        ? 'Selesai'
        : lateTask
            ? 'Terlambat'
            : timeLeft.inHours < 24
                ? 'Kurang 1 hari'
                : DateFormat('dd MMM, HH:mm', 'id_ID').format(task.dueDate);
    final deadlineColor = task.isDone
        ? AppTheme.teal
        : lateTask
            ? Colors.red
            : timeLeft.inHours < 24
                ? AppTheme.orange
                : AppTheme.muted;
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        leading: Checkbox(value: task.isDone, onChanged: (_) => onToggle()),
        title: Row(
          children: [
            Expanded(child: Text(task.title, style: TextStyle(fontWeight: FontWeight.w700, decoration: task.isDone ? TextDecoration.lineThrough : null))),
            const SizedBox(width: 6),
            _PriorityPill(task.priority),
          ],
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Wrap(
            spacing: 7,
            runSpacing: 4,
            children: [
              Text(course?.name ?? 'Mata kuliah', style: const TextStyle(color: AppTheme.muted)),
              const Text('•'),
              Text(task.status, style: const TextStyle(color: AppTheme.muted)),
              if (task.checklist.isNotEmpty) ...[
                const Text('•'),
                Text('${task.checklist.where((item) => item.completed).length}/${task.checklist.length} checklist', style: const TextStyle(color: AppTheme.muted)),
              ],
              const Text('•'),
              Text(deadline, style: TextStyle(color: deadlineColor, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

class _PriorityPill extends StatelessWidget { final String value; const _PriorityPill(this.value); @override Widget build(BuildContext c) { final color = value == 'Tinggi' ? Colors.red : value == 'Rendah' ? AppTheme.teal : AppTheme.orange; return Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5), decoration: BoxDecoration(color: color.withAlpha(20), borderRadius: BorderRadius.circular(20)), child: Text(value, style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.w700))); } }

Future<void> showCourseForm(BuildContext context, AppStore store, {Course? course}) async { final name = TextEditingController(text: course?.name); final code = TextEditingController(text: course?.code); final credits = TextEditingController(text: '${course?.credits ?? 2}'); final lecturer = TextEditingController(text: course?.lecturer); await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => _FormSheet(title: course == null ? 'Tambah Mata Kuliah' : 'Edit Mata Kuliah', children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Nama mata kuliah')), const SizedBox(height: 10), Row(children: [Expanded(child: TextField(controller: code, decoration: const InputDecoration(labelText: 'Kode'))), const SizedBox(width: 10), SizedBox(width: 90, child: TextField(controller: credits, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'SKS')))]), const SizedBox(height: 10), TextField(controller: lecturer, decoration: const InputDecoration(labelText: 'Dosen (opsional)')), const SizedBox(height: 18), PrimaryButton(label: course == null ? 'Simpan' : 'Simpan Perubahan', onPressed: () { if (name.text.trim().isEmpty || code.text.trim().isEmpty) return; final c = Course(id: course?.id ?? DateTime.now().microsecondsSinceEpoch.toString(), name: name.text.trim(), code: code.text.trim(), credits: int.tryParse(credits.text) ?? 2, lecturer: lecturer.text.trim()); if (course == null) { store.addCourse(c); } else { store.updateCourse(c); } Navigator.pop(ctx); })])); name.dispose(); code.dispose(); credits.dispose(); lecturer.dispose(); }

Future<void> showTaskForm(BuildContext context, AppStore store, {DateTime? initialDate, TaskItem? task}) async {
  final title = TextEditingController(text: task?.title ?? '');
  final link = TextEditingController(text: task?.link ?? '');
  final note = TextEditingController(text: task?.note ?? '');
  final baseDate = initialDate ?? task?.dueDate ?? DateTime.now().add(const Duration(days: 1));
  DateTime due = task?.dueDate ?? DateTime(baseDate.year, baseDate.month, baseDate.day, 18, 0);
  String priority = task?.priority ?? 'Sedang';
  String status = task?.status ?? 'Belum mulai';
  String? courseId = task?.courseId ?? (store.courses.isEmpty ? null : store.courses.first.id);
  await showModalBottomSheet(
    context: context, isScrollControlled: true, showDragHandle: true,
    builder: (ctx) => StatefulBuilder(builder: (_, set) => _FormSheet(
      title: task == null ? 'Tambah Tugas' : 'Edit Tugas',
      children: [
        TextField(controller: title, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Nama tugas', prefixIcon: Icon(Icons.task_alt_rounded))),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(initialValue: courseId, decoration: const InputDecoration(labelText: 'Mata kuliah'), items: store.courses.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(), onChanged: (v) => set(() => courseId = v)),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(initialValue: priority, decoration: const InputDecoration(labelText: 'Prioritas'), items: const ['Tinggi','Sedang','Rendah'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => set(() => priority = v ?? 'Sedang')),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(initialValue: status, decoration: const InputDecoration(labelText: 'Status'), items: const ['Belum mulai','Dalam proses','Selesai'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => set(() => status = v ?? 'Belum mulai')),
        const SizedBox(height: 10),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.event_outlined),
          title: const Text('Deadline'),
          subtitle: Text(DateFormat('EEEE, dd MMM yyyy • HH:mm', 'id_ID').format(due)),
          trailing: Wrap(children: [
            TextButton(onPressed: () async {
              final d = await showDatePicker(context: ctx, firstDate: DateTime.now(), lastDate: DateTime(2100), initialDate: due);
              if (d != null) set(() => due = DateTime(d.year, d.month, d.day, due.hour, due.minute));
            }, child: const Text('Tanggal')),
            TextButton(onPressed: () async {
              final t = await showTimePicker(context: ctx, initialTime: TimeOfDay.fromDateTime(due));
              if (t != null) set(() => due = DateTime(due.year, due.month, due.day, t.hour, t.minute));
            }, child: const Text('Jam')),
          ]),
        ),
        const SizedBox(height: 10),
        TextField(controller: link, keyboardType: TextInputType.url, textInputAction: TextInputAction.next, autocorrect: false, decoration: const InputDecoration(labelText: 'Link tugas (opsional)', hintText: 'https://...', prefixIcon: Icon(Icons.link_rounded))),
        const SizedBox(height: 10),
        TextField(controller: note, minLines: 3, maxLines: 6, textInputAction: TextInputAction.newline, decoration: const InputDecoration(labelText: 'Catatan tugas (opsional)', hintText: 'Tambahkan keterangan atau pengingat kecil...', prefixIcon: Icon(Icons.sticky_note_2_outlined))),
        const SizedBox(height: 8),
        const Text('Link dan catatan bisa diedit kapan saja dari Detail Tugas.', style: TextStyle(color: AppTheme.muted, fontSize: 12)),
        const SizedBox(height: 14),
        PrimaryButton(label: task == null ? 'Simpan Tugas' : 'Simpan Perubahan', onPressed: () async {
          if (title.text.trim().isEmpty || courseId == null) return;
          final updated = TaskItem(id: task?.id ?? DateTime.now().microsecondsSinceEpoch.toString(), title: title.text.trim(), courseId: courseId!, dueDate: due, priority: priority, status: status, completed: status == 'Selesai', link: link.text.trim(), note: note.text.trim(), checklist: task?.checklist ?? const []);
          if (task == null) { await store.addTask(updated); } else { await store.updateTask(updated); }
          if (ctx.mounted) Navigator.pop(ctx);
        }),
      ],
    )),
  );
  title.dispose(); link.dispose(); note.dispose();
}

Future<void> showExamForm(BuildContext context, AppStore store, {ExamItem? exam, Course? initialCourse}) async {
  String? courseId = exam?.courseId ?? initialCourse?.id ?? (store.courses.isEmpty ? null : store.courses.first.id);
  String type = exam?.type ?? 'UTS';
  DateTime date = exam?.date ?? DateTime.now();
  final start = TextEditingController(text: exam?.start ?? '08:00');
  final end = TextEditingController(text: exam?.end ?? '09:40');
  final room = TextEditingController(text: exam?.room ?? '');
  final note = TextEditingController(text: exam?.note ?? '');
  await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => StatefulBuilder(builder: (_, set) => _FormSheet(title: exam == null ? 'Tambah Ujian' : 'Edit Ujian', children: [
    DropdownButtonFormField<String>(initialValue: type, decoration: const InputDecoration(labelText: 'Jenis ujian'), items: const ['UTS','UAS','Kuis','Presentasi'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => set(() => type = v ?? type)),
    const SizedBox(height: 10),
    DropdownButtonFormField<String>(initialValue: courseId, decoration: const InputDecoration(labelText: 'Mata kuliah'), items: store.courses.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(), onChanged: (v) => set(() => courseId = v)),
    const SizedBox(height: 10),
    ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.calendar_today_outlined), title: const Text('Tanggal'), subtitle: Text(DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(date)), onTap: () async { final picked = await showDatePicker(context: ctx, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDate: date); if (picked != null) set(() => date = picked); }),
    Row(children: [Expanded(child: TextField(controller: start, decoration: const InputDecoration(labelText: 'Mulai'))), const SizedBox(width: 10), Expanded(child: TextField(controller: end, decoration: const InputDecoration(labelText: 'Selesai')))]),
    const SizedBox(height: 10), TextField(controller: room, decoration: const InputDecoration(labelText: 'Ruangan (opsional)')), const SizedBox(height: 10), TextField(controller: note, maxLines: 2, decoration: const InputDecoration(labelText: 'Catatan (opsional)', alignLabelWithHint: true)), const SizedBox(height: 18),
    PrimaryButton(label: exam == null ? 'Simpan Ujian' : 'Simpan Perubahan', onPressed: () { if (courseId == null || start.text.trim().isEmpty || end.text.trim().isEmpty) return; final item = ExamItem(id: exam?.id ?? DateTime.now().microsecondsSinceEpoch.toString(), courseId: courseId!, type: type, date: date, start: start.text.trim(), end: end.text.trim(), room: room.text.trim(), note: note.text.trim()); if (exam == null) { store.addExam(item); } else { store.updateExam(item); } Navigator.pop(ctx); })
  ])));
  start.dispose(); end.dispose(); room.dispose(); note.dispose();
}

Future<void> showScheduleForm(BuildContext context, AppStore store) async { int weekday = DateTime.now().weekday; String? courseId = store.courses.isEmpty ? null : store.courses.first.id; final start = TextEditingController(text: '08:00'); final end = TextEditingController(text: '09:40'); final room = TextEditingController(); await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => StatefulBuilder(builder: (_, set) => _FormSheet(title: 'Tambah Jadwal', children: [DropdownButtonFormField<int>(initialValue: weekday, decoration: const InputDecoration(labelText: 'Hari'), items: const [1,2,3,4,5,6,7].map((d) => DropdownMenuItem(value: d, child: Text(['','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'][d]))).toList(), onChanged: (v) => set(() => weekday = v ?? 1)), const SizedBox(height: 10), DropdownButtonFormField<String>(initialValue: courseId, decoration: const InputDecoration(labelText: 'Mata kuliah'), items: store.courses.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(), onChanged: (v) => set(() => courseId = v)), const SizedBox(height: 10), Row(children: [Expanded(child: TextField(controller: start, decoration: const InputDecoration(labelText: 'Mulai'))), const SizedBox(width: 10), Expanded(child: TextField(controller: end, decoration: const InputDecoration(labelText: 'Selesai')))]), const SizedBox(height: 10), TextField(controller: room, decoration: const InputDecoration(labelText: 'Ruangan (opsional)')), const SizedBox(height: 18), PrimaryButton(label: 'Simpan Jadwal', onPressed: () { if (courseId == null || start.text.trim().isEmpty || end.text.trim().isEmpty) return; store.addSchedule(ScheduleItem(id: DateTime.now().microsecondsSinceEpoch.toString(), courseId: courseId!, weekday: weekday, start: start.text.trim(), end: end.text.trim(), room: room.text.trim())); Navigator.pop(ctx); })]))); start.dispose(); end.dispose(); room.dispose(); }

Future<void> showGradeForm(BuildContext context, AppStore store, Course course) async { final existing = store.grades.where((g) => g.courseId == course.id).firstOrNull; final a = TextEditingController(text: existing?.assignment.toString() ?? '0'); final m = TextEditingController(text: existing?.midterm.toString() ?? '0'); final f = TextEditingController(text: existing?.finalExam.toString() ?? '0'); final attendancePercent = store.attendanceForCourse(course.id).isEmpty ? 0 : store.attendancePercentage(course.id); final at = TextEditingController(text: attendancePercent.toStringAsFixed(1)); await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => _GradeSheet(course: course, a: a, m: m, f: f, at: at, store: store)); a.dispose(); m.dispose(); f.dispose(); at.dispose(); }
class _GradeSheet extends StatefulWidget { final Course course; final TextEditingController a,m,f,at; final AppStore store; const _GradeSheet({required this.course, required this.a, required this.m, required this.f, required this.at, required this.store}); @override State<_GradeSheet> createState() => _GradeSheetState(); }
class _GradeSheetState extends State<_GradeSheet> { double get score => (double.tryParse(widget.a.text) ?? 0)*.3 + (double.tryParse(widget.m.text) ?? 0)*.3 + (double.tryParse(widget.f.text) ?? 0)*.3 + (double.tryParse(widget.at.text) ?? 0)*.1; @override Widget build(BuildContext c) => Padding(padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(c).bottom), child: SingleChildScrollView(child: Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 28), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Nilai ${widget.course.name}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 6), Text('Bobot: tugas 30% • UTS 30% • UAS 30% • kehadiran 10%', style: const TextStyle(color: AppTheme.muted, fontSize: 12)), const SizedBox(height: 18), _num(widget.a, 'Tugas (0–100)'), const SizedBox(height: 10), _num(widget.m, 'UTS (0–100)'), const SizedBox(height: 10), _num(widget.f, 'UAS (0–100)'), const SizedBox(height: 10), _num(widget.at, 'Kehadiran (otomatis)', readOnly: true), const SizedBox(height: 18), Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Theme.of(c).colorScheme.primary.withAlpha(12), borderRadius: BorderRadius.circular(15)), child: Row(children: [Expanded(child: Text('Nilai akhir', style: const TextStyle(fontWeight: FontWeight.w700))), Text(score.toStringAsFixed(1), style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: Theme.of(c).colorScheme.primary))])), const SizedBox(height: 16), PrimaryButton(label: 'Simpan Nilai', onPressed: () { widget.store.upsertGrade(GradeItem(id: DateTime.now().microsecondsSinceEpoch.toString(), courseId: widget.course.id, assignment: _clamp(widget.a.text), midterm: _clamp(widget.m.text), finalExam: _clamp(widget.f.text), attendance: _clamp(widget.at.text))); Navigator.pop(c); })])))); Widget _num(TextEditingController c, String label, {bool readOnly = false}) => TextField(controller: c, readOnly: readOnly, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: label), onChanged: readOnly ? null : (_) => setState(() {})); double _clamp(String s) => (double.tryParse(s) ?? 0).clamp(0, 100).toDouble(); }

Future<void> showProfileForm(BuildContext context, AppStore store) async { final p = store.profile; final name = TextEditingController(text: p.name), uni = TextEditingController(text: p.university), major = TextEditingController(text: p.major), nim = TextEditingController(text: p.nim); int semester = p.semester; await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => StatefulBuilder(builder: (_, set) => _FormSheet(title: 'Edit Profil', children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Nama lengkap')), const SizedBox(height: 10), TextField(controller: uni, decoration: const InputDecoration(labelText: 'Universitas')), const SizedBox(height: 10), TextField(controller: major, decoration: const InputDecoration(labelText: 'Program studi')), const SizedBox(height: 10), TextField(controller: nim, decoration: const InputDecoration(labelText: 'NIM')), const SizedBox(height: 10), DropdownButtonFormField<int>(initialValue: semester, decoration: const InputDecoration(labelText: 'Semester'), items: List.generate(12, (i) => DropdownMenuItem(value: i+1, child: Text('Semester ${i+1}'))), onChanged: (v) => set(() => semester = v ?? semester)), const SizedBox(height: 18), PrimaryButton(label: 'Simpan Profil', onPressed: () { if (name.text.trim().isEmpty) return; store.updateProfile(p.copyWith(name: name.text.trim(), university: uni.text.trim(), major: major.text.trim(), nim: nim.text.trim(), semester: semester)); Navigator.pop(ctx); })]))); name.dispose(); uni.dispose(); major.dispose(); nim.dispose(); }

Future<void> showThemePicker(BuildContext context, AppStore store) => showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
          child: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Tampilan aplikasi', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text('Pilih mode tampilan dan warna aksen favoritmu.', style: TextStyle(color: AppTheme.muted)),
              const SizedBox(height: 14),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'light', icon: Icon(Icons.light_mode_outlined), label: Text('Terang')),
                  ButtonSegment(value: 'dark', icon: Icon(Icons.dark_mode_outlined), label: Text('Gelap')),
                  ButtonSegment(value: 'system', icon: Icon(Icons.brightness_auto_outlined), label: Text('Sistem')),
                ],
                selected: {store.themeMode},
                onSelectionChanged: (v) { store.setThemeMode(v.first); set(() {}); },
              ),
              const SizedBox(height: 20),
              const Text('Warna tema', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 10, runSpacing: 10,
                children: AppTheme.themeNames.keys.map((theme) {
                  final selected = store.theme == theme;
                  final color = AppTheme.primaryFor(theme);
                  return Tooltip(
                    message: AppTheme.themeNames[theme]!,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(30),
                      onTap: () { store.setTheme(theme); set(() {}); },
                      child: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: selected ? Theme.of(ctx).colorScheme.onSurface : Colors.transparent, width: 3)),
                        child: selected ? const Icon(Icons.check_rounded, color: Colors.white, size: 22) : null,
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 12),
              Text('Terpilih: ${AppTheme.themeNames[store.theme] ?? 'Biru'}', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
            ]),
          ),
        ),
      ),
    );

Future<void> showNotificationCenter(BuildContext context, AppStore store) async {
  await showModalBottomSheet(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => FutureBuilder<List<dynamic>>(
        future: Future.wait<dynamic>([
          NotificationService.areNotificationsEnabled(),
          NotificationService.pendingNotifications(),
          NotificationService.notificationVolume(),
        ]),
        builder: (ctx, snapshot) {
          final enabled = snapshot.data != null ? snapshot.data![0] as bool : true;
          final pending = snapshot.data != null ? (snapshot.data![1] as List).length : 0;
          final volume = snapshot.data != null ? snapshot.data![2] as Map<String, int>? : null;
          final volumeText = volume == null ? 'Tidak tersedia' : '${volume['current']}/${volume['max']}';
          final ringer = volume == null ? '' : (volume['ringerMode'] == 0 ? ' • Mode senyap' : volume['ringerMode'] == 1 ? ' • Mode getar' : '');
          return Padding(
            padding: EdgeInsets.fromLTRB(20, 4, 20, MediaQuery.viewInsetsOf(ctx).bottom + 28),
            child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Pusat Pengingat', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text('Cek status pengingat dan pengaturan notifikasi HP di sini.', style: TextStyle(color: AppTheme.muted)),
              const SizedBox(height: 16),
              Card(child: ListTile(
                leading: Icon(enabled ? Icons.check_circle_rounded : Icons.error_rounded, color: enabled ? AppTheme.teal : Colors.red),
                title: Text(enabled ? 'Notifikasi sistem aktif' : 'Notifikasi sistem diblokir', style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('Pengingat terjadwal: $pending\nVolume notifikasi: $volumeText$ringer'),
              )),
              const SizedBox(height: 8),
              SizedBox(width: double.infinity, child: FilledButton.icon(
                onPressed: () async {
                  final ok = await NotificationService.sendTestNotification();
                  if (!ctx.mounted) return;
                  ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(ok ? 'Tes notifikasi berhasil dikirim.' : 'Notifikasi belum diizinkan.')));
                  set(() {});
                },
                icon: const Icon(Icons.notifications_active_rounded), label: const Text('Kirim tes notifikasi'),
              )),
              const SizedBox(height: 8),
              SizedBox(width: double.infinity, child: OutlinedButton.icon(
                onPressed: () async {
                  await NotificationService.openNotificationSettings();
                },
                icon: const Icon(Icons.settings_outlined), label: const Text('Buka Pengaturan Notifikasi HP'),
              )),
              const SizedBox(height: 10),
              const Text('Jika notifikasi tidak berbunyi, periksa volume dan pengaturan notifikasi HP.', style: TextStyle(fontSize: 12, color: AppTheme.muted, height: 1.45)),
            ])),
          );
        },
      ),
    ),
  );
}

Future<void> showServices(BuildContext context) async {
  final store = context.findAncestorStateOfType<_HomeShellState>()?.widget.store;
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => _ServicesSheet(store: store),
  );
}

const String _serviceWhatsApp = '6282110197135';

class _ServicesSheet extends StatelessWidget {
  final AppStore? store;
  const _ServicesSheet({this.store});

  @override
  Widget build(BuildContext context) => FractionallySizedBox(
        heightFactor: .92,
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
            children: [
              const Text('Jasa Mahasiswa', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text('Pilih layanan, isi kebutuhanmu, lalu kirim detail pesanan lewat WhatsApp.', style: TextStyle(color: AppTheme.muted)),
              const SizedBox(height: 18),
              _ServiceCard(
                icon: Icons.slideshow_rounded,
                title: 'Pembuatan PPT',
                description: 'Pembuatan baru atau perapihan PowerPoint.',
                price: 'Mulai dari Rp5.000',
                onTap: () => _showServiceForm(context, _ServiceType.ppt, store),
              ),
              _ServiceCard(
                icon: Icons.table_chart_rounded,
                title: 'Pembuatan Excel',
                description: 'Excel sederhana, rumus, absensi, dashboard, dan otomatisasi.',
                price: 'Mulai dari Rp15.000',
                onTap: () => _showServiceForm(context, _ServiceType.excel, store),
              ),
              _ServiceCard(
                icon: Icons.description_outlined,
                title: 'Format Dokumen',
                description: 'Perapihan Word, makalah, layout, dan kebutuhan dokumen lainnya.',
                price: 'Mulai dari Rp5.000',
                onTap: () => _showServiceForm(context, _ServiceType.document, store),
              ),
              const SizedBox(height: 8),
              const Text('Harga adalah estimasi minimum. Harga final dapat dikonfirmasi setelah kebutuhan dilihat.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: AppTheme.muted, height: 1.4)),
            ],
          ),
        ),
      );
}

class _ServiceCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final String price;
  final VoidCallback onTap;
  const _ServiceCard({required this.icon, required this.title, required this.description, required this.price, required this.onTap});

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Row(children: [
              Container(width: 48, height: 48, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(16), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: Theme.of(context).colorScheme.primary)),
              const SizedBox(width: 13),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                const SizedBox(height: 4),
                Text(description, style: const TextStyle(color: AppTheme.muted, fontSize: 12, height: 1.35)),
                const SizedBox(height: 7),
                Text(price, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800, fontSize: 12)),
              ])),
              const Icon(Icons.chevron_right_rounded),
            ]),
          ),
        ),
      );
}

enum _ServiceType { ppt, excel, document }

Future<void> _showServiceForm(BuildContext context, _ServiceType type, AppStore? store) async {
  Navigator.pop(context);
  await Future<void>.delayed(const Duration(milliseconds: 120));
  if (!context.mounted) return;
  if (type == _ServiceType.ppt) return _showPptForm(context, store);
  if (type == _ServiceType.excel) return _showExcelForm(context, store);
  return _showDocumentForm(context, store);
}

String _formatServiceDate(DateTime date) => DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(date);

Future<void> _showPptForm(BuildContext context, AppStore? store) async {
  String mode = 'Pembuatan PPT';
  int slides = 10;
  final topic = TextEditingController();
  final note = TextEditingController();
  String style = 'Modern';
  DateTime selectedDate = DateTime.now().add(const Duration(days: 3));

  await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => StatefulBuilder(builder: (_, set) {
    final isCreate = mode == 'Pembuatan PPT';
    final price = isCreate ? (slides <= 10 ? 10000 : slides <= 20 ? 20000 : 30000) : 5000;
    final summaryDetails = [
      'Jenis layanan: $mode',
      if (isCreate) 'Jumlah slide: $slides',
      if (!isCreate) 'File: Dikirim melalui WhatsApp setelah pemesanan',
      if (isCreate) 'Topik/judul: ${topic.text.trim().isEmpty ? '-' : topic.text.trim()}',
      'Gaya desain: $style',
      'Deadline: ${_formatServiceDate(selectedDate)}',
      if (isCreate) 'Referensi: Jika ada, kirim melalui WhatsApp setelah pemesanan',
      'Catatan: ${note.text.trim().isEmpty ? '-' : note.text.trim()}',
    ];
    final valid = isCreate ? topic.text.trim().isNotEmpty : true;
    return _ServiceFormSheet(title: 'PPT', price: price, children: [
      DropdownButtonFormField<String>(initialValue: mode, decoration: const InputDecoration(labelText: 'Pilihan layanan'), items: const ['Pembuatan PPT', 'Perapihan PPT'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => set(() => mode = v ?? mode)),
      const SizedBox(height: 10),
      if (isCreate) ...[
        DropdownButtonFormField<int>(initialValue: slides, decoration: const InputDecoration(labelText: 'Jumlah slide'), items: List.generate(30, (i) => i + 1).map((v) => DropdownMenuItem(value: v, child: Text('$v slide'))).toList(), onChanged: (v) => set(() => slides = v ?? slides)),
        const SizedBox(height: 10),
        TextField(controller: topic, onChanged: (_) => set(() {}), decoration: const InputDecoration(labelText: 'Topik / judul presentasi', prefixIcon: Icon(Icons.title_rounded))),
        const SizedBox(height: 10),
      ] else ...[
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Theme.of(ctx).colorScheme.primary.withAlpha(12), borderRadius: BorderRadius.circular(14), border: Border.all(color: Theme.of(ctx).colorScheme.primary.withAlpha(35))), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline_rounded), SizedBox(width: 10), Expanded(child: Text('Silakan kirim file yang ingin Anda rapihkan melalui WhatsApp setelah Anda memesan jasa.', style: TextStyle(height: 1.4)))])),
        const SizedBox(height: 10),
      ],
      DropdownButtonFormField<String>(initialValue: style, decoration: const InputDecoration(labelText: 'Gaya desain'), items: const ['Modern', 'Formal akademik', 'Minimalis', 'Kreatif'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => set(() => style = v ?? style)),
      const SizedBox(height: 10),
      _ServiceDateButton(date: selectedDate, onPressed: () async { final picked = await showDatePicker(context: ctx, initialDate: selectedDate, firstDate: DateTime.now(), lastDate: DateTime(2100)); if (picked != null) set(() => selectedDate = picked); }),
      const SizedBox(height: 10),
      if (isCreate) ...[
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Theme.of(ctx).colorScheme.primary.withAlpha(12), borderRadius: BorderRadius.circular(14), border: Border.all(color: Theme.of(ctx).colorScheme.primary.withAlpha(35))), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline_rounded), SizedBox(width: 10), Expanded(child: Text('Jika ada referensi, silakan kirim melalui WhatsApp setelah Anda memesan jasa.', style: TextStyle(height: 1.4)))])),
        const SizedBox(height: 10),
      ],
      TextField(controller: note, onChanged: (_) => set(() {}), maxLines: 3, decoration: const InputDecoration(labelText: 'Catatan tambahan (opsional)', alignLabelWithHint: true)),
      const SizedBox(height: 14),
      _ServiceSummaryCard(details: summaryDetails, price: price),
      const SizedBox(height: 14),
      PrimaryButton(label: 'Pesan via WhatsApp', onPressed: valid ? () => _sendServiceOrder(context, store: store, title: 'Jasa PPT', price: price, details: summaryDetails) : () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(isCreate ? 'Isi topik/judul presentasi terlebih dahulu.' : 'Silakan pesan jasa terlebih dahulu, lalu kirim file melalui WhatsApp.')))),
    ]);
  }));
  topic.dispose(); note.dispose();
}

Future<void> _showExcelForm(BuildContext context, AppStore? store) async {
  final note = TextEditingController();
  String type = 'Excel sederhana';
  DateTime selectedDate = DateTime.now().add(const Duration(days: 3));
  await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => StatefulBuilder(builder: (_, set) {
    final price = type == 'Excel sederhana' ? 15000 : type == 'Rumus & Laporan' ? 30000 : type == 'Absensi' ? 25000 : type == 'Dashboard' ? 35000 : type == 'Otomatisasi' ? 40000 : 0;
    final isOther = type == 'Lain-lain';
    return _ServiceFormSheet(title: 'Pembuatan Excel', price: price, children: [
      DropdownButtonFormField<String>(initialValue: type, decoration: const InputDecoration(labelText: 'Jenis kebutuhan'), items: const ['Excel sederhana', 'Rumus & Laporan', 'Absensi', 'Dashboard', 'Otomatisasi', 'Lain-lain'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => set(() => type = v ?? type)),
      const SizedBox(height: 10),
      if (isOther) TextField(controller: note, onChanged: (_) => set(() {}), maxLines: 4, decoration: const InputDecoration(labelText: 'Jelaskan format Excel yang dibutuhkan', hintText: 'Contoh: 3 sheet, rekap otomatis, grafik, dll.', alignLabelWithHint: true)) else TextField(controller: note, onChanged: (_) => set(() {}), maxLines: 4, decoration: const InputDecoration(labelText: 'Detail kebutuhan (opsional)', hintText: 'Jelaskan fitur atau format yang kamu inginkan.', alignLabelWithHint: true)),
      const SizedBox(height: 10),
      _ServiceDateButton(date: selectedDate, onPressed: () async { final picked = await showDatePicker(context: ctx, initialDate: selectedDate, firstDate: DateTime.now(), lastDate: DateTime(2100)); if (picked != null) set(() => selectedDate = picked); }),
      const SizedBox(height: 14),
      _ServiceSummaryCard(details: ['Jenis kebutuhan: $type', 'Deadline: ${_formatServiceDate(selectedDate)}', 'Detail kebutuhan: ${note.text.trim().isEmpty ? '-' : note.text.trim()}'], price: price, priceOnSeparateLine: true),
      const SizedBox(height: 14),
      PrimaryButton(label: 'Pesan via WhatsApp', onPressed: () => _sendServiceOrder(context, store: store, title: 'Pembuatan Excel', price: price, details: ['Jenis kebutuhan: $type', 'Deadline: ${_formatServiceDate(selectedDate)}', 'Detail kebutuhan: ${note.text.trim().isEmpty ? '-' : note.text.trim()}'])),
    ]);
  }));
  note.dispose();
}

Future<void> _showDocumentForm(BuildContext context, AppStore? store) async {
  final note = TextEditingController();
  DateTime selectedDate = DateTime.now().add(const Duration(days: 3));
  await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => StatefulBuilder(builder: (_, set) {
    const type = 'Perapihan dokumen';
    const price = 5000;
    return _ServiceFormSheet(title: 'Format Dokumen', price: price, children: [
      Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Theme.of(ctx).colorScheme.primary.withAlpha(12), borderRadius: BorderRadius.circular(14), border: Border.all(color: Theme.of(ctx).colorScheme.primary.withAlpha(35))), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline_rounded), SizedBox(width: 10), Expanded(child: Text('Silakan kirim file yang ingin Anda rapihkan melalui WhatsApp setelah Anda memesan jasa.', style: TextStyle(height: 1.4)))])),
      const SizedBox(height: 10),
      TextField(controller: note, onChanged: (_) => set(() {}), maxLines: 4, decoration: const InputDecoration(labelText: 'Catatan tambahan (opsional)', alignLabelWithHint: true)),
      const SizedBox(height: 10),
      _ServiceDateButton(date: selectedDate, onPressed: () async { final picked = await showDatePicker(context: ctx, initialDate: selectedDate, firstDate: DateTime.now(), lastDate: DateTime(2100)); if (picked != null) set(() => selectedDate = picked); }),
      const SizedBox(height: 14),
      _ServiceSummaryCard(details: [type, 'File: Dikirim melalui WhatsApp setelah pemesanan', 'Deadline: ${_formatServiceDate(selectedDate)}', 'Catatan: ${note.text.trim().isEmpty ? '-' : note.text.trim()}'], price: price),
      const SizedBox(height: 14),
      PrimaryButton(label: 'Pesan via WhatsApp', onPressed: () => _sendServiceOrder(context, store: store, title: 'Format Dokumen', price: price, details: [type, 'File: Dikirim melalui WhatsApp setelah pemesanan', 'Deadline: ${_formatServiceDate(selectedDate)}', 'Catatan: ${note.text.trim().isEmpty ? '-' : note.text.trim()}'])),
    ]);
  }));
  note.dispose();
}

class _ServiceFormSheet extends StatelessWidget {
  final String title;
  final int price;
  final List<Widget> children;
  const _ServiceFormSheet({required this.title, required this.price, required this.children});

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
        child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 28), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('Isi kebutuhanmu agar pesanan lebih jelas.', style: TextStyle(color: AppTheme.muted)),
          const SizedBox(height: 18),
          ...children,
        ]),),
      );
}

class _ServiceDateButton extends StatelessWidget {
  final DateTime date;
  final VoidCallback onPressed;
  const _ServiceDateButton({required this.date, required this.onPressed});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(12),
        child: InputDecorator(
          decoration: const InputDecoration(labelText: 'Deadline', prefixIcon: Icon(Icons.event_outlined)),
          child: Text(_formatServiceDate(date)),
        ),
      );
}

class _ServiceSummaryCard extends StatelessWidget {
  final List<String> details;
  final int price;
  final bool priceOnSeparateLine;
  const _ServiceSummaryCard({required this.details, required this.price, this.priceOnSeparateLine = false});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(10), borderRadius: BorderRadius.circular(16), border: Border.all(color: Theme.of(context).colorScheme.primary.withAlpha(30))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Ringkasan pesanan', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
          const SizedBox(height: 8),
          ...details.map((d) => Padding(padding: const EdgeInsets.only(bottom: 4), child: Text('• $d', style: const TextStyle(fontSize: 12, height: 1.3)))),
          const Divider(height: 16),
          if (priceOnSeparateLine) ...[
            const Text('Estimasi harga minimum', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(price == 0 ? 'Konsultasikan terlebih dahulu' : _rupiah(price), style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.primary)),
          ] else
            Row(children: [const Expanded(child: Text('Estimasi harga minimum', style: TextStyle(fontWeight: FontWeight.w700))), Text(price == 0 ? 'Konsultasikan terlebih dahulu' : _rupiah(price), style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.primary))]),
        ]),
      );
}

String _rupiah(int value) => 'Rp${NumberFormat('#,###', 'id_ID').format(value)}';

Future<void> _sendServiceOrder(BuildContext context, {required String title, required int price, required List<String> details, AppStore? store}) async {
  final profile = store?.profile;
  final name = profile?.name ?? '';
  final lines = <String>[
    'Halo, saya ingin memesan jasa dari Student Companion.',
    '',
    'JASA: $title',
    'ESTIMASI HARGA MINIMUM: ${price == 0 ? 'Konsultasikan terlebih dahulu' : _rupiah(price)}',
    '',
    'DETAIL PESANAN:',
    ...details.map((d) => '• $d'),
    '',
    'DATA PEMESAN:',
    '• Nama: ${name.isEmpty ? '-' : name}',
    '• Universitas: ${profile?.university.isEmpty ?? true ? '-' : profile!.university}',
    '• Program studi: ${profile?.major.isEmpty ?? true ? '-' : profile!.major}',
    '',
    'Mohon konfirmasi harga final dan proses pengerjaannya. Terima kasih.',
  ];
  final text = lines.join('\n');
  final uri = Uri.parse('https://wa.me/$_serviceWhatsApp?text=${Uri.encodeComponent(text)}');
  final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
  if (!ok && context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('WhatsApp tidak dapat dibuka.')));
}

void showAbout(BuildContext context) => showAboutDialog(context: context, applicationName: 'Student Companion', applicationVersion: '2.16.0', applicationIcon: const BrandLogo(size: 48, radius: 12), children: const [Text('Teman kuliahmu dari semester 1 sampai lulus. Versi awal berfokus pada tugas, mata kuliah, jadwal, nilai, progress, dan profil.')]);

class _FormSheet extends StatelessWidget { final String title; final List<Widget> children; const _FormSheet({required this.title, required this.children}); @override Widget build(BuildContext c) => Padding(padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(c).bottom), child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 28), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)), const SizedBox(height: 18), ...children]))); }
