package com.example.student_companion

import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Bundle
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "student_companion/system"
    private var samplePlayer: MediaPlayer? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "playSample" -> {
                    val sound = call.argument<String>("sound") ?: ""
                    val resourceId = resources.getIdentifier(sound, "raw", packageName)
                    if (resourceId == 0) {
                        result.error("NOT_FOUND", "Suara $sound tidak ditemukan.", null)
                        return@setMethodCallHandler
                    }
                    try {
                        samplePlayer?.release()
                        samplePlayer = MediaPlayer.create(this, resourceId)
                        samplePlayer?.setOnCompletionListener { mp ->
                            mp.release()
                            if (samplePlayer === mp) samplePlayer = null
                        }
                        samplePlayer?.start()
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("PLAY_ERROR", e.message, null)
                    }
                }
                "stopSample" -> {
                    samplePlayer?.stop()
                    samplePlayer?.release()
                    samplePlayer = null
                    result.success(true)
                }
                "openNotificationSettings" -> {
                    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                    }
                    startActivity(intent)
                    result.success(true)
                }
                "notificationVolume" -> {
                    val manager = getSystemService(AUDIO_SERVICE) as AudioManager
                    result.success(mapOf(
                        "current" to manager.getStreamVolume(AudioManager.STREAM_NOTIFICATION),
                        "max" to manager.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION),
                        "ringerMode" to manager.ringerMode
                    ))
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onDestroy() {
        samplePlayer?.release()
        samplePlayer = null
        super.onDestroy()
    }
}
