# Student Companion V2.18.2 — Dashboard 2.0 Final Touch

Baseline: Student Companion V2.18.1 yang sudah berhasil dibuild dan diuji.

Pembaruan V2.18.2:
- Final touch Dashboard 2.0 tanpa mengubah struktur utama.
- Peringatan ringkas untuk tugas yang melewati deadline.
- Progress semester lebih aman saat data tugas/mata kuliah masih kosong.
- Hero Card responsif untuk layar HP yang lebih sempit.
- Ilustrasi Student Stairs tetap dipertahankan.
# Student Companion V2.11.0

Pembaruan:
- Jadwal Ujian dibuat lebih terlihat di Detail Mata Kuliah.
- Dari Detail Mata Kuliah, pengguna bisa langsung menambah UTS/UAS/kuis/presentasi untuk mata kuliah tersebut.
- Jadwal ujian menampilkan tanggal, jam, ruangan, dan countdown.
- Checklist Tugas: tambah langkah, centang selesai, edit, hapus, dan progress otomatis.
- Checklist tersimpan lokal dan kompatibel dengan tugas lama.

Baseline: Student Companion V2.10.0 yang sudah berhasil dibuild dan diuji.
