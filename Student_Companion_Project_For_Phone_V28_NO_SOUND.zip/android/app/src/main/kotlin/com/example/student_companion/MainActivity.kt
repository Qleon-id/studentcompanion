package com.example.student_companion

import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "student_companion/system"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "openNotificationSettings" -> {
                    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                    }
                    startActivity(intent)
                    result.success(true)
                }
                "notificationVolume" -> {
                    val manager = getSystemService(AUDIO_SERVICE) as AudioManager
                    result.success(mapOf(
                        "current" to manager.getStreamVolume(AudioManager.STREAM_NOTIFICATION),
                        "max" to manager.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION),
                        "ringerMode" to manager.ringerMode
                    ))
                }
                else -> result.notImplemented()
            }
        }
    }

}
