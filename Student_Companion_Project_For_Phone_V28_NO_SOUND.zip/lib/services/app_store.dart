import 'dart:convert';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_models.dart';
import 'notification_service.dart';

class AppStore extends ChangeNotifier {
  static const _profileKey = 'profile';
  static const _coursesKey = 'courses';
  static const _tasksKey = 'tasks';
  static const _scheduleKey = 'schedule';
  static const _gradesKey = 'grades';
  static const _notesKey = 'notes';
  static const _onboardedKey = 'onboarded';
  static const _themeKey = 'theme';
  static const _themeModeKey = 'theme_mode';
  static const _profilePhotoKey = 'profile_photo_path';
  static const _targetGpaKey = 'target_gpa';
  static const _notificationsKey = 'notifications_enabled';
  static const _scheduleNotificationsKey = 'schedule_notifications_enabled';

  StudentProfile profile = const StudentProfile();
  List<Course> courses = [];
  List<TaskItem> tasks = [];
  List<ScheduleItem> schedule = [];
  List<GradeItem> grades = [];
  List<NoteItem> notes = [];
  bool onboarded = false;
  String theme = 'blue';
  String themeMode = 'system';
  String profilePhotoPath = '';
  double targetGpa = 3.75;
  bool notificationsEnabled = true;
  bool scheduleNotificationsEnabled = true;

  SharedPreferences? _prefs;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    final p = _prefs!.getString(_profileKey);
    if (p != null) profile = StudentProfile.fromJson(jsonDecode(p) as Map<String, dynamic>);
    courses = _decodeList(_prefs!.getString(_coursesKey), Course.fromJson);
    tasks = _decodeList(_prefs!.getString(_tasksKey), TaskItem.fromJson);
    schedule = _decodeList(_prefs!.getString(_scheduleKey), ScheduleItem.fromJson);
    grades = _decodeList(_prefs!.getString(_gradesKey), GradeItem.fromJson);
    notes = _decodeList(_prefs!.getString(_notesKey), NoteItem.fromJson);
    onboarded = _prefs!.getBool(_onboardedKey) ?? false;
    theme = _prefs!.getString(_themeKey) ?? 'blue';
    themeMode = _prefs!.getString(_themeModeKey) ?? 'system';
    profilePhotoPath = _prefs!.getString(_profilePhotoKey) ?? '';
    targetGpa = _prefs!.getDouble(_targetGpaKey) ?? 3.75;
    notificationsEnabled = _prefs!.getBool(_notificationsKey) ?? true;
    scheduleNotificationsEnabled = _prefs!.getBool(_scheduleNotificationsKey) ?? true;
    _seedIfEmpty();
    notifyListeners();
    if (onboarded && (notificationsEnabled || scheduleNotificationsEnabled)) {
      await NotificationService.requestPermissions();
      await _rescheduleNotifications();
    }
  }

  List<T> _decodeList<T>(String? raw, T Function(Map<String, dynamic>) fromJson) {
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return [];
    }
  }

  void _seedIfEmpty() {
    if (courses.isNotEmpty || onboarded) return;
    courses = [
      const Course(id: 'c1', name: 'Pemrograman Mobile', code: 'IF201', credits: 3, lecturer: 'Budi Santoso'),
      const Course(id: 'c2', name: 'Basis Data', code: 'IF202', credits: 3, lecturer: 'Siti Rahma'),
      const Course(id: 'c3', name: 'UI/UX Design', code: 'DKV110', credits: 2, lecturer: 'Andi Pratama'),
    ];
    final now = DateTime.now();
    tasks = [
      TaskItem(id: 't1', title: 'Kumpulkan laporan praktikum', courseId: 'c1', dueDate: now.add(const Duration(days: 1)), priority: 'Tinggi'),
      TaskItem(id: 't2', title: 'Review materi sebelum kuis', courseId: 'c2', dueDate: now.add(const Duration(days: 3)), priority: 'Sedang'),
    ];
    grades = const [
      GradeItem(id: 'g1', courseId: 'c1', assignment: 88, midterm: 84, finalExam: 86, attendance: 100),
      GradeItem(id: 'g2', courseId: 'c2', assignment: 82, midterm: 78, finalExam: 80, attendance: 95),
    ];
  }

  Future<void> _save(String key, Object value) async {
    await _prefs?.setString(key, jsonEncode(value));
  }

  Future<void> completeOnboarding(StudentProfile value) async {
    profile = value;
    onboarded = true;
    await _prefs?.setString(_profileKey, jsonEncode(profile.toJson()));
    await _prefs?.setBool(_onboardedKey, true);
    await _save(_coursesKey, courses.map((e) => e.toJson()).toList());
    await _save(_tasksKey, tasks.map((e) => e.toJson()).toList());
    await _save(_gradesKey, grades.map((e) => e.toJson()).toList());
    await _save(_scheduleKey, schedule.map((e) => e.toJson()).toList());
    await _save(_notesKey, notes.map((e) => e.toJson()).toList());
    if (notificationsEnabled || scheduleNotificationsEnabled) {
      await NotificationService.requestPermissions();
      await _rescheduleNotifications();
    }
    notifyListeners();
  }

  Future<void> updateProfile(StudentProfile value) async {
    profile = value;
    await _prefs?.setString(_profileKey, jsonEncode(profile.toJson()));
    notifyListeners();
  }

  Future<void> setNotificationsEnabled(bool value) async {
    notificationsEnabled = value;
    await _prefs?.setBool(_notificationsKey, value);
    if (value || scheduleNotificationsEnabled) {
      await NotificationService.requestPermissions();
    }
    await _rescheduleNotifications();
    notifyListeners();
  }

  Future<void> setScheduleNotificationsEnabled(bool value) async {
    scheduleNotificationsEnabled = value;
    await _prefs?.setBool(_scheduleNotificationsKey, value);
    if (value || notificationsEnabled) {
      await NotificationService.requestPermissions();
    }
    await _rescheduleNotifications();
    notifyListeners();
  }

  Future<void> _rescheduleNotifications() async {
    await NotificationService.cancelAll();
    if (notificationsEnabled) {
      for (final task in tasks.where((t) => !t.completed)) {
        final course = courses.where((c) => c.id == task.courseId).firstOrNull;
        await NotificationService.scheduleTask(task, courseName: course?.name);
      }
    }
    if (scheduleNotificationsEnabled) {
      for (final item in schedule) {
        final course = courses.where((c) => c.id == item.courseId).firstOrNull;
        await NotificationService.scheduleSchedule(item, courseName: course?.name);
      }
    }
  }

  Future<void> setTheme(String value) async {
    theme = value;
    await _prefs?.setString(_themeKey, value);
    notifyListeners();
  }

  Future<void> setThemeMode(String value) async {
    themeMode = value;
    await _prefs?.setString(_themeModeKey, value);
    notifyListeners();
  }

  Future<void> setTargetGpa(double value) async {
    targetGpa = value.clamp(0, 4).toDouble();
    await _prefs?.setDouble(_targetGpaKey, targetGpa);
    notifyListeners();
  }


  Future<void> pickProfilePhoto() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 1200);
    if (picked == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final target = File('${dir.path}/profile_photo.jpg');
    await File(picked.path).copy(target.path);
    profilePhotoPath = target.path;
    await _prefs?.setString(_profilePhotoKey, profilePhotoPath);
    notifyListeners();
  }

  Future<void> removeProfilePhoto() async {
    if (profilePhotoPath.isNotEmpty) {
      final file = File(profilePhotoPath);
      if (await file.exists()) await file.delete();
    }
    profilePhotoPath = '';
    await _prefs?.remove(_profilePhotoKey);
    notifyListeners();
  }

  Future<void> addNote(NoteItem note) async {
    notes = [note, ...notes];
    await _save(_notesKey, notes.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  Future<void> updateNote(NoteItem note) async {
    notes = notes.map((e) => e.id == note.id ? note : e).toList();
    await _save(_notesKey, notes.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  Future<void> deleteNote(String id) async {
    notes = notes.where((e) => e.id != id).toList();
    await _save(_notesKey, notes.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  Future<void> addCourse(Course course) async {
    courses = [...courses, course];
    await _save(_coursesKey, courses.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  Future<void> updateCourse(Course course) async {
    courses = courses.map((e) => e.id == course.id ? course : e).toList();
    await _save(_coursesKey, courses.map((e) => e.toJson()).toList());
    if (notificationsEnabled || scheduleNotificationsEnabled) await _rescheduleNotifications();
    notifyListeners();
  }

  Future<void> deleteCourse(String id) async {
    courses = courses.where((e) => e.id != id).toList();
    tasks = tasks.where((e) => e.courseId != id).toList();
    grades = grades.where((e) => e.courseId != id).toList();
    schedule = schedule.where((e) => e.courseId != id).toList();
    await _save(_coursesKey, courses.map((e) => e.toJson()).toList());
    await _save(_tasksKey, tasks.map((e) => e.toJson()).toList());
    await _save(_gradesKey, grades.map((e) => e.toJson()).toList());
    await _save(_scheduleKey, schedule.map((e) => e.toJson()).toList());
    await _save(_notesKey, notes.map((e) => e.toJson()).toList());
    if (notificationsEnabled || scheduleNotificationsEnabled) await _rescheduleNotifications();
    notifyListeners();
  }

  Future<void> addTask(TaskItem task) async {
    tasks = [...tasks, task];
    await _save(_tasksKey, tasks.map((e) => e.toJson()).toList());
    if (notificationsEnabled) {
      final course = courses.where((c) => c.id == task.courseId).firstOrNull;
      await NotificationService.scheduleTask(task, courseName: course?.name);
    }
    notifyListeners();
  }

  Future<void> updateTask(TaskItem task) async {
    tasks = tasks.map((e) => e.id == task.id ? task : e).toList();
    await _save(_tasksKey, tasks.map((e) => e.toJson()).toList());
    if (task.isDone || !notificationsEnabled) {
      await NotificationService.cancelTask(task.id);
    } else {
      final course = courses.where((c) => c.id == task.courseId).firstOrNull;
      await NotificationService.scheduleTask(task, courseName: course?.name);
    }
    notifyListeners();
  }

  Future<void> toggleTask(String id) async {
    final task = tasks.where((e) => e.id == id).firstOrNull;
    if (task == null) return;
    await setTaskStatus(id, task.isDone ? 'Belum mulai' : 'Selesai');
  }

  Future<void> setTaskStatus(String id, String status) async {
    TaskItem? changed;
    tasks = tasks.map((e) {
      if (e.id == id) {
        changed = e.copyWith(status: status, completed: status == 'Selesai');
        return changed!;
      }
      return e;
    }).toList();
    await _save(_tasksKey, tasks.map((e) => e.toJson()).toList());
    if (changed != null) {
      if (changed!.isDone || !notificationsEnabled) {
        await NotificationService.cancelTask(changed!.id);
      } else {
        final course = courses.where((c) => c.id == changed!.courseId).firstOrNull;
        await NotificationService.scheduleTask(changed!, courseName: course?.name);
      }
    }
    notifyListeners();
  }

  Future<void> deleteTask(String id) async {
    tasks = tasks.where((e) => e.id != id).toList();
    await _save(_tasksKey, tasks.map((e) => e.toJson()).toList());
    await NotificationService.cancelTask(id);
    notifyListeners();
  }

  Future<void> addSchedule(ScheduleItem item) async {
    schedule = [...schedule, item];
    await _save(_scheduleKey, schedule.map((e) => e.toJson()).toList());
    if (scheduleNotificationsEnabled) {
      final course = courses.where((c) => c.id == item.courseId).firstOrNull;
      await NotificationService.scheduleSchedule(item, courseName: course?.name);
    }
    notifyListeners();
  }

  Future<void> deleteSchedule(String id) async {
    schedule = schedule.where((e) => e.id != id).toList();
    await _save(_scheduleKey, schedule.map((e) => e.toJson()).toList());
    await NotificationService.cancelSchedule(id);
    notifyListeners();
  }

  Future<void> upsertGrade(GradeItem grade) async {
    final exists = grades.any((e) => e.courseId == grade.courseId);
    grades = exists ? grades.map((e) => e.courseId == grade.courseId ? grade : e).toList() : [...grades, grade];
    await _save(_gradesKey, grades.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  double get gpa {
    if (grades.isEmpty) return 0;
    double totalPoints = 0;
    int totalCredits = 0;
    for (final grade in grades) {
      final course = courses.where((c) => c.id == grade.courseId).firstOrNull;
      if (course == null) continue;
      totalPoints += grade.gradePoint * course.credits;
      totalCredits += course.credits;
    }
    return totalCredits == 0 ? 0 : totalPoints / totalCredits;
  }

  int get completedTasks => tasks.where((e) => e.isDone).length;
  int get inProgressTasks => tasks.where((e) => e.status == 'Dalam proses').length;
  int get notStartedTasks => tasks.where((e) => e.status == 'Belum mulai').length;
  int get pendingTasks => tasks.where((e) => !e.isDone).length;
  int get overdueTasks => tasks.where((e) => !e.isDone && e.dueDate.isBefore(DateTime.now())).length;
  int get highPriorityTasks => tasks.where((e) => !e.isDone && e.priority == 'Tinggi').length;
  int get gradedCourses => grades.where((g) => courses.any((c) => c.id == g.courseId)).length;
  int get totalCredits => courses.fold<int>(0, (sum, course) => sum + course.credits);
}

extension FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
