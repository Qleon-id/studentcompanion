class StudentProfile {
  final String name;
  final String university;
  final String major;
  final String nim;
  final int semester;

  const StudentProfile({
    this.name = '',
    this.university = '',
    this.major = '',
    this.nim = '',
    this.semester = 1,
  });

  StudentProfile copyWith({
    String? name,
    String? university,
    String? major,
    String? nim,
    int? semester,
  }) => StudentProfile(
        name: name ?? this.name,
        university: university ?? this.university,
        major: major ?? this.major,
        nim: nim ?? this.nim,
        semester: semester ?? this.semester,
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'university': university,
        'major': major,
        'nim': nim,
        'semester': semester,
      };

  factory StudentProfile.fromJson(Map<String, dynamic> json) => StudentProfile(
        name: json['name'] as String? ?? '',
        university: json['university'] as String? ?? '',
        major: json['major'] as String? ?? '',
        nim: json['nim'] as String? ?? '',
        semester: (json['semester'] as num?)?.toInt() ?? 1,
      );
}

class NoteItem {
  final String id;
  final String title;
  final String content;
  final String courseId;
  final DateTime updatedAt;

  const NoteItem({
    required this.id,
    required this.title,
    required this.content,
    this.courseId = '',
    required this.updatedAt,
  });

  NoteItem copyWith({String? title, String? content, String? courseId, DateTime? updatedAt}) => NoteItem(
        id: id,
        title: title ?? this.title,
        content: content ?? this.content,
        courseId: courseId ?? this.courseId,
        updatedAt: updatedAt ?? this.updatedAt,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'content': content,
        'courseId': courseId,
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory NoteItem.fromJson(Map<String, dynamic> json) => NoteItem(
        id: json['id'] as String? ?? '',
        title: json['title'] as String? ?? '',
        content: json['content'] as String? ?? '',
        courseId: json['courseId'] as String? ?? '',
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ?? DateTime.now(),
      );
}

class Course {
  final String id;
  final String name;
  final String code;
  final int credits;
  final String lecturer;

  const Course({
    required this.id,
    required this.name,
    required this.code,
    required this.credits,
    this.lecturer = '',
  });

  Course copyWith({String? name, String? code, int? credits, String? lecturer}) => Course(
        id: id,
        name: name ?? this.name,
        code: code ?? this.code,
        credits: credits ?? this.credits,
        lecturer: lecturer ?? this.lecturer,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'code': code,
        'credits': credits,
        'lecturer': lecturer,
      };

  factory Course.fromJson(Map<String, dynamic> json) => Course(
        id: json['id'] as String? ?? '',
        name: json['name'] as String? ?? '',
        code: json['code'] as String? ?? '',
        credits: (json['credits'] as num?)?.toInt() ?? 2,
        lecturer: json['lecturer'] as String? ?? '',
      );
}

class ChecklistItem {
  final String id;
  final String title;
  final bool completed;

  const ChecklistItem({
    required this.id,
    required this.title,
    this.completed = false,
  });

  ChecklistItem copyWith({String? title, bool? completed}) => ChecklistItem(
        id: id,
        title: title ?? this.title,
        completed: completed ?? this.completed,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'completed': completed,
      };

  factory ChecklistItem.fromJson(Map<String, dynamic> json) => ChecklistItem(
        id: json['id'] as String? ?? '',
        title: json['title'] as String? ?? '',
        completed: json['completed'] as bool? ?? false,
      );
}

class TaskItem {
  final String id;
  final String title;
  final String courseId;
  final DateTime dueDate;
  final String priority;
  final String status;
  final bool completed;
  final String link;
  final String note;
  final List<ChecklistItem> checklist;

  const TaskItem({
    required this.id,
    required this.title,
    required this.courseId,
    required this.dueDate,
    this.priority = 'Sedang',
    this.status = 'Belum mulai',
    this.completed = false,
    this.link = '',
    this.note = '',
    this.checklist = const [],
  });

  bool get isDone => status == 'Selesai' || completed;

  TaskItem copyWith({
    String? title,
    String? courseId,
    DateTime? dueDate,
    String? priority,
    String? status,
    bool? completed,
    String? link,
    String? note,
    List<ChecklistItem>? checklist,
  }) {
    final nextStatus = status ?? (completed == null ? this.status : (completed ? 'Selesai' : 'Belum mulai'));
    final nextCompleted = completed ?? (status == null ? this.completed : status == 'Selesai');
    return TaskItem(
      id: id,
      title: title ?? this.title,
      courseId: courseId ?? this.courseId,
      dueDate: dueDate ?? this.dueDate,
      priority: priority ?? this.priority,
      status: nextStatus,
      completed: nextCompleted,
      link: link ?? this.link,
      note: note ?? this.note,
      checklist: checklist ?? this.checklist,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'courseId': courseId,
        'dueDate': dueDate.toIso8601String(),
        'priority': priority,
        'status': status,
        'completed': isDone,
        'link': link,
        'note': note,
        'checklist': checklist.map((e) => e.toJson()).toList(),
      };

  factory TaskItem.fromJson(Map<String, dynamic> json) {
    final oldCompleted = json['completed'] as bool? ?? false;
    final rawChecklist = json['checklist'];
    final checklist = rawChecklist is List
        ? rawChecklist.whereType<Map<String, dynamic>>().map(ChecklistItem.fromJson).toList()
        : <ChecklistItem>[];
    final rawStatus = json['status'] as String?;
    final normalized = rawStatus == 'Dalam proses' || rawStatus == 'Selesai' || rawStatus == 'Belum mulai'
        ? rawStatus!
        : (oldCompleted ? 'Selesai' : 'Belum mulai');
    return TaskItem(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      courseId: json['courseId'] as String? ?? '',
      dueDate: DateTime.tryParse(json['dueDate'] as String? ?? '') ?? DateTime.now(),
      priority: json['priority'] as String? ?? 'Sedang',
      status: normalized,
      completed: normalized == 'Selesai',
      link: json['link'] as String? ?? '',
      note: json['note'] as String? ?? '',
      checklist: checklist,
    );
  }
}

class AttendanceItem {
  final String id;
  final String courseId;
  final DateTime date;
  final String status;
  final String note;

  const AttendanceItem({
    required this.id,
    required this.courseId,
    required this.date,
    this.status = 'Hadir',
    this.note = '',
  });

  AttendanceItem copyWith({DateTime? date, String? status, String? note}) => AttendanceItem(
        id: id,
        courseId: courseId,
        date: date ?? this.date,
        status: status ?? this.status,
        note: note ?? this.note,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'courseId': courseId,
        'date': date.toIso8601String(),
        'status': status,
        'note': note,
      };

  factory AttendanceItem.fromJson(Map<String, dynamic> json) => AttendanceItem(
        id: json['id'] as String? ?? '',
        courseId: json['courseId'] as String? ?? '',
        date: DateTime.tryParse(json['date'] as String? ?? '') ?? DateTime.now(),
        status: json['status'] as String? ?? 'Hadir',
        note: json['note'] as String? ?? '',
      );
}

class ScheduleItem {
  final String id;
  final String courseId;
  final int weekday;
  final String start;
  final String end;
  final String room;

  const ScheduleItem({
    required this.id,
    required this.courseId,
    required this.weekday,
    required this.start,
    required this.end,
    this.room = '',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'courseId': courseId,
        'weekday': weekday,
        'start': start,
        'end': end,
        'room': room,
      };

  factory ScheduleItem.fromJson(Map<String, dynamic> json) => ScheduleItem(
        id: json['id'] as String? ?? '',
        courseId: json['courseId'] as String? ?? '',
        weekday: (json['weekday'] as num?)?.toInt() ?? 1,
        start: json['start'] as String? ?? '08:00',
        end: json['end'] as String? ?? '09:40',
        room: json['room'] as String? ?? '',
      );
}

class ExamItem {
  final String id;
  final String courseId;
  final String type;
  final DateTime date;
  final String start;
  final String end;
  final String room;
  final String note;

  const ExamItem({
    required this.id,
    required this.courseId,
    this.type = 'UTS',
    required this.date,
    this.start = '08:00',
    this.end = '09:40',
    this.room = '',
    this.note = '',
  });

  ExamItem copyWith({String? courseId, String? type, DateTime? date, String? start, String? end, String? room, String? note}) => ExamItem(
    id: id, courseId: courseId ?? this.courseId, type: type ?? this.type, date: date ?? this.date,
    start: start ?? this.start, end: end ?? this.end, room: room ?? this.room, note: note ?? this.note,
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'courseId': courseId, 'type': type, 'date': date.toIso8601String(),
    'start': start, 'end': end, 'room': room, 'note': note,
  };

  factory ExamItem.fromJson(Map<String, dynamic> json) => ExamItem(
    id: json['id'] as String? ?? '', courseId: json['courseId'] as String? ?? '',
    type: json['type'] as String? ?? 'UTS', date: DateTime.tryParse(json['date'] as String? ?? '') ?? DateTime.now(),
    start: json['start'] as String? ?? '08:00', end: json['end'] as String? ?? '09:40',
    room: json['room'] as String? ?? '', note: json['note'] as String? ?? '',
  );
}

class GradeItem {
  final String id;
  final String courseId;
  final double assignment;
  final double midterm;
  final double finalExam;
  final double attendance;

  const GradeItem({
    required this.id,
    required this.courseId,
    this.assignment = 0,
    this.midterm = 0,
    this.finalExam = 0,
    this.attendance = 0,
  });

  double get score => (assignment * .30) + (midterm * .30) + (finalExam * .30) + (attendance * .10);

  String get letter {
    final s = score;
    if (s >= 85) return 'A';
    if (s >= 80) return 'A-';
    if (s >= 75) return 'B+';
    if (s >= 70) return 'B';
    if (s >= 65) return 'B-';
    if (s >= 60) return 'C+';
    if (s >= 55) return 'C';
    if (s >= 45) return 'D';
    return 'E';
  }

  double get gradePoint {
    switch (letter) {
      case 'A': return 4.0;
      case 'A-': return 3.7;
      case 'B+': return 3.3;
      case 'B': return 3.0;
      case 'B-': return 2.7;
      case 'C+': return 2.3;
      case 'C': return 2.0;
      case 'D': return 1.0;
      default: return 0;
    }
  }

  GradeItem copyWith({double? assignment, double? midterm, double? finalExam, double? attendance}) => GradeItem(
        id: id,
        courseId: courseId,
        assignment: assignment ?? this.assignment,
        midterm: midterm ?? this.midterm,
        finalExam: finalExam ?? this.finalExam,
        attendance: attendance ?? this.attendance,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'courseId': courseId,
        'assignment': assignment,
        'midterm': midterm,
        'finalExam': finalExam,
        'attendance': attendance,
      };

  factory GradeItem.fromJson(Map<String, dynamic> json) => GradeItem(
        id: json['id'] as String? ?? '',
        courseId: json['courseId'] as String? ?? '',
        assignment: (json['assignment'] as num?)?.toDouble() ?? 0,
        midterm: (json['midterm'] as num?)?.toDouble() ?? 0,
        finalExam: (json['finalExam'] as num?)?.toDouble() ?? 0,
        attendance: (json['attendance'] as num?)?.toDouble() ?? 0,
      );
}
