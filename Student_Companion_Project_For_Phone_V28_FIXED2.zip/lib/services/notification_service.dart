import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import '../models/app_models.dart';
import 'i18n.dart';

class NotificationService {
  NotificationService._();
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _initialized = false;
  static const _channelId = 'student_companion_reminders_v28';
  static const _channelName = 'Pengingat Student Companion';

  static Future<void> initialize() async {
    if (_initialized) return;
    tz.initializeTimeZones();
    try {
      final local = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(local.identifier));
    } catch (_) {
      tz.setLocalLocation(tz.getLocation('Asia/Jakarta'));
    }
    const android = AndroidInitializationSettings('ic_launcher');
    const darwin = DarwinInitializationSettings();
    await _plugin.initialize(const InitializationSettings(android: android, iOS: darwin));
    final androidPlugin = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(const AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: 'Pengingat tugas dan jadwal kuliah',
      importance: Importance.high,
      playSound: true,
      enableVibration: true,
      audioAttributesUsage: AudioAttributesUsage.notification,
    ));
    _initialized = true;
  }

  static NotificationDetails _details() => const NotificationDetails(
    android: AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: 'Pengingat tugas dan jadwal kuliah',
      importance: Importance.high,
      priority: Priority.high,
      icon: 'ic_launcher',
      playSound: true,
      enableVibration: true,
      audioAttributesUsage: AudioAttributesUsage.notification,
    ),
    iOS: DarwinNotificationDetails(presentSound: true),
  );

  static Future<bool> requestPermissions() async {
    await initialize();
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    return await android?.requestNotificationsPermission() ?? true;
  }

  static int _hash(String value) {
    var hash = 2166136261;
    for (final code in value.codeUnits) { hash ^= code; hash = (hash * 16777619) & 0x7fffffff; }
    return hash % 100000000;
  }
  static int _taskNotificationId(String taskId, int slot) => _hash('task:$taskId') * 10 + slot;
  static int _scheduleNotificationId(String scheduleId) => _hash('schedule:$scheduleId') + 200000000;

  static Future<void> scheduleTask(TaskItem task, {String? courseName}) async {
    await initialize();
    if (task.completed) return;
    final now = DateTime.now();
    final due = task.dueDate;
    if (!due.isAfter(now)) return;
    await cancelTask(task.id);
    final body = '${task.title}${courseName == null ? '' : ' • $courseName'}';
    final details = _details();
    final dayBefore = due.subtract(const Duration(days: 1));
    if (dayBefore.isAfter(now)) await _plugin.zonedSchedule(_taskNotificationId(task.id, 1), tr('Besok ada deadline'), body, tz.TZDateTime.from(dayBefore, tz.local), details, androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, payload: task.id);
    final oneHourBefore = due.subtract(const Duration(hours: 1));
    if (oneHourBefore.isAfter(now)) await _plugin.zonedSchedule(_taskNotificationId(task.id, 2), tr('Deadline 1 jam lagi'), body, tz.TZDateTime.from(oneHourBefore, tz.local), details, androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, payload: task.id);
    await _plugin.zonedSchedule(_taskNotificationId(task.id, 3), tr('Deadline tugas'), body, tz.TZDateTime.from(due, tz.local), details, androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, payload: task.id);
  }

  static Future<void> scheduleSchedule(ScheduleItem item, {String? courseName}) async {
    await initialize();
    await cancelSchedule(item.id);
    final parts = item.start.split(':');
    if (parts.length != 2) return;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour < 0 || hour > 23 || minute < 0 || minute > 59) return;
    final now = tz.TZDateTime.now(tz.local);
    var classDate = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    final daysAhead = (item.weekday - classDate.weekday + 7) % 7;
    classDate = classDate.add(Duration(days: daysAhead));
    if (!classDate.isAfter(now)) classDate = classDate.add(const Duration(days: 7));
    final reminder = classDate.subtract(const Duration(minutes: 30));
    final body = '${courseName ?? 'Mata kuliah'}${item.room.isEmpty ? '' : ' • ${item.room}'}';
    await _plugin.zonedSchedule(_scheduleNotificationId(item.id), tr('Kuliah 30 menit lagi'), body, reminder, _details(), androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime, payload: item.id);
  }

  static Future<void> cancelTask(String taskId) async { await initialize(); for (final slot in [1, 2, 3]) { await _plugin.cancel(_taskNotificationId(taskId, slot)); } }
  static Future<void> cancelSchedule(String scheduleId) async { await initialize(); await _plugin.cancel(_scheduleNotificationId(scheduleId)); }
  static Future<void> cancelAll() async { await initialize(); await _plugin.cancelAll(); }
}
