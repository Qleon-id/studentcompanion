# Student Companion — Ready-to-open Flutter Android Project

Project ini sudah berbentuk **project Flutter lengkap**, bukan hanya folder `lib/`. Buka folder `student_companion` ini dari Android Studio.

## Cara menjalankan

1. Pastikan Flutter SDK sudah terpasang dan Flutter plugin untuk Android Studio aktif.
2. Buka **folder `student_companion`** (folder yang berisi `pubspec.yaml` dan `android/`).
3. Tunggu Android Studio selesai melakukan Gradle/Flutter sync.
4. Jalankan `flutter pub get` bila diminta.
5. Pilih emulator atau HP Android yang terhubung.
6. Klik tombol **Run ▶**.

Atau dari terminal di root project:

```bash
flutter pub get
flutter analyze
flutter run
```

## Catatan penting

- `android/local.properties` sengaja tidak disertakan karena berisi lokasi Flutter/Android SDK **di komputer masing-masing**.
- Project menggunakan Flutter SDK `>=3.35.0 <4.0.0` dan Dart `>=3.9.0 <4.0.0`.
- Dependency runtime dibuat minimal: `shared_preferences` dan `intl`.
- Versi release sementara memakai debug signing agar bisa langsung dibuat APK untuk pengujian. Untuk Play Store nanti wajib dibuat signing key/release signing yang benar.
- Jika Android Studio meminta upgrade Gradle/Android Gradle Plugin karena versi Flutter SDK lokal berbeda, ikuti rekomendasi Flutter/Android Studio untuk project tersebut.

## Isi MVP

Onboarding, profil, semester, dashboard, mata kuliah, tugas, jadwal mingguan, nilai/IP, progress, pilihan tema, bantuan & jasa, serta penyimpanan lokal.

## Versi 2

Versi 2 menambahkan notifikasi deadline tugas, pengaturan notifikasi, pemilihan jam deadline, dan penjadwalan ulang pengingat otomatis setelah aplikasi dibuka.
