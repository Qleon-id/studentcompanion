import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import '../models/app_models.dart';

class NotificationService {
  NotificationService._();

  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _initialized = false;

  static const _taskChannelName = 'Pengingat tugas';
  static const _scheduleChannelName = 'Pengingat kuliah';
  static const _soundNames = ['default', 'soft', 'tone1', 'tone2', 'firm', 'silent'];

  static Future<void> initialize() async {
    if (_initialized) return;
    tz.initializeTimeZones();
    try {
      final local = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(local.identifier));
    } catch (_) {
      tz.setLocalLocation(tz.getLocation('Asia/Jakarta'));
    }
    const android = AndroidInitializationSettings('ic_launcher');
    const darwin = DarwinInitializationSettings();
    await _plugin.initialize(const InitializationSettings(android: android, iOS: darwin));
    _initialized = true;
    await _createChannels();
  }

  static Future<void> _createChannels() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android == null) return;
    for (final sound in _soundNames) {
      await android.createNotificationChannel(_channel('task', sound));
      await android.createNotificationChannel(_channel('schedule', sound));
    }
  }

  static AndroidNotificationChannel _channel(String type, String sound) {
    final isSilent = sound == 'silent';
    final raw = _rawSound(sound);
    return AndroidNotificationChannel(
      '${type}_reminders_$sound',
      type == 'task' ? _taskChannelName : _scheduleChannelName,
      description: type == 'task' ? 'Pengingat deadline tugas mahasiswa' : 'Pengingat jadwal kuliah mahasiswa',
      importance: Importance.high,
      playSound: !isSilent,
      sound: raw == null ? null : RawResourceAndroidNotificationSound(raw),
    );
  }

  static String? _rawSound(String sound) {
    switch (sound) {
      case 'soft': return 'notif_soft';
      case 'tone1': return 'notif_tone1';
      case 'tone2': return 'notif_tone2';
      case 'firm': return 'notif_firm';
      default: return null;
    }
  }

  static String _safeSound(String sound) => _soundNames.contains(sound) ? sound : 'default';

  static NotificationDetails _taskDetails(String sound) {
    final safe = _safeSound(sound);
    final raw = _rawSound(safe);
    return NotificationDetails(
      android: AndroidNotificationDetails(
        'task_reminders_$safe',
        _taskChannelName,
        channelDescription: 'Pengingat deadline tugas mahasiswa',
        importance: Importance.high,
        priority: Priority.high,
        icon: 'ic_launcher',
        playSound: safe != 'silent',
        sound: raw == null ? null : RawResourceAndroidNotificationSound(raw),
      ),
      iOS: DarwinNotificationDetails(presentSound: safe != 'silent'),
    );
  }

  static NotificationDetails _scheduleDetails(String sound) {
    final safe = _safeSound(sound);
    final raw = _rawSound(safe);
    return NotificationDetails(
      android: AndroidNotificationDetails(
        'schedule_reminders_$safe',
        _scheduleChannelName,
        channelDescription: 'Pengingat jadwal kuliah mahasiswa',
        importance: Importance.high,
        priority: Priority.high,
        icon: 'ic_launcher',
        playSound: safe != 'silent',
        sound: raw == null ? null : RawResourceAndroidNotificationSound(raw),
      ),
      iOS: DarwinNotificationDetails(presentSound: safe != 'silent'),
    );
  }

  static Future<bool> requestPermissions() async {
    await initialize();
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final result = await android?.requestNotificationsPermission();
    return result ?? true;
  }

  static int _hash(String value) {
    var hash = 2166136261;
    for (final code in value.codeUnits) {
      hash ^= code;
      hash = (hash * 16777619) & 0x7fffffff;
    }
    return hash % 100000000;
  }

  static int _taskNotificationId(String taskId, int slot) => _hash('task:$taskId') * 10 + slot;
  static int _scheduleNotificationId(String scheduleId) => _hash('schedule:$scheduleId') + 200000000;

  static Future<void> scheduleTask(TaskItem task, {String? courseName, String soundName = 'default'}) async {
    await initialize();
    if (task.completed) return;
    final now = DateTime.now();
    final due = task.dueDate;
    if (!due.isAfter(now)) return;
    await cancelTask(task.id);
    final body = '${task.title}${courseName == null ? '' : ' • $courseName'}';
    final details = _taskDetails(soundName);
    final dayBefore = due.subtract(const Duration(days: 1));
    if (dayBefore.isAfter(now)) {
      await _plugin.zonedSchedule(_taskNotificationId(task.id, 1), 'Besok ada deadline', body, tz.TZDateTime.from(dayBefore, tz.local), details, androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, payload: task.id);
    }
    final oneHourBefore = due.subtract(const Duration(hours: 1));
    if (oneHourBefore.isAfter(now)) {
      await _plugin.zonedSchedule(_taskNotificationId(task.id, 2), 'Deadline 1 jam lagi', body, tz.TZDateTime.from(oneHourBefore, tz.local), details, androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, payload: task.id);
    }
    await _plugin.zonedSchedule(_taskNotificationId(task.id, 3), 'Deadline tugas', body, tz.TZDateTime.from(due, tz.local), details, androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, payload: task.id);
  }

  static Future<void> scheduleSchedule(ScheduleItem item, {String? courseName, String soundName = 'default'}) async {
    await initialize();
    await cancelSchedule(item.id);
    final parts = item.start.split(':');
    if (parts.length != 2) return;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour < 0 || hour > 23 || minute < 0 || minute > 59) return;
    final now = tz.TZDateTime.now(tz.local);
    var classDate = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    final daysAhead = (item.weekday - classDate.weekday + 7) % 7;
    classDate = classDate.add(Duration(days: daysAhead));
    if (!classDate.isAfter(now)) classDate = classDate.add(const Duration(days: 7));
    final reminder = classDate.subtract(const Duration(minutes: 30));
    final body = '${courseName ?? 'Mata kuliah'}${item.room.isEmpty ? '' : ' • ${item.room}'}';
    await _plugin.zonedSchedule(_scheduleNotificationId(item.id), 'Kuliah 30 menit lagi', body, reminder, _scheduleDetails(soundName), androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime, payload: item.id);
  }

  static Future<void> previewSound(String soundName) async {
    await initialize();
    await requestPermissions();
    final id = 987654321;
    await _plugin.show(id, 'Preview suara notifikasi', 'Ini contoh suara yang dipilih.', _taskDetails(soundName), payload: 'preview');
  }

  static Future<void> cancelTask(String taskId) async {
    await initialize();
    for (final slot in [1, 2, 3]) { await _plugin.cancel(_taskNotificationId(taskId, slot)); }
  }

  static Future<void> cancelSchedule(String scheduleId) async {
    await initialize();
    await _plugin.cancel(_scheduleNotificationId(scheduleId));
  }

  static Future<void> cancelAll() async {
    await initialize();
    await _plugin.cancelAll();
  }
}
