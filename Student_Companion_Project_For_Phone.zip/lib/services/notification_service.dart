import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import '../models/app_models.dart';

class NotificationService {
  NotificationService._();

  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static bool _initialized = false;

  static const _channelId = 'student_companion_tasks';
  static const _channelName = 'Pengingat tugas';

  static Future<void> initialize() async {
    if (_initialized) return;
    tz.initializeTimeZones();
    try {
      final local = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(local.identifier));
    } catch (_) {
      tz.setLocalLocation(tz.getLocation('Asia/Jakarta'));
    }

    const android = AndroidInitializationSettings('ic_launcher');
    const darwin = DarwinInitializationSettings();
    const settings = InitializationSettings(android: android, iOS: darwin);
    await _plugin.initialize(settings);
    _initialized = true;
  }

  static Future<bool> requestPermissions() async {
    await initialize();
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    final result = await android?.requestNotificationsPermission();
    return result ?? true;
  }

  static int _notificationId(String taskId, int slot) {
    var hash = 2166136261;
    for (final code in taskId.codeUnits) {
      hash ^= code;
      hash = (hash * 16777619) & 0x7fffffff;
    }
    return (hash % 100000000) * 10 + slot;
  }

  static NotificationDetails _details() => const NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          channelDescription: 'Pengingat deadline tugas mahasiswa',
          importance: Importance.high,
          priority: Priority.high,
          icon: 'ic_launcher',
        ),
        iOS: DarwinNotificationDetails(),
      );

  static Future<void> scheduleTask(TaskItem task, {String? courseName}) async {
    await initialize();
    if (task.completed) return;
    final now = DateTime.now();
    final due = task.dueDate;
    if (!due.isAfter(now)) return;

    await cancelTask(task.id);

    final title = 'Deadline tugas';
    final body = '${task.title}${courseName == null ? '' : ' • $courseName'}';
    final dueTz = tz.TZDateTime.from(due, tz.local);
    await _plugin.zonedSchedule(
      _notificationId(task.id, 2),
      title,
      body,
      dueTz,
      _details(),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: task.id,
    );

    final reminder = DateTime(due.year, due.month, due.day, 9);
    if (reminder.isAfter(now) && reminder.isBefore(due)) {
      await _plugin.zonedSchedule(
        _notificationId(task.id, 1),
        'Besok ada deadline',
        body,
        tz.TZDateTime.from(reminder, tz.local),
        _details(),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: task.id,
      );
    }
  }

  static Future<void> cancelTask(String taskId) async {
    await initialize();
    await _plugin.cancel(_notificationId(taskId, 1));
    await _plugin.cancel(_notificationId(taskId, 2));
  }

  static Future<void> cancelAll() async {
    await initialize();
    await _plugin.cancelAll();
  }
}
