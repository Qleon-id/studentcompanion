import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_models.dart';
import 'notification_service.dart';

class AppStore extends ChangeNotifier {
  static const _profileKey = 'profile';
  static const _coursesKey = 'courses';
  static const _tasksKey = 'tasks';
  static const _scheduleKey = 'schedule';
  static const _gradesKey = 'grades';
  static const _onboardedKey = 'onboarded';
  static const _themeKey = 'theme';
  static const _notificationsKey = 'notifications_enabled';

  StudentProfile profile = const StudentProfile();
  List<Course> courses = [];
  List<TaskItem> tasks = [];
  List<ScheduleItem> schedule = [];
  List<GradeItem> grades = [];
  bool onboarded = false;
  String theme = 'blue';
  bool notificationsEnabled = true;

  SharedPreferences? _prefs;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    final p = _prefs!.getString(_profileKey);
    if (p != null) profile = StudentProfile.fromJson(jsonDecode(p) as Map<String, dynamic>);
    courses = _decodeList(_prefs!.getString(_coursesKey), Course.fromJson);
    tasks = _decodeList(_prefs!.getString(_tasksKey), TaskItem.fromJson);
    schedule = _decodeList(_prefs!.getString(_scheduleKey), ScheduleItem.fromJson);
    grades = _decodeList(_prefs!.getString(_gradesKey), GradeItem.fromJson);
    onboarded = _prefs!.getBool(_onboardedKey) ?? false;
    theme = _prefs!.getString(_themeKey) ?? 'blue';
    notificationsEnabled = _prefs!.getBool(_notificationsKey) ?? true;
    _seedIfEmpty();
    notifyListeners();
    if (onboarded && notificationsEnabled) {
      await NotificationService.requestPermissions();
      await _rescheduleNotifications();
    }
  }

  List<T> _decodeList<T>(String? raw, T Function(Map<String, dynamic>) fromJson) {
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return [];
    }
  }

  void _seedIfEmpty() {
    if (courses.isNotEmpty || onboarded) return;
    courses = [
      const Course(id: 'c1', name: 'Pemrograman Mobile', code: 'IF201', credits: 3, lecturer: 'Budi Santoso'),
      const Course(id: 'c2', name: 'Basis Data', code: 'IF202', credits: 3, lecturer: 'Siti Rahma'),
      const Course(id: 'c3', name: 'UI/UX Design', code: 'DKV110', credits: 2, lecturer: 'Andi Pratama'),
    ];
    final now = DateTime.now();
    tasks = [
      TaskItem(id: 't1', title: 'Kumpulkan laporan praktikum', courseId: 'c1', dueDate: now.add(const Duration(days: 1)), priority: 'Tinggi'),
      TaskItem(id: 't2', title: 'Review materi sebelum kuis', courseId: 'c2', dueDate: now.add(const Duration(days: 3)), priority: 'Sedang'),
    ];
    grades = const [
      GradeItem(id: 'g1', courseId: 'c1', assignment: 88, midterm: 84, finalExam: 86, attendance: 100),
      GradeItem(id: 'g2', courseId: 'c2', assignment: 82, midterm: 78, finalExam: 80, attendance: 95),
    ];
  }

  Future<void> _save(String key, Object value) async {
    await _prefs?.setString(key, jsonEncode(value));
  }

  Future<void> completeOnboarding(StudentProfile value) async {
    profile = value;
    onboarded = true;
    await _prefs?.setString(_profileKey, jsonEncode(profile.toJson()));
    await _prefs?.setBool(_onboardedKey, true);
    if (notificationsEnabled) {
      await NotificationService.requestPermissions();
    }
    notifyListeners();
  }

  Future<void> updateProfile(StudentProfile value) async {
    profile = value;
    await _prefs?.setString(_profileKey, jsonEncode(profile.toJson()));
    notifyListeners();
  }

  Future<void> setNotificationsEnabled(bool value) async {
    notificationsEnabled = value;
    await _prefs?.setBool(_notificationsKey, value);
    if (value) {
      await NotificationService.requestPermissions();
      await _rescheduleNotifications();
    } else {
      await NotificationService.cancelAll();
    }
    notifyListeners();
  }

  Future<void> _rescheduleNotifications() async {
    await NotificationService.cancelAll();
    if (!notificationsEnabled) return;
    for (final task in tasks.where((t) => !t.completed)) {
      final course = courses.where((c) => c.id == task.courseId).firstOrNull;
      await NotificationService.scheduleTask(task, courseName: course?.name);
    }
  }

  Future<void> setTheme(String value) async {
    theme = value;
    await _prefs?.setString(_themeKey, value);
    notifyListeners();
  }

  Future<void> addCourse(Course course) async {
    courses = [...courses, course];
    await _save(_coursesKey, courses.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  Future<void> updateCourse(Course course) async {
    courses = courses.map((e) => e.id == course.id ? course : e).toList();
    await _save(_coursesKey, courses.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  Future<void> deleteCourse(String id) async {
    courses = courses.where((e) => e.id != id).toList();
    tasks = tasks.where((e) => e.courseId != id).toList();
    grades = grades.where((e) => e.courseId != id).toList();
    schedule = schedule.where((e) => e.courseId != id).toList();
    await _save(_coursesKey, courses.map((e) => e.toJson()).toList());
    await _save(_tasksKey, tasks.map((e) => e.toJson()).toList());
    await _save(_gradesKey, grades.map((e) => e.toJson()).toList());
    await _save(_scheduleKey, schedule.map((e) => e.toJson()).toList());
    if (notificationsEnabled) await _rescheduleNotifications();
    notifyListeners();
  }

  Future<void> addTask(TaskItem task) async {
    tasks = [...tasks, task];
    await _save(_tasksKey, tasks.map((e) => e.toJson()).toList());
    if (notificationsEnabled) {
      final course = courses.where((c) => c.id == task.courseId).firstOrNull;
      await NotificationService.scheduleTask(task, courseName: course?.name);
    }
    notifyListeners();
  }

  Future<void> toggleTask(String id) async {
    TaskItem? changed;
    tasks = tasks.map((e) {
      if (e.id == id) {
        changed = e.copyWith(completed: !e.completed);
        return changed!;
      }
      return e;
    }).toList();
    await _save(_tasksKey, tasks.map((e) => e.toJson()).toList());
    if (changed != null) {
      if (changed!.completed || !notificationsEnabled) {
        await NotificationService.cancelTask(changed!.id);
      } else {
        final course = courses.where((c) => c.id == changed!.courseId).firstOrNull;
        await NotificationService.scheduleTask(changed!, courseName: course?.name);
      }
    }
    notifyListeners();
  }

  Future<void> deleteTask(String id) async {
    tasks = tasks.where((e) => e.id != id).toList();
    await _save(_tasksKey, tasks.map((e) => e.toJson()).toList());
    await NotificationService.cancelTask(id);
    notifyListeners();
  }

  Future<void> addSchedule(ScheduleItem item) async {
    schedule = [...schedule, item];
    await _save(_scheduleKey, schedule.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  Future<void> deleteSchedule(String id) async {
    schedule = schedule.where((e) => e.id != id).toList();
    await _save(_scheduleKey, schedule.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  Future<void> upsertGrade(GradeItem grade) async {
    final exists = grades.any((e) => e.courseId == grade.courseId);
    grades = exists ? grades.map((e) => e.courseId == grade.courseId ? grade : e).toList() : [...grades, grade];
    await _save(_gradesKey, grades.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  double get gpa {
    if (grades.isEmpty) return 0;
    double totalPoints = 0;
    int totalCredits = 0;
    for (final grade in grades) {
      final course = courses.where((c) => c.id == grade.courseId).firstOrNull;
      if (course == null) continue;
      totalPoints += grade.gradePoint * course.credits;
      totalCredits += course.credits;
    }
    return totalCredits == 0 ? 0 : totalPoints / totalCredits;
  }

  int get completedTasks => tasks.where((e) => e.completed).length;
  int get pendingTasks => tasks.where((e) => !e.completed).length;
}

extension FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
