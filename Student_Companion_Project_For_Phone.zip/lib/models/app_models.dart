class StudentProfile {
  final String name;
  final String university;
  final String major;
  final String nim;
  final int semester;

  const StudentProfile({
    this.name = '',
    this.university = '',
    this.major = '',
    this.nim = '',
    this.semester = 1,
  });

  StudentProfile copyWith({
    String? name,
    String? university,
    String? major,
    String? nim,
    int? semester,
  }) => StudentProfile(
        name: name ?? this.name,
        university: university ?? this.university,
        major: major ?? this.major,
        nim: nim ?? this.nim,
        semester: semester ?? this.semester,
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'university': university,
        'major': major,
        'nim': nim,
        'semester': semester,
      };

  factory StudentProfile.fromJson(Map<String, dynamic> json) => StudentProfile(
        name: json['name'] as String? ?? '',
        university: json['university'] as String? ?? '',
        major: json['major'] as String? ?? '',
        nim: json['nim'] as String? ?? '',
        semester: (json['semester'] as num?)?.toInt() ?? 1,
      );
}

class Course {
  final String id;
  final String name;
  final String code;
  final int credits;
  final String lecturer;

  const Course({
    required this.id,
    required this.name,
    required this.code,
    required this.credits,
    this.lecturer = '',
  });

  Course copyWith({String? name, String? code, int? credits, String? lecturer}) => Course(
        id: id,
        name: name ?? this.name,
        code: code ?? this.code,
        credits: credits ?? this.credits,
        lecturer: lecturer ?? this.lecturer,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'code': code,
        'credits': credits,
        'lecturer': lecturer,
      };

  factory Course.fromJson(Map<String, dynamic> json) => Course(
        id: json['id'] as String? ?? '',
        name: json['name'] as String? ?? '',
        code: json['code'] as String? ?? '',
        credits: (json['credits'] as num?)?.toInt() ?? 2,
        lecturer: json['lecturer'] as String? ?? '',
      );
}

class TaskItem {
  final String id;
  final String title;
  final String courseId;
  final DateTime dueDate;
  final String priority;
  final bool completed;

  const TaskItem({
    required this.id,
    required this.title,
    required this.courseId,
    required this.dueDate,
    this.priority = 'Sedang',
    this.completed = false,
  });

  TaskItem copyWith({String? title, String? courseId, DateTime? dueDate, String? priority, bool? completed}) => TaskItem(
        id: id,
        title: title ?? this.title,
        courseId: courseId ?? this.courseId,
        dueDate: dueDate ?? this.dueDate,
        priority: priority ?? this.priority,
        completed: completed ?? this.completed,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'courseId': courseId,
        'dueDate': dueDate.toIso8601String(),
        'priority': priority,
        'completed': completed,
      };

  factory TaskItem.fromJson(Map<String, dynamic> json) => TaskItem(
        id: json['id'] as String? ?? '',
        title: json['title'] as String? ?? '',
        courseId: json['courseId'] as String? ?? '',
        dueDate: DateTime.tryParse(json['dueDate'] as String? ?? '') ?? DateTime.now(),
        priority: json['priority'] as String? ?? 'Sedang',
        completed: json['completed'] as bool? ?? false,
      );
}

class ScheduleItem {
  final String id;
  final String courseId;
  final int weekday;
  final String start;
  final String end;
  final String room;

  const ScheduleItem({
    required this.id,
    required this.courseId,
    required this.weekday,
    required this.start,
    required this.end,
    this.room = '',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'courseId': courseId,
        'weekday': weekday,
        'start': start,
        'end': end,
        'room': room,
      };

  factory ScheduleItem.fromJson(Map<String, dynamic> json) => ScheduleItem(
        id: json['id'] as String? ?? '',
        courseId: json['courseId'] as String? ?? '',
        weekday: (json['weekday'] as num?)?.toInt() ?? 1,
        start: json['start'] as String? ?? '08:00',
        end: json['end'] as String? ?? '09:40',
        room: json['room'] as String? ?? '',
      );
}

class GradeItem {
  final String id;
  final String courseId;
  final double assignment;
  final double midterm;
  final double finalExam;
  final double attendance;

  const GradeItem({
    required this.id,
    required this.courseId,
    this.assignment = 0,
    this.midterm = 0,
    this.finalExam = 0,
    this.attendance = 0,
  });

  double get score => (assignment * .30) + (midterm * .30) + (finalExam * .30) + (attendance * .10);

  String get letter {
    final s = score;
    if (s >= 85) return 'A';
    if (s >= 80) return 'A-';
    if (s >= 75) return 'B+';
    if (s >= 70) return 'B';
    if (s >= 65) return 'B-';
    if (s >= 60) return 'C+';
    if (s >= 55) return 'C';
    if (s >= 45) return 'D';
    return 'E';
  }

  double get gradePoint {
    switch (letter) {
      case 'A': return 4.0;
      case 'A-': return 3.7;
      case 'B+': return 3.3;
      case 'B': return 3.0;
      case 'B-': return 2.7;
      case 'C+': return 2.3;
      case 'C': return 2.0;
      case 'D': return 1.0;
      default: return 0;
    }
  }

  GradeItem copyWith({double? assignment, double? midterm, double? finalExam, double? attendance}) => GradeItem(
        id: id,
        courseId: courseId,
        assignment: assignment ?? this.assignment,
        midterm: midterm ?? this.midterm,
        finalExam: finalExam ?? this.finalExam,
        attendance: attendance ?? this.attendance,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'courseId': courseId,
        'assignment': assignment,
        'midterm': midterm,
        'finalExam': finalExam,
        'attendance': attendance,
      };

  factory GradeItem.fromJson(Map<String, dynamic> json) => GradeItem(
        id: json['id'] as String? ?? '',
        courseId: json['courseId'] as String? ?? '',
        assignment: (json['assignment'] as num?)?.toDouble() ?? 0,
        midterm: (json['midterm'] as num?)?.toDouble() ?? 0,
        finalExam: (json['finalExam'] as num?)?.toDouble() ?? 0,
        attendance: (json['attendance'] as num?)?.toDouble() ?? 0,
      );
}
