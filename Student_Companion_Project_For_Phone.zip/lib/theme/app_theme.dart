import 'package:flutter/material.dart';

class AppTheme {
  static const blue = Color(0xFF2563EB);
  static const purple = Color(0xFF7C3AED);
  static const teal = Color(0xFF0F9F8E);
  static const orange = Color(0xFFF59E0B);
  static const ink = Color(0xFF172033);
  static const muted = Color(0xFF667085);
  static const background = Color(0xFFF6F8FC);

  static Color primaryFor(String theme) {
    switch (theme) {
      case 'purple': return purple;
      case 'teal': return teal;
      case 'orange': return orange;
      default: return blue;
    }
  }

  static ThemeData light(String theme) {
    final primary = primaryFor(theme);
    final scheme = ColorScheme.fromSeed(seedColor: primary, brightness: Brightness.light).copyWith(primary: primary, surface: Colors.white, onSurface: ink);
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: background,
      fontFamily: 'Poppins',
      appBarTheme: const AppBarTheme(backgroundColor: background, foregroundColor: ink, elevation: 0, centerTitle: false),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Color(0xFFE6EAF0))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: primary, width: 1.5)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      ),
      cardTheme: CardThemeData(color: Colors.white, elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFE8ECF2)))),
    );
  }
}
