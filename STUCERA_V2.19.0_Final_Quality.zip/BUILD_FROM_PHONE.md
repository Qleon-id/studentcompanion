# Build STUCERA dari HP

Cara termudah tanpa Android Studio adalah memakai GitHub Actions.

## 1. Buat repository GitHub
- Buka github.com di browser HP.
- Login.
- Buat repository baru, misalnya `student-companion`.
- Untuk paling mudah, pilih **Public**.

## 2. Upload seluruh isi project
Upload **isi folder project ini**, bukan folder pembungkusnya. Pastikan `pubspec.yaml`, `lib/`, `android/`, dan `.github/` berada di root repository.

## 3. Jalankan build
Setelah upload selesai:
- Buka tab **Actions** pada repository.
- Pilih workflow **Build STUCERA APK**.
- Tekan **Run workflow** jika diperlukan.

Workflow otomatis akan:
1. Mengambil Flutter stable.
2. Menjalankan `flutter pub get`.
3. Menjalankan `flutter analyze`.
4. Membuat `app-release.apk`.
5. Menyimpan APK sebagai GitHub Actions artifact.

## 4. Download APK
Buka run yang sudah selesai → bagian **Artifacts** → `student-companion-apk` → download.

Extract ZIP artifact tersebut dan ambil `app-release.apk`.

## Catatan
APK release pada project ini memakai debug signing agar MVP dapat dipasang untuk pengujian. Untuk rilis resmi Google Play, nanti perlu membuat keystore/signing release yang aman dan mengubah konfigurasi build.
