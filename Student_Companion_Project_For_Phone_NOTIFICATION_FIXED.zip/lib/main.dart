import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'models/app_models.dart';
import 'services/app_store.dart';
import 'services/notification_service.dart';
import 'theme/app_theme.dart';
import 'widgets/common.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('id_ID');
  await NotificationService.initialize();
  runApp(const StudentCompanionApp());
}

class StudentCompanionApp extends StatefulWidget {
  const StudentCompanionApp({super.key});
  @override
  State<StudentCompanionApp> createState() => _StudentCompanionAppState();
}

class _StudentCompanionAppState extends State<StudentCompanionApp> {
  final store = AppStore();
  @override
  void initState() { super.initState(); store.load(); }
  @override
  void dispose() { store.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: store, builder: (_, __) => MaterialApp(debugShowCheckedModeBanner: false, title: 'Student Companion', theme: AppTheme.light(store.theme), darkTheme: AppTheme.dark(store.theme), themeMode: store.themeMode == 'dark' ? ThemeMode.dark : store.themeMode == 'light' ? ThemeMode.light : ThemeMode.system, home: store.onboarded ? HomeShell(store: store) : OnboardingScreen(store: store)));
}

class OnboardingScreen extends StatefulWidget {
  final AppStore store;
  const OnboardingScreen({super.key, required this.store});
  @override State<OnboardingScreen> createState() => _OnboardingScreenState();
}
class _OnboardingScreenState extends State<OnboardingScreen> {
  final name = TextEditingController();
  final university = TextEditingController();
  final major = TextEditingController();
  final nim = TextEditingController();
  int semester = 1;
  int step = 0;
  @override void dispose() { name.dispose(); university.dispose(); major.dispose(); nim.dispose(); super.dispose(); }
  void next() {
    if (step == 0) { setState(() => step = 1); return; }
    if (name.text.trim().isEmpty) { _snack('Nama mahasiswa wajib diisi.'); return; }
    widget.store.completeOnboarding(StudentProfile(name: name.text.trim(), university: university.text.trim(), major: major.text.trim(), nim: nim.text.trim(), semester: semester));
  }
  @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(24, 24, 24, 20), child: Column(children: [Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(13)), child: const Icon(Icons.school_rounded, color: Colors.white)), const SizedBox(width: 12), const Text('Student Companion', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))]), Expanded(child: AnimatedSwitcher(duration: const Duration(milliseconds: 250), child: step == 0 ? _welcome(context) : _profile(context))), _dots(), const SizedBox(height: 16), PrimaryButton(label: step == 0 ? 'Mulai Sekarang' : 'Simpan & Masuk', onPressed: next)]))));
  Widget _welcome(BuildContext context) => Center(key: const ValueKey(0), child: Column(mainAxisSize: MainAxisSize.min, children: [Container(width: 120, height: 120, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(18), shape: BoxShape.circle), child: Icon(Icons.auto_awesome_rounded, size: 58, color: Theme.of(context).colorScheme.primary)), const SizedBox(height: 28), const Text('Kuliah jadi lebih teratur.', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, height: 1.15)), const SizedBox(height: 12), const Text('Dari tugas sampai IPK, semua dalam satu aplikasi.', textAlign: TextAlign.center, style: TextStyle(fontSize: 15, color: AppTheme.muted, height: 1.5)), const SizedBox(height: 28), Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: const [_Pill(icon: Icons.task_alt_rounded, text: 'Tugas'), _Pill(icon: Icons.calendar_month_rounded, text: 'Jadwal'), _Pill(icon: Icons.auto_graph_rounded, text: 'IPK')])]));
  Widget _profile(BuildContext context) => ListView(key: const ValueKey(1), padding: const EdgeInsets.only(top: 24), children: [const Text('Kenalan dulu, yuk.', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)), const SizedBox(height: 8), const Text('Data ini tersimpan di perangkatmu dan bisa diubah kapan saja.', style: TextStyle(color: AppTheme.muted)), const SizedBox(height: 24), TextField(controller: name, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Nama lengkap', prefixIcon: Icon(Icons.person_outline_rounded))), const SizedBox(height: 12), TextField(controller: university, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Universitas (opsional)', prefixIcon: Icon(Icons.account_balance_outlined))), const SizedBox(height: 12), TextField(controller: major, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Program studi (opsional)', prefixIcon: Icon(Icons.menu_book_outlined))), const SizedBox(height: 12), TextField(controller: nim, decoration: const InputDecoration(labelText: 'NIM (opsional)', prefixIcon: Icon(Icons.badge_outlined))), const SizedBox(height: 16), DropdownButtonFormField<int>(initialValue: semester, decoration: const InputDecoration(labelText: 'Semester saat ini', prefixIcon: Icon(Icons.layers_outlined)), items: List.generate(12, (i) => DropdownMenuItem(value: i + 1, child: Text('Semester ${i + 1}'))), onChanged: (v) => setState(() => semester = v ?? 1))]);
  Widget _dots() => Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(2, (i) => AnimatedContainer(duration: const Duration(milliseconds: 200), margin: const EdgeInsets.symmetric(horizontal: 4), width: i == step ? 22 : 7, height: 7, decoration: BoxDecoration(color: i == step ? Theme.of(context).colorScheme.primary : const Color(0xFFD7DCE5), borderRadius: BorderRadius.circular(10)))));
  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
}
class _Pill extends StatelessWidget { final IconData icon; final String text; const _Pill({required this.icon, required this.text}); @override Widget build(BuildContext c) => Container(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9), decoration: BoxDecoration(color: Theme.of(c).colorScheme.surface, borderRadius: BorderRadius.circular(30), border: Border.all(color: Theme.of(c).dividerColor)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 17, color: Theme.of(c).colorScheme.primary), const SizedBox(width: 6), Text(text, style: const TextStyle(fontWeight: FontWeight.w600))])); }

Widget _buildClassCard(BuildContext context, AppStore store, ScheduleItem item) {
  final course = store.courses.where((c) => c.id == item.courseId).firstOrNull;
  return Card(
    margin: const EdgeInsets.only(bottom: 9),
    child: ListTile(
      contentPadding: const EdgeInsets.all(13),
      leading: Container(
        width: 58,
        padding: const EdgeInsets.symmetric(vertical: 7),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(13)),
        child: Column(children: [
          Text(item.start, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800, fontSize: 12)),
          const Text('—', style: TextStyle(color: AppTheme.muted, fontSize: 10)),
          Text(item.end, style: const TextStyle(color: AppTheme.muted, fontSize: 10)),
        ]),
      ),
      title: Text(course?.name ?? 'Mata kuliah', style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text([course?.code, if (item.room.isNotEmpty) item.room].whereType<String>().where((x) => x.isNotEmpty).join(' • ')),
    ),
  );
}

Widget _buildTaskCard(BuildContext context, AppStore store, TaskItem task) {
  final course = store.courses.where((c) => c.id == task.courseId).firstOrNull;
  final late = task.dueDate.isBefore(DateTime.now()) && !task.isDone;
  return Card(
    margin: const EdgeInsets.only(bottom: 9),
    child: ListTile(
      onTap: () => showTaskDetail(context, store, task),
      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 5),
      leading: Checkbox(value: task.isDone, onChanged: (_) => store.toggleTask(task.id)),
      title: Text(task.title, style: TextStyle(fontWeight: FontWeight.w700, decoration: task.isDone ? TextDecoration.lineThrough : null)),
      subtitle: Text('${course?.name ?? 'Mata kuliah'} • ${DateFormat('HH:mm').format(task.dueDate)}', style: TextStyle(color: late ? Colors.red : AppTheme.muted)),
      trailing: _PriorityPill(task.priority),
    ),
  );
}

class HomeShell extends StatefulWidget {
  final AppStore store;
  const HomeShell({super.key, required this.store});
  @override State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int index = 0;
  @override Widget build(BuildContext context) {
    final pages = [DashboardPage(store: widget.store, onTab: (i) => setState(() => index = i)), CoursesPage(store: widget.store), SchedulePage(store: widget.store), ProgressPage(store: widget.store), ProfilePage(store: widget.store)];
    return Scaffold(body: IndexedStack(index: index, children: pages), bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (i) => setState(() => index = i), height: 70, destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'), NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book_rounded), label: 'Kuliah'), NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month_rounded), label: 'Jadwal'), NavigationDestination(icon: Icon(Icons.auto_graph_outlined), selectedIcon: Icon(Icons.auto_graph_rounded), label: 'Progress'), NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'Profil')]));
  }
}

class DashboardPage extends StatelessWidget {
  final AppStore store;
  final ValueChanged<int> onTab;
  const DashboardPage({super.key, required this.store, required this.onTab});

  @override
  Widget build(BuildContext context) {
    final pending = store.tasks.where((t) => !t.completed).toList()..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    final upcoming = _upcomingSchedule(store);
    final now = DateTime.now();
    final greeting = now.hour < 12 ? 'Selamat pagi' : now.hour < 18 ? 'Selamat siang' : 'Selamat malam';
    final totalCredits = store.courses.fold<int>(0, (sum, c) => sum + c.credits);
    return SafeArea(child: CustomScrollView(slivers: [
      SliverPadding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 28), sliver: SliverList(delegate: SliverChildListDelegate([
        Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(greeting, style: const TextStyle(color: AppTheme.muted, fontSize: 13)), const SizedBox(height: 2), Text(store.profile.name.isEmpty ? 'Mahasiswa' : store.profile.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800))])), CircleAvatar(radius: 20, backgroundColor: Theme.of(context).colorScheme.primary.withAlpha(18), backgroundImage: store.profilePhotoPath.isNotEmpty && File(store.profilePhotoPath).existsSync() ? FileImage(File(store.profilePhotoPath)) : null, child: store.profilePhotoPath.isNotEmpty && File(store.profilePhotoPath).existsSync() ? null : Icon(Icons.person_rounded, color: Theme.of(context).colorScheme.primary)), IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NotesPage(store: store))), icon: const Icon(Icons.sticky_note_2_outlined)), IconButton(tooltip: 'Agenda Pintar', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AgendaPage(store: store))), icon: const Icon(Icons.calendar_month_outlined)), IconButton(onPressed: () => _showNotifications(context), icon: const Icon(Icons.notifications_none_rounded))]),
        const SizedBox(height: 16),
        _HeroCard(store: store),
        const SizedBox(height: 16),
        Row(children: [StatCard(icon: Icons.task_alt_rounded, value: '${store.pendingTasks}', label: 'Tugas aktif', color: Theme.of(context).colorScheme.primary), const SizedBox(width: 10), StatCard(icon: Icons.menu_book_rounded, value: '${store.courses.length}', label: 'Mata kuliah', color: AppTheme.teal), const SizedBox(width: 10), StatCard(icon: Icons.star_rounded, value: store.gpa.toStringAsFixed(2), label: 'IP semester', color: AppTheme.orange)]),
        const SizedBox(height: 14),
        Row(children: [Expanded(child: _MiniDashboardStat(icon: Icons.timelapse_rounded, label: 'Dalam proses', value: '${store.inProgressTasks}')), const SizedBox(width: 10), Expanded(child: _MiniDashboardStat(icon: Icons.warning_amber_rounded, label: 'Terlambat', value: '${store.overdueTasks}')), const SizedBox(width: 10), Expanded(child: _MiniDashboardStat(icon: Icons.flag_rounded, label: 'Prioritas tinggi', value: '${store.highPriorityTasks}'))]),
        const SizedBox(height: 18),
        Card(child: ListTile(contentPadding: const EdgeInsets.all(14), leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(13)), child: Icon(Icons.school_outlined, color: Theme.of(context).colorScheme.primary)), title: const Text('Semester kamu', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${store.profile.semester} • $totalCredits SKS terdaftar', style: const TextStyle(color: AppTheme.muted, fontSize: 12)), trailing: TextButton(onPressed: () => onTab(1), child: const Text('Lihat')))),
        const SizedBox(height: 22),
        const SectionTitle(title: 'Jadwal berikutnya'),
        const SizedBox(height: 10),
        upcoming == null ? const _EmptyScheduleDashboard() : _UpcomingScheduleCard(item: upcoming.item, course: upcoming.course, date: upcoming.date),
        const SizedBox(height: 22),
        SectionTitle(title: 'Tugas terdekat', action: 'Lihat semua', onAction: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TasksPage(store: store)))),
        const SizedBox(height: 10),
        if (pending.isEmpty) const EmptyState(icon: Icons.task_alt_rounded, title: 'Semua beres!', subtitle: 'Belum ada tugas yang perlu dikerjakan.') else ...pending.take(3).map((task) => _TaskTile(task: task, course: store.courses.where((c) => c.id == task.courseId).firstOrNull, onToggle: () => store.toggleTask(task.id), onTap: () => showTaskDetail(context, store, task))),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Akses cepat'),
        const SizedBox(height: 10),
        Row(children: [_QuickAction(icon: Icons.add_task_rounded, label: 'Tambah tugas', onTap: () => showTaskForm(context, store)), const SizedBox(width: 10), _QuickAction(icon: Icons.add_box_rounded, label: 'Tambah kuliah', onTap: () => showCourseForm(context, store)), const SizedBox(width: 10), _QuickAction(icon: Icons.design_services_rounded, label: 'Jasa', onTap: () => showServices(context))]),
      ])))
    ]));
  }

  void _showNotifications(BuildContext context) {
    showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 30), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Notifikasi', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      ListTile(leading: const Icon(Icons.notifications_active_outlined), title: const Text('Pengingat tugas'), subtitle: Text(store.notificationsEnabled ? 'Aktif — deadline akan diingatkan otomatis.' : 'Nonaktif — aktifkan dari Profil.'), trailing: Switch(value: store.notificationsEnabled, onChanged: (value) async { await store.setNotificationsEnabled(value); if (context.mounted) Navigator.pop(context); })),
      ListTile(leading: const Icon(Icons.school_outlined), title: const Text('Pengingat kuliah'), subtitle: Text(store.scheduleNotificationsEnabled ? 'Aktif — 30 menit sebelum kelas.' : 'Nonaktif — aktifkan dari Profil.'), trailing: Switch(value: store.scheduleNotificationsEnabled, onChanged: (value) async { await store.setScheduleNotificationsEnabled(value); if (context.mounted) Navigator.pop(context); })),
    ])));
  }
}

class _HeroCard extends StatelessWidget {
  final AppStore store;
  const _HeroCard({required this.store});
  @override Widget build(BuildContext c) => Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Theme.of(c).colorScheme.primary, borderRadius: BorderRadius.circular(22)), child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Semester ${store.profile.semester}', style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)), const SizedBox(height: 5), const Text('Tetap fokus,\nselangkah demi selangkah.', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800, height: 1.15)), const SizedBox(height: 14), Text('${store.completedTasks} tugas selesai', style: const TextStyle(color: Colors.white70))])), Container(width: 68, height: 68, decoration: BoxDecoration(color: Colors.white.withAlpha(28), shape: BoxShape.circle), child: const Icon(Icons.school_rounded, color: Colors.white, size: 34))]));
}

class _QuickAction extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _QuickAction({required this.icon, required this.label, required this.onTap});
  @override Widget build(BuildContext c) => Expanded(child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(16), child: Container(padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8), decoration: BoxDecoration(color: Theme.of(c).colorScheme.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Theme.of(c).dividerColor)), child: Column(children: [Icon(icon, color: Theme.of(c).colorScheme.primary), const SizedBox(height: 8), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600))]))));
}

class _MiniDashboardStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _MiniDashboardStat({required this.icon, required this.label, required this.value});
  @override Widget build(BuildContext c) => Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Theme.of(c).colorScheme.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: Theme.of(c).dividerColor)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, size: 18, color: Theme.of(c).colorScheme.primary), const SizedBox(height: 8), Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)), const SizedBox(height: 2), Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: AppTheme.muted))]));
}

class _UpcomingScheduleData { final ScheduleItem item; final Course? course; final DateTime date; const _UpcomingScheduleData(this.item, this.course, this.date); }
_UpcomingScheduleData? _upcomingSchedule(AppStore store) {
  if (store.schedule.isEmpty) return null;
  final now = DateTime.now(); _UpcomingScheduleData? best;
  for (final item in store.schedule) {
    final parts = item.start.split(':'); final hour = int.tryParse(parts.first) ?? 0; final minute = parts.length > 1 ? int.tryParse(parts[1]) ?? 0 : 0;
    var date = DateTime(now.year, now.month, now.day); final daysAhead = (item.weekday - date.weekday + 7) % 7; date = date.add(Duration(days: daysAhead)); date = DateTime(date.year, date.month, date.day, hour, minute);
    if (!date.isAfter(now)) date = date.add(const Duration(days: 7));
    if (best == null || date.isBefore(best.date)) best = _UpcomingScheduleData(item, store.courses.where((c) => c.id == item.courseId).firstOrNull, date);
  }
  return best;
}

class _UpcomingScheduleCard extends StatelessWidget {
  final ScheduleItem item; final Course? course; final DateTime date;
  const _UpcomingScheduleCard({required this.item, required this.course, required this.date});
  @override Widget build(BuildContext context) => Card(child: ListTile(contentPadding: const EdgeInsets.all(14), leading: Container(width: 58, padding: const EdgeInsets.symmetric(vertical: 8), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(14)), child: Column(children: [Text(DateFormat('EEE', 'id_ID').format(date), style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800, fontSize: 12)), const SizedBox(height: 2), Text(DateFormat('HH:mm').format(date), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12))])), title: Text(course?.name ?? 'Mata kuliah', style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${item.start}–${item.end}${item.room.isEmpty ? '' : '  •  ${item.room}'}')));
}
class _EmptyScheduleDashboard extends StatelessWidget {
  const _EmptyScheduleDashboard();
  @override Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(Icons.event_available_outlined, color: Theme.of(context).colorScheme.primary), title: const Text('Belum ada jadwal', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('Tambahkan jadwal kuliah dari tab Jadwal.')));
}

class AgendaPage extends StatefulWidget {
  final AppStore store;
  const AgendaPage({super.key, required this.store});
  @override State<AgendaPage> createState() => _AgendaPageState();
}

class _AgendaPageState extends State<AgendaPage> {
  DateTime selectedDate = DateTime.now();
  DateTime _day(DateTime d) => DateTime(d.year, d.month, d.day);
  List<TaskItem> _tasks() => widget.store.tasks.where((t) => _day(t.dueDate) == _day(selectedDate)).toList()..sort((a,b) => a.dueDate.compareTo(b.dueDate));
  List<ScheduleItem> _classes() => widget.store.schedule.where((s) => s.weekday == selectedDate.weekday).toList()..sort((a,b) => a.start.compareTo(b.start));
  bool _hasEvents(DateTime d) => widget.store.tasks.any((t) => _day(t.dueDate) == _day(d)) || widget.store.schedule.any((s) => s.weekday == d.weekday);

  @override Widget build(BuildContext context) {
    final tasks = _tasks();
    final classes = _classes();
    final today = _day(selectedDate) == _day(DateTime.now());
    return Scaffold(
      appBar: AppBar(title: const Text('Agenda Pintar'), actions: [IconButton(tooltip: 'Hari ini', onPressed: () => setState(() => selectedDate = DateTime.now()), icon: const Icon(Icons.today_outlined))]),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
        Card(child: CalendarDatePicker(initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime(2100), onDateChanged: (d) => setState(() => selectedDate = d))),
        const SizedBox(height: 14),
        Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(12), borderRadius: BorderRadius.circular(16), border: Border.all(color: Theme.of(context).dividerColor)), child: Row(children: [Icon(Icons.event_available_rounded, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 10), Expanded(child: Text('${today ? 'Hari ini • ' : ''}${DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(selectedDate)}', style: const TextStyle(fontWeight: FontWeight.w700)))])),
        const SizedBox(height: 20),
        const SectionTitle(title: 'Kuliah'), const SizedBox(height: 10),
        if (classes.isEmpty)
          const _AgendaEmpty(icon: Icons.school_outlined, text: 'Tidak ada jadwal kuliah pada tanggal ini.')
        else
          ...classes.map((item) => _buildClassCard(context, widget.store, item)),
        const SizedBox(height: 16),
        Row(children: [const Expanded(child: SectionTitle(title: 'Deadline tugas')), Text('${tasks.length} tugas', style: const TextStyle(color: AppTheme.muted, fontSize: 12))]),
        const SizedBox(height: 10),
        if (tasks.isEmpty)
          const _AgendaEmpty(icon: Icons.task_alt_rounded, text: 'Tidak ada deadline tugas pada tanggal ini.')
        else
          ...tasks.map((task) => _buildTaskCard(context, widget.store, task)),
        if (!_hasEvents(selectedDate)) ...[const SizedBox(height: 4), Card(child: ListTile(leading: Icon(Icons.auto_awesome_outlined, color: Theme.of(context).colorScheme.primary), title: const Text('Hari ini masih kosong ✨', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('Manfaatkan waktu untuk belajar atau menyelesaikan tugas.')))],
      ]),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => showTaskForm(context, widget.store, initialDate: selectedDate), icon: const Icon(Icons.add_task_rounded), label: const Text('Tambah tugas')),
    );
  }
}

class _AgendaEmpty extends StatelessWidget {
  final IconData icon; final String text;
  const _AgendaEmpty({required this.icon, required this.text});
  @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Theme.of(context).dividerColor)), child: Row(children: [Icon(icon, color: AppTheme.muted, size: 20), const SizedBox(width: 10), Expanded(child: Text(text, style: const TextStyle(color: AppTheme.muted, fontSize: 13)))]));
}

class NotesPage extends StatelessWidget {
  final AppStore store;
  const NotesPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final notes = [...store.notes]..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return PageShell(
      title: 'Catatan Kuliah',
      actions: [
        IconButton(onPressed: () => showNoteForm(context, store), icon: const Icon(Icons.add_rounded)),
      ],
      child: notes.isEmpty
          ? EmptyState(
              icon: Icons.sticky_note_2_outlined,
              title: 'Belum ada catatan',
              subtitle: 'Simpan ringkasan materi, ide tugas, atau catatan penting kuliah di sini.',
              buttonText: 'Buat Catatan',
              onPressed: () => showNoteForm(context, store),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
              itemCount: notes.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final note = notes[i];
                final course = store.courses.where((c) => c.id == note.courseId).firstOrNull;
                final preview = note.content.replaceAll(RegExp(r'\s+'), ' ').trim();
                return Card(
                  child: ListTile(
                    onTap: () => showNoteDetail(context, store, note),
                    contentPadding: const EdgeInsets.all(14),
                    leading: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary.withAlpha(18),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(Icons.sticky_note_2_rounded, color: Theme.of(context).colorScheme.primary),
                    ),
                    title: Text(note.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        [if (course != null) course.name, if (preview.isNotEmpty) preview].join(' • '),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) {
                        if (v == 'edit') showNoteForm(context, store, note: note);
                        if (v == 'delete') _confirmDeleteNote(context, store, note);
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('Edit')),
                        PopupMenuItem(value: 'delete', child: Text('Hapus')),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _confirmDeleteNote(BuildContext context, AppStore store, NoteItem note) => showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Hapus catatan?'),
          content: Text('Catatan "${note.title}" akan dihapus dari perangkat.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
            FilledButton(
              onPressed: () {
                store.deleteNote(note.id);
                Navigator.pop(context);
              },
              child: const Text('Hapus'),
            ),
          ],
        ),
      );
}

void showNoteDetail(BuildContext context, AppStore store, NoteItem note) {
  final course = store.courses.where((c) => c.id == note.courseId).firstOrNull;
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(note.title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
            IconButton(onPressed: () { Navigator.pop(ctx); showNoteForm(context, store, note: note); }, icon: const Icon(Icons.edit_outlined)),
          ]),
          if (course != null) ...[
            const SizedBox(height: 4),
            Text(course.name, style: TextStyle(color: Theme.of(ctx).colorScheme.primary, fontWeight: FontWeight.w600)),
          ],
          const SizedBox(height: 16),
          Text(note.content.isEmpty ? 'Catatan ini masih kosong.' : note.content, style: const TextStyle(fontSize: 15, height: 1.55)),
          const SizedBox(height: 18),
          Text('Diperbarui ${DateFormat('dd MMM yyyy • HH:mm', 'id_ID').format(note.updatedAt)}', style: const TextStyle(color: AppTheme.muted, fontSize: 11)),
        ]),
      ),
    ),
  );
}

Future<void> showNoteForm(BuildContext context, AppStore store, {NoteItem? note}) async {
  final title = TextEditingController(text: note?.title ?? '');
  final content = TextEditingController(text: note?.content ?? '');
  String courseId = note?.courseId ?? '';
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(
      builder: (_, set) => _FormSheet(
        title: note == null ? 'Catatan Baru' : 'Edit Catatan',
        children: [
          TextField(controller: title, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Judul catatan', prefixIcon: Icon(Icons.title_rounded))),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            initialValue: courseId,
            decoration: const InputDecoration(labelText: 'Mata kuliah (opsional)', prefixIcon: Icon(Icons.menu_book_outlined)),
            items: [const DropdownMenuItem(value: '', child: Text('Umum')),...store.courses.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name)))],
            onChanged: (v) => set(() => courseId = v ?? ''),
          ),
          const SizedBox(height: 10),
          TextField(controller: content, minLines: 8, maxLines: 14, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Isi catatan', alignLabelWithHint: true, prefixIcon: Icon(Icons.notes_rounded)),),
          const SizedBox(height: 18),
          PrimaryButton(
            label: 'Simpan Catatan',
            onPressed: () {
              if (title.text.trim().isEmpty) return;
              final now = DateTime.now();
              if (note == null) {
                store.addNote(NoteItem(id: now.microsecondsSinceEpoch.toString(), title: title.text.trim(), content: content.text.trim(), courseId: courseId, updatedAt: now));
              } else {
                store.updateNote(note.copyWith(title: title.text.trim(), content: content.text.trim(), courseId: courseId, updatedAt: now));
              }
              Navigator.pop(ctx);
            },
          ),
        ],
      ),
    ),
  );
  title.dispose();
  content.dispose();
}

class CoursesPage extends StatelessWidget {
  final AppStore store;
  const CoursesPage({super.key, required this.store});
  @override Widget build(BuildContext context) => PageShell(title: 'Mata Kuliah', actions: [IconButton(onPressed: () => showCourseForm(context, store), icon: const Icon(Icons.add_rounded))], child: store.courses.isEmpty ? EmptyState(icon: Icons.menu_book_outlined, title: 'Belum ada mata kuliah', subtitle: 'Tambahkan mata kuliah agar jadwal, tugas, dan IPK saling terhubung.', buttonText: 'Tambah Mata Kuliah', onPressed: () => showCourseForm(context, store)) : ListView.separated(padding: const EdgeInsets.fromLTRB(20, 8, 20, 24), itemCount: store.courses.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (_, i) { final c = store.courses[i]; final taskCount = store.tasks.where((t) => t.courseId == c.id && !t.completed).length; final grade = store.grades.where((g) => g.courseId == c.id).firstOrNull; return Card(child: ListTile(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CourseDetailPage(store: store, course: c))), contentPadding: const EdgeInsets.all(12), leading: Container(width: 46, height: 46, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(18), borderRadius: BorderRadius.circular(14)), child: Icon(Icons.menu_book_rounded, color: Theme.of(context).colorScheme.primary)), title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${c.code}  •  ${c.credits} SKS${c.lecturer.isEmpty ? '' : '  •  ${c.lecturer}'}\n$taskCount tugas aktif${grade == null ? '' : '  •  Nilai ${grade.letter}'}'), isThreeLine: true, trailing: PopupMenuButton<String>(onSelected: (v) { if (v == 'detail') Navigator.push(context, MaterialPageRoute(builder: (_) => CourseDetailPage(store: store, course: c))); if (v == 'edit') showCourseForm(context, store, course: c); if (v == 'delete') _confirmDelete(context, c); }, itemBuilder: (_) => const [PopupMenuItem(value: 'detail', child: Text('Lihat detail')), PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'delete', child: Text('Hapus'))]))); }));
  void _confirmDelete(BuildContext context, Course c) => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Hapus mata kuliah?'), content: Text('Data tugas, nilai, dan jadwal yang terkait dengan ${c.name} juga akan dihapus.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')), FilledButton(onPressed: () { store.deleteCourse(c.id); Navigator.pop(context); }, child: const Text('Hapus'))]));
}

class CourseDetailPage extends StatelessWidget {
  final AppStore store; final Course course;
  const CourseDetailPage({super.key, required this.store, required this.course});
  @override Widget build(BuildContext context) {
    final tasks = store.tasks.where((t) => t.courseId == course.id).toList()..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    final schedules = store.schedule.where((s) => s.courseId == course.id).toList()..sort((a, b) => a.weekday == b.weekday ? a.start.compareTo(b.start) : a.weekday.compareTo(b.weekday));
    final grade = store.grades.where((g) => g.courseId == course.id).firstOrNull;
    return Scaffold(appBar: AppBar(title: const Text('Detail Mata Kuliah')), body: ListView(padding: const EdgeInsets.fromLTRB(20, 10, 20, 28), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(22)), child: Row(children: [Container(width: 56, height: 56, decoration: BoxDecoration(color: Colors.white.withAlpha(28), borderRadius: BorderRadius.circular(17)), child: const Icon(Icons.menu_book_rounded, color: Colors.white, size: 28)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(course.name, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 4), Text('${course.code} • ${course.credits} SKS', style: const TextStyle(color: Colors.white70))]))])),
      const SizedBox(height: 16),
      _InfoCard(icon: Icons.person_outline_rounded, title: 'Dosen', value: course.lecturer.isEmpty ? 'Belum diisi' : course.lecturer),
      if (schedules.isNotEmpty) ...[const SizedBox(height: 18), const SectionTitle(title: 'Jadwal kuliah'), const SizedBox(height: 10), ...schedules.map((s) => Card(child: ListTile(leading: const Icon(Icons.schedule_rounded), title: Text(_weekdayName(s.weekday), style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${s.start}–${s.end}${s.room.isEmpty ? '' : '  •  ${s.room}'}'))))],
      const SizedBox(height: 18), const SectionTitle(title: 'Nilai'), const SizedBox(height: 10),
      Card(child: ListTile(contentPadding: const EdgeInsets.all(14), leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primary.withAlpha(15), child: Text(grade?.letter ?? '-', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800))), title: Text(grade == null ? 'Belum ada nilai' : 'Nilai akhir ${grade.score.toStringAsFixed(1)}', style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(grade == null ? 'Isi komponen nilai untuk menghitung grade.' : 'Tugas 30% • UTS 30% • UAS 30% • Kehadiran 10%'), trailing: TextButton(onPressed: () => showGradeForm(context, store, course), child: Text(grade == null ? 'Isi nilai' : 'Edit')))),
      const SizedBox(height: 18), Row(children: [const Expanded(child: SectionTitle(title: 'Tugas')), Text('${tasks.where((t) => !t.completed).length} aktif', style: const TextStyle(color: AppTheme.muted, fontSize: 12))]), const SizedBox(height: 10),
      if (tasks.isEmpty) const EmptyState(icon: Icons.task_alt_rounded, title: 'Belum ada tugas', subtitle: 'Tambahkan tugas untuk mata kuliah ini dari Home.') else ...tasks.map((task) => _TaskTile(task: task, course: course, onToggle: () => store.toggleTask(task.id), onTap: () => showTaskDetail(context, store, task))),
    ]));
  }
}
class _InfoCard extends StatelessWidget { final IconData icon; final String title; final String value; const _InfoCard({required this.icon, required this.title, required this.value}); @override Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon, color: Theme.of(context).colorScheme.primary), title: Text(title, style: const TextStyle(fontSize: 12, color: AppTheme.muted)), subtitle: Text(value, style: const TextStyle(fontWeight: FontWeight.w700)))); }
String _weekdayName(int day) => const ['', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'][day.clamp(1, 7).toInt()];

class SchedulePage extends StatefulWidget { final AppStore store; const SchedulePage({super.key, required this.store}); @override State<SchedulePage> createState() => _SchedulePageState(); }
class _SchedulePageState extends State<SchedulePage> {
  int day = DateTime.now().weekday;

  @override
  Widget build(BuildContext context) {
    final items = widget.store.schedule.where((s) => s.weekday == day).toList()
      ..sort((a, b) => a.start.compareTo(b.start));
    return PageShell(
      title: 'Jadwal Mingguan',
      actions: [
        IconButton(
          onPressed: () => showScheduleForm(context, widget.store),
          icon: const Icon(Icons.add_rounded),
        ),
      ],
      child: Column(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Row(
              children: List.generate(7, (i) {
                final d = i + 1;
                const names = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
                final count = widget.store.schedule.where((s) => s.weekday == d).length;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(names[i]),
                        if (count > 0) ...[
                          const SizedBox(width: 5),
                          Text('$count', style: const TextStyle(fontSize: 10)),
                        ],
                      ],
                    ),
                    selected: day == d,
                    onSelected: (_) => setState(() => day = d),
                  ),
                );
              }),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
            child: Row(
              children: [
                Expanded(child: Text(_weekdayName(day), style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
                Text('${items.length} kelas', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
              ],
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? EmptyState(
                    icon: Icons.event_available_outlined,
                    title: 'Tidak ada kelas',
                    subtitle: 'Hari ini kamu belum punya jadwal kuliah.',
                    buttonText: 'Tambah Jadwal',
                    onPressed: () => showScheduleForm(context, widget.store),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) => _scheduleCard(context, items[i]),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _scheduleCard(BuildContext context, ScheduleItem item) {
    final course = widget.store.courses.where((x) => x.id == item.courseId).firstOrNull;
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(15),
        leading: Container(
          width: 64,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withAlpha(15),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            children: [
              Text(item.start, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800, fontSize: 12)),
              const SizedBox(height: 2),
              const Icon(Icons.arrow_downward_rounded, size: 12),
              Text(item.end, style: const TextStyle(color: AppTheme.muted, fontSize: 10)),
            ],
          ),
        ),
        title: Text(course?.name ?? 'Mata kuliah', style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text([
            course?.code,
            if (item.room.isNotEmpty) 'Ruang ${item.room}',
          ].whereType<String>().where((x) => x.isNotEmpty).join(' • ')),
        ),
        trailing: IconButton(
          onPressed: () => widget.store.deleteSchedule(item.id),
          icon: const Icon(Icons.delete_outline_rounded),
        ),
      ),
    );
  }
}

class ProgressPage extends StatelessWidget {
  final AppStore store;
  const ProgressPage({super.key, required this.store});
  @override Widget build(BuildContext context) {
    final total = store.tasks.length;
    final done = store.completedTasks;
    final progress = total == 0 ? 0.0 : done / total;
    final graded = store.gradedCourses;
    final targetGap = store.targetGpa - store.gpa;
    return PageShell(title: 'Progress & Nilai', child: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 28), children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary,
          borderRadius: BorderRadius.circular(22),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ringkasan semester', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 4),
                  Text('IP ${store.gpa.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 3),
                  Text('$graded dari ${store.courses.length} mata kuliah sudah dinilai', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                ],
              ),
            ),
            Container(
              width: 76,
              height: 76,
              decoration: BoxDecoration(color: Colors.white.withAlpha(28), shape: BoxShape.circle),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(value: progress, color: Colors.white, backgroundColor: Colors.white24, strokeWidth: 7),
                  Text('${(progress * 100).round()}%', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 14),
      Row(children: [Expanded(child: _AcademicStatCard(title: 'Selesai', value: '$done', icon: Icons.check_circle_outline_rounded)), const SizedBox(width: 10), Expanded(child: _AcademicStatCard(title: 'Dalam proses', value: '${store.inProgressTasks}', icon: Icons.timelapse_rounded))]),
      const SizedBox(height: 10),
      Row(children: [Expanded(child: _AcademicStatCard(title: 'Terlambat', value: '${store.overdueTasks}', icon: Icons.warning_amber_rounded)), const SizedBox(width: 10), Expanded(child: _AcademicStatCard(title: 'SKS', value: '${store.totalCredits}', icon: Icons.menu_book_outlined))]),
      const SizedBox(height: 18),
      Card(child: ListTile(contentPadding: const EdgeInsets.all(15), leading: Icon(Icons.flag_outlined, color: Theme.of(context).colorScheme.primary), title: const Text('Target IP', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(targetGap <= 0 ? 'Target ${store.targetGpa.toStringAsFixed(2)} tercapai 🎉' : 'Target ${store.targetGpa.toStringAsFixed(2)} • kurang ${targetGap.toStringAsFixed(2)} poin'), trailing: IconButton(onPressed: () => showTargetGpaForm(context, store), icon: const Icon(Icons.edit_outlined)))),
      const SizedBox(height: 18),
      const SectionTitle(title: 'Progress tugas'), const SizedBox(height: 10),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [Row(children: [Expanded(child: Text('$done dari $total tugas selesai', style: const TextStyle(fontWeight: FontWeight.w700))), Text('${(progress * 100).round()}%', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800))]), const SizedBox(height: 10), LinearProgressIndicator(value: progress, minHeight: 8, borderRadius: BorderRadius.circular(10)), const SizedBox(height: 14), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Belum mulai ${store.notStartedTasks}', style: const TextStyle(fontSize: 11, color: AppTheme.muted)), Text('Proses ${store.inProgressTasks}', style: const TextStyle(fontSize: 11, color: AppTheme.muted)), Text('Selesai ${store.completedTasks}', style: const TextStyle(fontSize: 11, color: AppTheme.muted))])]))),
      const SizedBox(height: 24), const SectionTitle(title: 'Nilai per mata kuliah'), const SizedBox(height: 10),
      if (store.courses.isEmpty)
        const EmptyState(icon: Icons.grade_outlined, title: 'Belum ada data', subtitle: 'Tambahkan mata kuliah terlebih dahulu.')
      else
        ...store.courses.map((course) {
          final grade = store.grades.where((g) => g.courseId == course.id).firstOrNull;
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 6),
              leading: CircleAvatar(
                backgroundColor: Theme.of(context).colorScheme.primary.withAlpha(15),
                child: Text(grade?.letter ?? '-', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800)),
              ),
              title: Text(course.name, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${course.credits} SKS • ${grade == null ? 'Belum diisi' : '${grade.score.toStringAsFixed(1)} / ${grade.letter}'}'),
              trailing: FilledButton.tonal(onPressed: () => showGradeForm(context, store, course), child: Text(grade?.letter ?? 'Isi')),
            ),
          );
        }),
    ]));
  }
}

class _AcademicStatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const _AcademicStatCard({required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(15),
      child: Row(children: [
        Container(width: 40, height: 40, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: Theme.of(context).colorScheme.primary, size: 20)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 11, color: AppTheme.muted)), const SizedBox(height: 3), Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))])),
      ]),
    ),
  );
}

Future<void> showTargetGpaForm(BuildContext context, AppStore store) async {
  final controller = TextEditingController(text: store.targetGpa.toStringAsFixed(2));
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => _FormSheet(
      title: 'Target IP',
      children: [
        const Text('Tentukan target IP semester yang ingin kamu capai.', style: TextStyle(color: AppTheme.muted)),
        const SizedBox(height: 14),
        TextField(controller: controller, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Target IP (0–4)', prefixIcon: Icon(Icons.flag_outlined))),
        const SizedBox(height: 18),
        PrimaryButton(label: 'Simpan Target', onPressed: () async {
          final value = double.tryParse(controller.text.replaceAll(',', '.'));
          if (value == null) return;
          await store.setTargetGpa(value);
          if (ctx.mounted) Navigator.pop(ctx);
        }),
      ],
    ),
  );
  controller.dispose();
}

class ProfilePage extends StatelessWidget {
  final AppStore store; const ProfilePage({super.key, required this.store});
  @override Widget build(BuildContext context) {
    final p = store.profile;
    return PageShell(
      title: 'Profil',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(22)),
            child: Row(children: [
              GestureDetector(
                onTap: () => _showProfilePhotoActions(context, store),
                child: Stack(clipBehavior: Clip.none, children: [
                  Container(
                    width: 62, height: 62,
                    decoration: BoxDecoration(color: Colors.white.withAlpha(30), shape: BoxShape.circle),
                    clipBehavior: Clip.antiAlias,
                    child: store.profilePhotoPath.isNotEmpty && File(store.profilePhotoPath).existsSync()
                        ? Image.file(File(store.profilePhotoPath), fit: BoxFit.cover)
                        : const Icon(Icons.person_rounded, color: Colors.white, size: 32),
                  ),
                  Positioned(
                    right: -2, bottom: -2,
                    child: Container(width: 23, height: 23, decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: Theme.of(context).colorScheme.primary, width: 2)), child: Icon(Icons.camera_alt_rounded, size: 12, color: Theme.of(context).colorScheme.primary)),
                  ),
                ]),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p.name.isEmpty ? 'Mahasiswa' : p.name, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(p.major.isEmpty ? 'Program studi belum diisi' : p.major, style: const TextStyle(color: Colors.white70)),
                Text('Semester ${p.semester}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ])),
            ]),
          ),
          const SizedBox(height: 18),
          _SettingTile(icon: Icons.edit_outlined, title: 'Edit profil', subtitle: 'Nama, universitas, program studi, NIM', onTap: () => showProfileForm(context, store)),
          _SettingTile(icon: Icons.sticky_note_2_outlined, title: 'Catatan kuliah', subtitle: '${store.notes.length} catatan tersimpan', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NotesPage(store: store)))),
          _SettingTile(icon: Icons.dark_mode_outlined, title: 'Tampilan', subtitle: _themeSummary(store), onTap: () => showThemePicker(context, store)),
          _SettingTile(icon: Icons.volume_up_outlined, title: 'Suara notifikasi', subtitle: _soundSummary(store.notificationSound), onTap: () => showNotificationSoundPicker(context, store)),
          _NotificationSettingTile(store: store),
          _ScheduleNotificationSettingTile(store: store),
          _SettingTile(icon: Icons.design_services_outlined, title: 'Bantuan & jasa', subtitle: 'PPT, Excel, dan format dokumen', onTap: () => showServices(context)),
          _SettingTile(icon: Icons.info_outline_rounded, title: 'Tentang aplikasi', subtitle: 'Student Companion • v2.6.1', onTap: () => showAbout(context)),
          const SizedBox(height: 10),
          const Text('Data tersimpan lokal di perangkat. Backup cloud dan sinkronisasi dapat ditambahkan pada fase berikutnya.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: AppTheme.muted, height: 1.4)),
        ],
      ),
    );
  }
}
class _SettingTile extends StatelessWidget { final IconData icon; final String title; final String subtitle; final VoidCallback onTap; const _SettingTile({required this.icon, required this.title, required this.subtitle, required this.onTap}); @override Widget build(BuildContext c) => Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(onTap: onTap, contentPadding: const EdgeInsets.all(13), leading: Container(width: 42, height: 42, decoration: BoxDecoration(color: Theme.of(c).colorScheme.primary.withAlpha(16), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: Theme.of(c).colorScheme.primary)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right_rounded))); }

class _NotificationSettingTile extends StatelessWidget {
  final AppStore store;
  const _NotificationSettingTile({required this.store});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: SwitchListTile(
          value: store.notificationsEnabled,
          onChanged: (value) => store.setNotificationsEnabled(value),
          secondary: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withAlpha(16),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(Icons.notifications_active_outlined, color: Theme.of(context).colorScheme.primary),
          ),
          title: const Text('Pengingat tugas', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: const Text('H-1, 1 jam sebelum, dan saat deadline'),
        ),
      );
}

class _ScheduleNotificationSettingTile extends StatelessWidget {
  final AppStore store;
  const _ScheduleNotificationSettingTile({required this.store});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: SwitchListTile(
          value: store.scheduleNotificationsEnabled,
          onChanged: (value) => store.setScheduleNotificationsEnabled(value),
          secondary: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withAlpha(16),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(Icons.school_outlined, color: Theme.of(context).colorScheme.primary),
          ),
          title: const Text('Pengingat kuliah', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: const Text('30 menit sebelum jadwal kuliah'),
        ),
      );
}


String _themeSummary(AppStore store) {
  final mode = switch (store.themeMode) {
    'dark' => 'Gelap',
    'light' => 'Terang',
    _ => 'Ikuti sistem',
  };
  final accent = AppTheme.themeNames[store.theme] ?? 'Biru';
  return '$mode • Aksen $accent';
}

String _soundSummary(String sound) {
  const names = {
    'default': 'Default',
    'soft': 'Lembut',
    'tone1': 'Nada 1',
    'tone2': 'Nada 2',
    'firm': 'Tegas',
    'silent': 'Senyap',
  };
  return names[sound] ?? 'Default';
}


Future<void> _showProfilePhotoActions(BuildContext context, AppStore store) async {
  await showModalBottomSheet(
    context: context,
    showDragHandle: true,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Align(alignment: Alignment.centerLeft, child: Text('Foto profil', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
        const SizedBox(height: 8),
        const Align(alignment: Alignment.centerLeft, child: Text('Pilih foto dari galeri atau hapus foto saat ini.', style: TextStyle(color: AppTheme.muted))),
        const SizedBox(height: 16),
        ListTile(leading: const Icon(Icons.photo_library_outlined), title: const Text('Pilih dari galeri'), onTap: () async { Navigator.pop(ctx); await store.pickProfilePhoto(); }),
        if (store.profilePhotoPath.isNotEmpty) ListTile(leading: const Icon(Icons.delete_outline_rounded), title: const Text('Hapus foto'), onTap: () async { Navigator.pop(ctx); await store.removeProfilePhoto(); }),
      ]),
    ),
  );
}

class TasksPage extends StatelessWidget {
  final AppStore store;
  const TasksPage({super.key, required this.store});
  @override Widget build(BuildContext context) {
    final tasks = [...store.tasks]..sort((a, b) { if (a.isDone != b.isDone) return a.isDone ? 1 : -1; if (a.dueDate != b.dueDate) return a.dueDate.compareTo(b.dueDate); return a.priority.compareTo(b.priority); });
    return Scaffold(appBar: AppBar(title: const Text('Semua Tugas'), actions: [IconButton(onPressed: () => showTaskForm(context, store), icon: const Icon(Icons.add_rounded))]), body: tasks.isEmpty ? EmptyState(icon: Icons.task_alt_rounded, title: 'Belum ada tugas', subtitle: 'Tambahkan tugas untuk mulai mengatur deadline.', buttonText: 'Tambah Tugas', onPressed: () => showTaskForm(context, store)) : ListView.separated(padding: const EdgeInsets.fromLTRB(20, 10, 20, 28), itemCount: tasks.length, separatorBuilder: (_, __) => const SizedBox(height: 9), itemBuilder: (_, i) { final task = tasks[i]; return _TaskTile(task: task, course: store.courses.where((c) => c.id == task.courseId).firstOrNull, onToggle: () => store.toggleTask(task.id), onTap: () => showTaskDetail(context, store, task)); }));
  }
}
void showTaskDetail(BuildContext context, AppStore store, TaskItem task) { Navigator.push(context, MaterialPageRoute(builder: (_) => TaskDetailPage(store: store, taskId: task.id))); }
class TaskDetailPage extends StatefulWidget {
  final AppStore store; final String taskId;
  const TaskDetailPage({super.key, required this.store, required this.taskId});
  @override State<TaskDetailPage> createState() => _TaskDetailPageState();
}
class _TaskDetailPageState extends State<TaskDetailPage> {
  @override Widget build(BuildContext context) {
    final task = widget.store.tasks.where((t) => t.id == widget.taskId).firstOrNull;
    if (task == null) return const Scaffold(body: Center(child: Text('Tugas tidak ditemukan.')));
    final course = widget.store.courses.where((c) => c.id == task.courseId).firstOrNull;
    final lateTask = task.dueDate.isBefore(DateTime.now()) && !task.completed;
    return Scaffold(appBar: AppBar(title: const Text('Detail Tugas')), body: ListView(padding: const EdgeInsets.fromLTRB(20, 10, 20, 28), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text(task.title, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800))), const SizedBox(width: 8), _PriorityPill(task.priority)]), const SizedBox(height: 12), Text(course?.name ?? 'Mata kuliah', style: const TextStyle(color: Colors.white70))])),
      const SizedBox(height: 16), _TaskInfoRow(icon: Icons.event_outlined, title: 'Deadline', value: DateFormat('EEEE, dd MMMM yyyy • HH:mm', 'id_ID').format(task.dueDate), valueColor: lateTask ? Colors.red : null), const SizedBox(height: 10), _TaskInfoRow(icon: Icons.flag_outlined, title: 'Prioritas', value: task.priority), const SizedBox(height: 10), _TaskInfoRow(icon: task.isDone ? Icons.check_circle_outline_rounded : Icons.pending_actions_rounded, title: 'Status', value: task.isDone ? 'Selesai' : lateTask ? 'Terlambat' : task.status),
      const SizedBox(height: 18),
      const Text('Ubah status tugas', style: TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      SegmentedButton<String>(
        segments: const [
          ButtonSegment(value: 'Belum mulai', icon: Icon(Icons.radio_button_unchecked_rounded), label: Text('Belum mulai')),
          ButtonSegment(value: 'Dalam proses', icon: Icon(Icons.timelapse_rounded), label: Text('Proses')),
          ButtonSegment(value: 'Selesai', icon: Icon(Icons.check_circle_outline_rounded), label: Text('Selesai')),
        ],
        selected: {task.status},
        onSelectionChanged: (v) async { await widget.store.setTaskStatus(task.id, v.first); if (mounted) setState(() {}); },
        multiSelectionEnabled: false,
        showSelectedIcon: false,
      ),
      const SizedBox(height: 20),
      FilledButton.icon(
        onPressed: () async {
          await widget.store.toggleTask(task.id);
          if (!mounted) return;
          setState(() {});
        },
        icon: Icon(task.isDone ? Icons.undo_rounded : Icons.check_rounded),
        label: Text(task.isDone ? 'Tandai belum mulai' : 'Tandai selesai'),
      ),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: () async {
          await widget.store.deleteTask(task.id);
          if (!context.mounted) return;
          Navigator.pop(context);
        },
        icon: const Icon(Icons.delete_outline_rounded),
        label: const Text('Hapus tugas'),
      ),
    ]));
  }
}
class _TaskInfoRow extends StatelessWidget { final IconData icon; final String title; final String value; final Color? valueColor; const _TaskInfoRow({required this.icon, required this.title, required this.value, this.valueColor}); @override Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon, color: Theme.of(context).colorScheme.primary), title: Text(title, style: const TextStyle(fontSize: 12, color: AppTheme.muted)), subtitle: Text(value, style: TextStyle(fontWeight: FontWeight.w700, color: valueColor)))); }
class _TaskTile extends StatelessWidget {
  final TaskItem task;
  final Course? course;
  final VoidCallback onToggle;
  final VoidCallback onTap;
  const _TaskTile({required this.task, required this.course, required this.onToggle, required this.onTap});

  @override
  Widget build(BuildContext c) {
    final lateTask = task.dueDate.isBefore(DateTime.now()) && !task.isDone;
    final timeLeft = task.dueDate.difference(DateTime.now());
    final deadline = task.isDone
        ? 'Selesai'
        : lateTask
            ? 'Terlambat'
            : timeLeft.inHours < 24
                ? 'Kurang 1 hari'
                : DateFormat('dd MMM, HH:mm', 'id_ID').format(task.dueDate);
    final deadlineColor = task.isDone
        ? AppTheme.teal
        : lateTask
            ? Colors.red
            : timeLeft.inHours < 24
                ? AppTheme.orange
                : AppTheme.muted;
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        leading: Checkbox(value: task.isDone, onChanged: (_) => onToggle()),
        title: Row(
          children: [
            Expanded(child: Text(task.title, style: TextStyle(fontWeight: FontWeight.w700, decoration: task.isDone ? TextDecoration.lineThrough : null))),
            const SizedBox(width: 6),
            _PriorityPill(task.priority),
          ],
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Wrap(
            spacing: 7,
            runSpacing: 4,
            children: [
              Text(course?.name ?? 'Mata kuliah', style: const TextStyle(color: AppTheme.muted)),
              const Text('•'),
              Text(task.status, style: const TextStyle(color: AppTheme.muted)),
              const Text('•'),
              Text(deadline, style: TextStyle(color: deadlineColor, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

class _PriorityPill extends StatelessWidget { final String value; const _PriorityPill(this.value); @override Widget build(BuildContext c) { final color = value == 'Tinggi' ? Colors.red : value == 'Rendah' ? AppTheme.teal : AppTheme.orange; return Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5), decoration: BoxDecoration(color: color.withAlpha(20), borderRadius: BorderRadius.circular(20)), child: Text(value, style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.w700))); } }

Future<void> showCourseForm(BuildContext context, AppStore store, {Course? course}) async { final name = TextEditingController(text: course?.name); final code = TextEditingController(text: course?.code); final credits = TextEditingController(text: '${course?.credits ?? 2}'); final lecturer = TextEditingController(text: course?.lecturer); await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => _FormSheet(title: course == null ? 'Tambah Mata Kuliah' : 'Edit Mata Kuliah', children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Nama mata kuliah')), const SizedBox(height: 10), Row(children: [Expanded(child: TextField(controller: code, decoration: const InputDecoration(labelText: 'Kode'))), const SizedBox(width: 10), SizedBox(width: 90, child: TextField(controller: credits, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'SKS')))]), const SizedBox(height: 10), TextField(controller: lecturer, decoration: const InputDecoration(labelText: 'Dosen (opsional)')), const SizedBox(height: 18), PrimaryButton(label: course == null ? 'Simpan' : 'Simpan Perubahan', onPressed: () { if (name.text.trim().isEmpty || code.text.trim().isEmpty) return; final c = Course(id: course?.id ?? DateTime.now().microsecondsSinceEpoch.toString(), name: name.text.trim(), code: code.text.trim(), credits: int.tryParse(credits.text) ?? 2, lecturer: lecturer.text.trim()); if (course == null) { store.addCourse(c); } else { store.updateCourse(c); } Navigator.pop(ctx); })])); name.dispose(); code.dispose(); credits.dispose(); lecturer.dispose(); }

Future<void> showTaskForm(BuildContext context, AppStore store, {DateTime? initialDate}) async {
  final title = TextEditingController();
  final baseDate = initialDate ?? DateTime.now().add(const Duration(days: 1));
  DateTime due = DateTime(baseDate.year, baseDate.month, baseDate.day, initialDate == null ? 18 : 18, 0);
  String priority = 'Sedang';
  String status = 'Belum mulai';
  String? courseId = store.courses.isEmpty ? null : store.courses.first.id;
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(
      builder: (_, set) => _FormSheet(
        title: 'Tambah Tugas',
        children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Nama tugas')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(initialValue: courseId, decoration: const InputDecoration(labelText: 'Mata kuliah'), items: store.courses.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(), onChanged: (v) => set(() => courseId = v)),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(initialValue: priority, decoration: const InputDecoration(labelText: 'Prioritas'), items: const ['Tinggi','Sedang','Rendah'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => set(() => priority = v ?? 'Sedang')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(initialValue: 'Belum mulai', decoration: const InputDecoration(labelText: 'Status awal'), items: const ['Belum mulai','Dalam proses','Selesai'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => set(() => status = v ?? 'Belum mulai')),
          const SizedBox(height: 10),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.event_outlined),
            title: const Text('Deadline'),
            subtitle: Text(DateFormat('EEEE, dd MMM yyyy • HH:mm', 'id_ID').format(due)),
            trailing: Wrap(children: [
              TextButton(onPressed: () async { final d = await showDatePicker(context: ctx, firstDate: DateTime.now(), lastDate: DateTime(2100), initialDate: due); if (d != null) set(() => due = DateTime(d.year, d.month, d.day, due.hour, due.minute)); }, child: const Text('Tanggal')),
              TextButton(onPressed: () async { final t = await showTimePicker(context: ctx, initialTime: TimeOfDay.fromDateTime(due)); if (t != null) set(() => due = DateTime(due.year, due.month, due.day, t.hour, t.minute)); }, child: const Text('Jam')),
            ]),
          ),
          const SizedBox(height: 10),
          const Text('Jika aktif: H-1, 1 jam sebelum, dan tepat saat deadline.', style: TextStyle(color: AppTheme.muted, fontSize: 12)),
          const SizedBox(height: 10),
          PrimaryButton(label: 'Simpan Tugas', onPressed: () { if (title.text.trim().isEmpty || courseId == null) return; store.addTask(TaskItem(id: DateTime.now().microsecondsSinceEpoch.toString(), title: title.text.trim(), courseId: courseId!, dueDate: due, priority: priority, status: status, completed: status == 'Selesai')); Navigator.pop(ctx); })
        ],
      ),
    ),
  );
  title.dispose();
}

Future<void> showScheduleForm(BuildContext context, AppStore store) async { int weekday = DateTime.now().weekday; String? courseId = store.courses.isEmpty ? null : store.courses.first.id; final start = TextEditingController(text: '08:00'); final end = TextEditingController(text: '09:40'); final room = TextEditingController(); await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => StatefulBuilder(builder: (_, set) => _FormSheet(title: 'Tambah Jadwal', children: [DropdownButtonFormField<int>(initialValue: weekday, decoration: const InputDecoration(labelText: 'Hari'), items: const [1,2,3,4,5,6,7].map((d) => DropdownMenuItem(value: d, child: Text(['','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'][d]))).toList(), onChanged: (v) => set(() => weekday = v ?? 1)), const SizedBox(height: 10), DropdownButtonFormField<String>(initialValue: courseId, decoration: const InputDecoration(labelText: 'Mata kuliah'), items: store.courses.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(), onChanged: (v) => set(() => courseId = v)), const SizedBox(height: 10), Row(children: [Expanded(child: TextField(controller: start, decoration: const InputDecoration(labelText: 'Mulai'))), const SizedBox(width: 10), Expanded(child: TextField(controller: end, decoration: const InputDecoration(labelText: 'Selesai')))]), const SizedBox(height: 10), TextField(controller: room, decoration: const InputDecoration(labelText: 'Ruangan (opsional)')), const SizedBox(height: 18), PrimaryButton(label: 'Simpan Jadwal', onPressed: () { if (courseId == null || start.text.trim().isEmpty || end.text.trim().isEmpty) return; store.addSchedule(ScheduleItem(id: DateTime.now().microsecondsSinceEpoch.toString(), courseId: courseId!, weekday: weekday, start: start.text.trim(), end: end.text.trim(), room: room.text.trim())); Navigator.pop(ctx); })]))); start.dispose(); end.dispose(); room.dispose(); }

Future<void> showGradeForm(BuildContext context, AppStore store, Course course) async { final existing = store.grades.where((g) => g.courseId == course.id).firstOrNull; final a = TextEditingController(text: existing?.assignment.toString() ?? '0'); final m = TextEditingController(text: existing?.midterm.toString() ?? '0'); final f = TextEditingController(text: existing?.finalExam.toString() ?? '0'); final at = TextEditingController(text: existing?.attendance.toString() ?? '0'); await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => _GradeSheet(course: course, a: a, m: m, f: f, at: at, store: store)); a.dispose(); m.dispose(); f.dispose(); at.dispose(); }
class _GradeSheet extends StatefulWidget { final Course course; final TextEditingController a,m,f,at; final AppStore store; const _GradeSheet({required this.course, required this.a, required this.m, required this.f, required this.at, required this.store}); @override State<_GradeSheet> createState() => _GradeSheetState(); }
class _GradeSheetState extends State<_GradeSheet> { double get score => (double.tryParse(widget.a.text) ?? 0)*.3 + (double.tryParse(widget.m.text) ?? 0)*.3 + (double.tryParse(widget.f.text) ?? 0)*.3 + (double.tryParse(widget.at.text) ?? 0)*.1; @override Widget build(BuildContext c) => Padding(padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(c).bottom), child: SingleChildScrollView(child: Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 28), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Nilai ${widget.course.name}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 6), Text('Bobot: tugas 30% • UTS 30% • UAS 30% • kehadiran 10%', style: const TextStyle(color: AppTheme.muted, fontSize: 12)), const SizedBox(height: 18), _num(widget.a, 'Tugas (0–100)'), const SizedBox(height: 10), _num(widget.m, 'UTS (0–100)'), const SizedBox(height: 10), _num(widget.f, 'UAS (0–100)'), const SizedBox(height: 10), _num(widget.at, 'Kehadiran (0–100)'), const SizedBox(height: 18), Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Theme.of(c).colorScheme.primary.withAlpha(12), borderRadius: BorderRadius.circular(15)), child: Row(children: [Expanded(child: Text('Nilai akhir', style: const TextStyle(fontWeight: FontWeight.w700))), Text(score.toStringAsFixed(1), style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: Theme.of(c).colorScheme.primary))])), const SizedBox(height: 16), PrimaryButton(label: 'Simpan Nilai', onPressed: () { widget.store.upsertGrade(GradeItem(id: DateTime.now().microsecondsSinceEpoch.toString(), courseId: widget.course.id, assignment: _clamp(widget.a.text), midterm: _clamp(widget.m.text), finalExam: _clamp(widget.f.text), attendance: _clamp(widget.at.text))); Navigator.pop(c); })])))); Widget _num(TextEditingController c, String label) => TextField(controller: c, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: label), onChanged: (_) => setState(() {})); double _clamp(String s) => (double.tryParse(s) ?? 0).clamp(0, 100).toDouble(); }

Future<void> showProfileForm(BuildContext context, AppStore store) async { final p = store.profile; final name = TextEditingController(text: p.name), uni = TextEditingController(text: p.university), major = TextEditingController(text: p.major), nim = TextEditingController(text: p.nim); int semester = p.semester; await showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => StatefulBuilder(builder: (_, set) => _FormSheet(title: 'Edit Profil', children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Nama lengkap')), const SizedBox(height: 10), TextField(controller: uni, decoration: const InputDecoration(labelText: 'Universitas')), const SizedBox(height: 10), TextField(controller: major, decoration: const InputDecoration(labelText: 'Program studi')), const SizedBox(height: 10), TextField(controller: nim, decoration: const InputDecoration(labelText: 'NIM')), const SizedBox(height: 10), DropdownButtonFormField<int>(initialValue: semester, decoration: const InputDecoration(labelText: 'Semester'), items: List.generate(12, (i) => DropdownMenuItem(value: i+1, child: Text('Semester ${i+1}'))), onChanged: (v) => set(() => semester = v ?? semester)), const SizedBox(height: 18), PrimaryButton(label: 'Simpan Profil', onPressed: () { if (name.text.trim().isEmpty) return; store.updateProfile(p.copyWith(name: name.text.trim(), university: uni.text.trim(), major: major.text.trim(), nim: nim.text.trim(), semester: semester)); Navigator.pop(ctx); })]))); name.dispose(); uni.dispose(); major.dispose(); nim.dispose(); }

Future<void> showThemePicker(BuildContext context, AppStore store) => showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
          child: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Tampilan aplikasi', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text('Pilih mode tampilan dan warna aksen favoritmu.', style: TextStyle(color: AppTheme.muted)),
              const SizedBox(height: 14),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'light', icon: Icon(Icons.light_mode_outlined), label: Text('Terang')),
                  ButtonSegment(value: 'dark', icon: Icon(Icons.dark_mode_outlined), label: Text('Gelap')),
                  ButtonSegment(value: 'system', icon: Icon(Icons.brightness_auto_outlined), label: Text('Sistem')),
                ],
                selected: {store.themeMode},
                onSelectionChanged: (v) { store.setThemeMode(v.first); set(() {}); },
              ),
              const SizedBox(height: 20),
              const Text('Warna tema', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 10, runSpacing: 10,
                children: AppTheme.themeNames.keys.map((theme) {
                  final selected = store.theme == theme;
                  final color = AppTheme.primaryFor(theme);
                  return Tooltip(
                    message: AppTheme.themeNames[theme]!,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(30),
                      onTap: () { store.setTheme(theme); set(() {}); },
                      child: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: selected ? Theme.of(ctx).colorScheme.onSurface : Colors.transparent, width: 3)),
                        child: selected ? const Icon(Icons.check_rounded, color: Colors.white, size: 22) : null,
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 12),
              Text('Terpilih: ${AppTheme.themeNames[store.theme] ?? 'Biru'}', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
            ]),
          ),
        ),
      ),
    );

Future<void> showNotificationSoundPicker(BuildContext context, AppStore store) => showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) {
          const labels = {
            'default': ('Default', 'Suara bawaan sistem'),
            'soft': ('Lembut', 'Nada pendek dan halus'),
            'tone1': ('Nada 1', 'Nada cerah'),
            'tone2': ('Nada 2', 'Nada ganda'),
            'firm': ('Tegas', 'Nada lebih menonjol'),
            'silent': ('Senyap', 'Tanpa suara'),
          };
          return Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Suara notifikasi', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text('Pilih suara untuk pengingat tugas dan kuliah.', style: TextStyle(color: AppTheme.muted)),
              const SizedBox(height: 12),
              ...NotificationService.soundNames.map((sound) {
                final selected = store.notificationSound == sound;
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(
                    selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                    color: selected ? Theme.of(ctx).colorScheme.primary : AppTheme.muted,
                  ),
                  title: Text(labels[sound]!.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(labels[sound]!.$2),
                  onTap: () async {
                    await store.setNotificationSound(sound);
                    set(() {});
                  },
                );
              }),
              const SizedBox(height: 6),
              SizedBox(width: double.infinity, child: OutlinedButton.icon(
                onPressed: store.notificationSound == 'silent' ? null : () async {
                  final ok = await NotificationService.previewSound(store.notificationSound);
                  if (!ctx.mounted) return;
                  ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(ok ? 'Notifikasi uji dikirim. Cek panel notifikasi HP.' : 'Izin notifikasi belum diberikan. Aktifkan izin notifikasi di Pengaturan HP.')));
                },
                icon: const Icon(Icons.notifications_active_outlined), label: const Text('Tes notifikasi & suara'),
              )),
            ]),
          );
        },
      ),
    );

Future<void> showServices(BuildContext context) => showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 30), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Bantuan & Jasa', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)), const SizedBox(height: 6), const Text('Layanan teknis dan desain untuk membantu pekerjaanmu.', style: TextStyle(color: AppTheme.muted)), const SizedBox(height: 18), _ServiceTile(icon: Icons.slideshow_rounded, title: 'Pembuatan PPT', subtitle: 'Desain presentasi yang rapi dan profesional'), _ServiceTile(icon: Icons.table_chart_rounded, title: 'Pembuatan Excel', subtitle: 'Template, dashboard, laporan, dan otomatisasi'), _ServiceTile(icon: Icons.description_outlined, title: 'Format Dokumen', subtitle: 'Rapikan Word, daftar isi, layout, dan format'), const SizedBox(height: 10), const Text('Hubungkan tombol pemesanan ke WhatsApp/form/backend saat fase monetisasi.', style: TextStyle(fontSize: 11, color: AppTheme.muted))])));
class _ServiceTile extends StatelessWidget { final IconData icon; final String title; final String subtitle; const _ServiceTile({required this.icon, required this.title, required this.subtitle}); @override Widget build(BuildContext c) => Card(margin: const EdgeInsets.only(bottom: 9), child: ListTile(contentPadding: const EdgeInsets.all(11), leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: Theme.of(c).colorScheme.primary.withAlpha(15), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: Theme.of(c).colorScheme.primary)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(subtitle))); }

void showAbout(BuildContext context) => showAboutDialog(context: context, applicationName: 'Student Companion', applicationVersion: '2.6.0', applicationIcon: const Icon(Icons.school_rounded), children: const [Text('Teman kuliahmu dari semester 1 sampai lulus. Versi awal berfokus pada tugas, mata kuliah, jadwal, nilai, progress, dan profil.')]);

class _FormSheet extends StatelessWidget { final String title; final List<Widget> children; const _FormSheet({required this.title, required this.children}); @override Widget build(BuildContext c) => Padding(padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(c).bottom), child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 28), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)), const SizedBox(height: 18), ...children]))); }
