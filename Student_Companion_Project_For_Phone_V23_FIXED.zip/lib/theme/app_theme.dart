import 'package:flutter/material.dart';

class AppTheme {
  static const blue = Color(0xFF2563EB);
  static const purple = Color(0xFF7C3AED);
  static const teal = Color(0xFF0F9F8E);
  static const orange = Color(0xFFF59E0B);
  static const ink = Color(0xFF172033);
  static const muted = Color(0xFF667085);
  static const background = Color(0xFFF6F8FC);

  static Color primaryFor(String theme) {
    switch (theme) {
      case 'purple': return purple;
      case 'teal': return teal;
      case 'orange': return orange;
      default: return blue;
    }
  }

  static ThemeData light(String theme) => _build(theme, Brightness.light);
  static ThemeData dark(String theme) => _build(theme, Brightness.dark);

  static ThemeData _build(String theme, Brightness brightness) {
    final primary = primaryFor(theme);
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(seedColor: primary, brightness: brightness).copyWith(primary: primary);
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: dark ? const Color(0xFF0F141C) : background,
      fontFamily: 'Poppins',
      appBarTheme: AppBarTheme(
        backgroundColor: dark ? const Color(0xFF0F141C) : background,
        foregroundColor: scheme.onSurface,
        elevation: 0,
        centerTitle: false,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: dark ? const Color(0xFF171E28) : Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: dark ? const Color(0xFF2A3442) : const Color(0xFFE6EAF0))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: primary, width: 1.5)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      ),
      cardTheme: CardThemeData(
        color: dark ? const Color(0xFF171E28) : Colors.white,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: dark ? const Color(0xFF283241) : const Color(0xFFE8ECF2))),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: dark ? const Color(0xFF151B24) : Colors.white,
        indicatorColor: primary.withAlpha(dark ? 55 : 28),
      ),
      dividerTheme: DividerThemeData(color: dark ? const Color(0xFF2A3442) : const Color(0xFFE8ECF2)),
    );
  }
}
